package com.scb.rwb.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.scb.rwb.glue.TestData;

public class ExcelRead {

	/**
	 * This method will read and reutrn the value from the ProductOfferingExcel
	 * based on the given country Code
	 * 
	 * @param countryCode
	 * @return
	 */
	public static ArrayList<String> getSubProductListFromProductOfferingXLS(
			String countryCode) {
		TestData.TestDataPath = "features//" + countryCode
				+ "-features//TestData//ProductOffering.xlsx";
		ArrayList<String> data = getDataFromExcelBasedOnGivenFileAndColNo(
				TestData.TestDataPath, "SubProductList", 0);
		return data;
	}

	/**
	 * This method will read and reutrn the value from the
	 * CardCurrentAndLoanExcel based on the given country Code
	 * 
	 * @param countryCode
	 * @return
	 */
	public static ArrayList<String> getSubProductListFromCurrentCardAndLoanXLS(
			String countryCode) {
		TestData.TestDataPath = "features//" + countryCode
				+ "-features//TestData//Current-and-Card-and-Loan.xlsx";
		ArrayList<String> data = getDataFromExcelBasedOnGivenFileAndColNo(
				TestData.TestDataPath, "Subprdt selector", 0);
		return data;
	}

	/**
	 * This method will read And return the data from the given file path and
	 * sheet name the columm number
	 * 
	 * @param filePath
	 * @param col
	 * @return
	 */
	public static ArrayList<String> getDataFromExcelBasedOnGivenFileAndColNo(
			String filePath, String sheetName, int col) {
		ArrayList<String> data = new ArrayList<>();
		File file = new File(filePath);
		FileInputStream fs;
		XSSFWorkbook wb;
		try {
			fs = new FileInputStream(file);
			wb = new XSSFWorkbook(fs);
			XSSFSheet subProductSheet = wb.getSheet(sheetName);
			int RowCount = subProductSheet.getLastRowNum();
			for (int i = 0; i <= RowCount; i++) {
				System.out.println(subProductSheet.getRow(i).getCell(col)
						.getStringCellValue());
				data.add(subProductSheet.getRow(i).getCell(col)
						.getStringCellValue());
			}
		} catch (IOException e1) {

		}
		return data;
	}
}
