//package com.scb.rwb.utility;
//
//import java.util.ArrayList;
//
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
//
//public class FromFillTestData {
//
//	public FromFillTestData(ArrayList<ArrayList<String>> testData) {
//
//		int i = 1;
//		setTitle(testData.get(1).get(i));
//		setFirstName(testData.get(2).get(i));
//		setMiddleName(testData.get(3).get(i));
//		setLastName(testData.get(4).get(i));
//		setFullName(testData.get(5).get(i));
//		setAliasName(testData.get(6).get(i));
//		setIdNo(testData.get(7).get(i));
//		setIdIssueDate(testData.get(8).get(i));
//		setOtherIdDetails(testData.get(9).get(i));
//		setGender(testData.get(10).get(i));
//		setMaritalStatus(testData.get(11).get(i));
//		setDateOfBirth(testData.get(12).get(i));
//		setCountryOfBirth(testData.get(13).get(i));
//		setDistrictOfBirth(testData.get(14).get(i));
//		setNationality(testData.get(15).get(i));
//		setOtherNation(testData.get(16).get(i));
//		setPassportNo(testData.get(17).get(i));
//		setPassportIssuanceDate(testData.get(18).get(i));
//		setPassportCountry(testData.get(19).get(i));
//		setPassportExpiryDate(testData.get(20).get(i));
//		setDrivingLicenseNo(testData.get(21).get(i));
//		setDrivingLicenseExpiryDate(testData.get(22).get(i));
//		setDrivingLicenseIssueDate(testData.get(23).get(i));
//		setDrivingLicenseIssueCountry(testData.get(24).get(i));
//		setQualification(testData.get(25).get(i));
//		setMothersMaidenName(testData.get(26).get(i));
//		setFatherName(testData.get(27).get(i));
//		setTaxIdNo(testData.get(28).get(i));
//		setResidenceCountry(testData.get(29).get(i));
//		setResidentialStatus(testData.get(30).get(i));
//		setNoOfDependants(testData.get(31).get(i));
//		setNoOfCarOwned(testData.get(32).get(i));
//		setStaffCategory(testData.get(33).get(i));
//		setSpouseFullName(testData.get(34).get(i));
//		setSpouseProfession(testData.get(35).get(i));
//		setSpouseOrganisation(testData.get(36).get(i));
//		setSpouseOfficeLine1(testData.get(37).get(i));
//		setSpouseOfficeLine2(testData.get(38).get(i));
//		setSpouseOfficeLine3(testData.get(39).get(i));
//		setSpouseContactNo(testData.get(40).get(i));
//		setSpouseEmail(testData.get(41).get(i));
//		setSpouseFavColour(testData.get(42).get(i));
//		setSpouseFavCity(testData.get(43).get(i));
//
//		/**
//		 * This is for Address details
//		 * 
//		 */
//		setResAddressLine1(testData.get(45).get(i));
//		setResAddressLine2(testData.get(46).get(i));
//		setResAddressLine3(testData.get(47).get(i));
//		setResAddressLine4(testData.get(47).get(i));
//		setResPostalCode(testData.get(49).get(i));
//		setResCity(testData.get(50).get(i));
//		setResCountry(testData.get(51).get(i));
//		setResidenceType(testData.get(52).get(i));
//		setRentPerAnnum(testData.get(53).get(i));
//		setTimeAtAddressYrs(testData.get(54).get(i));
//		setPerSameAsResidentialAddress(testData.get(55).get(i));
//		setPerAddressLine1(testData.get(56).get(i));
//		setPerAddressLine2(testData.get(56).get(i));
//		setPerAddressLine3(testData.get(58).get(i));
//		setPerAddressLine4(testData.get(59).get(i));
//		setPerPostalCode(testData.get(60).get(i));
//		setPerCity(testData.get(61).get(i));
//		setPerCountry(testData.get(62).get(i));
//		setOffAddressLine1(testData.get(63).get(i));
//		setOffAddressLine2(testData.get(64).get(i));
//		setOffAddressLine3(testData.get(65).get(i));
//		setOffAddressLine4(testData.get(66).get(i));
//		setOffPostalCode(testData.get(67).get(i));
//		setOffCity(testData.get(68).get(i));
//		setOffCountry(testData.get(69).get(i));
//		setMailingAddress(testData.get(70).get(i));
//		setOthAddressLine1(testData.get(71).get(i));
//		setOthAddressLine2(testData.get(72).get(i));
//		setOthAddressLine3(testData.get(73).get(i));
//		setOthAddressLine4(testData.get(74).get(i));
//		setOthPostalCode(testData.get(75).get(i));
//		setOthCity(testData.get(76).get(i));
//		setOthCountry(testData.get(77).get(i));
//		setProofAddressDoc(testData.get(78).get(i));
//		setHome(testData.get(80).get(i));
//		setWork(testData.get(81).get(i));
//		setMobile(testData.get(82).get(i));
//		setFax(testData.get(83).get(i));
//		setEmail(testData.get(84).get(i));
//		setOtherContact(testData.get(85).get(i));
//
//		/* Setting Income section values */
//
//		setMonSalaryIncome(testData.get(87).get(i));
//		setMonAllowances(testData.get(88).get(i));
//		setMonTotalIncome(testData.get(89).get(i));
//		setSourceOfOtherIncome(testData.get(90).get(i));
//		setSpouseMonthlyIncome(testData.get(91).get(i));
//		setOthIncomeAvgTurnover(testData.get(92).get(i));
//		setMonthlyRentalIncome(testData.get(93).get(i));
//		setMonBizIncome(testData.get(94).get(i));
//		setMonRentUtility(testData.get(95).get(i));
//		setMonFoodExp(testData.get(96).get(i));
//		setMonEduExp(testData.get(97).get(i));
//		setMonLoanRepay(testData.get(98).get(i));
//		setMonOthExp(testData.get(99).get(i));
//		setMonTotalExp(testData.get(100).get(i));
//
//		/**
//		 * This is for Employment details
//		 */
//		setEmploymentType(testData.get(102).get(i));
//		setEmploymentStatus(testData.get(103).get(i));
//		setCompany(testData.get(104).get(i));
//		setBusinessType(testData.get(105).get(i));
//		setBusinessSetupDate(testData.get(106).get(i));
//		setBusinessOwnership(testData.get(107).get(i));
//		setOfficePremiseStatus(testData.get(108).get(i));
//		setPrevBusinessName(testData.get(109).get(i));
//		setTotalLengthCurrBizYears(testData.get(110).get(i));
//		setTotalLengthCurrBizMonths(testData.get(111).get(i));
//		setTotalBizExpYears(testData.get(112).get(i));
//		setTotalBizExpMonths(testData.get(113).get(i));
//		setProfession(testData.get(114).get(i));
//		setDesignation(testData.get(115).get(i));
//		setEmployerCode(testData.get(116).get(i));
//		setEmployeeStaffId(testData.get(117).get(i));
//		setTotalCurrEmpYears(testData.get(118).get(i));
//		setTotalCurrEmpMonths(testData.get(119).get(i));
//		setTotalLengthOfEmploymentYears(testData.get(120).get(i));
//		setTotalLengthOfEmploymentMonths(testData.get(121).get(i));
//		setNameOfPrevEmployer(testData.get(122).get(i));
//		setTotalPrevEmpYears(testData.get(123).get(i));
//		setTotalPrevEmpMonths(testData.get(124).get(i));
//		
//		/**
//		 * Bank details
//		 */
//		
//		setChequeBookRequiredCa(testData.get(126).get(i));
//		setChequeBookTypeCa(testData.get(127).get(i));
//		setRequiredAtmDebitCard(testData.get(128).get(i));
//		setAccountLinksToDebitCardAtm(testData.get(129).get(i));
//		setInternetBanking(testData.get(130).get(i));
//		setSmsAlerts(testData.get(131).get(i));
//		seteStatementCasa(testData.get(132).get(i));
//		setEeStatementTypeCasa(testData.get(133).get(i));
//		setStatementHardcopyCasa(testData.get(134).get(i));
//		setStatementFrequencyCasa(testData.get(135).get(i));
//		seteStatementCreditCard(testData.get(136).get(i));
//		seteStatementTypeCreditCard(testData.get(137).get(i));
//		setStatementHardcopyCreditCard(testData.get(138).get(i));
//		setStatementFrequencyCreditCard(testData.get(139).get(i));
//		
//		/**
//		 * Product Specific details
//		 */
//		
//		setNoNominee(testData.get(141).get(i));
//		setNomName1(testData.get(142).get(i));
//		setPercent1(testData.get(143).get(i));
//		setNomName2(testData.get(144).get(i));
//		setPercent2(testData.get(145).get(i));
//		setNomName3(testData.get(146).get(i));
//		setPercent3(testData.get(147).get(i));
//		setBankName1(testData.get(148).get(i));
//		setBranch1(testData.get(149).get(i));
//		setTypeAccount1(testData.get(150).get(i));
//		setAccountCardno1(testData.get(151).get(i));
//		setCreditLoan1(testData.get(152).get(i));
//		setOutstandingAmt1(testData.get(153).get(i));
//		setInstalamt1(testData.get(154).get(i));
//		setCardMemberSince1(testData.get(155).get(i));
//		setBankName2(testData.get(156).get(i));
//		setBranch2(testData.get(157).get(i));
//		setTypeAccount2(testData.get(158).get(i));
//		setAccountCardno2(testData.get(159).get(i));
//		setCreditLoan2(testData.get(160).get(i));
//		setOutstandingAmt2(testData.get(161).get(i));
//		setInstalAmt2(testData.get(162).get(i));
//		setCardMemberSince2(testData.get(163).get(i));
//		setBankName3(testData.get(164).get(i));
//		setBranch3(testData.get(165).get(i));
//		setTypeAccount3(testData.get(166).get(i));
//		setAccountCardno3(testData.get(167).get(i));
//		setCreditLoan3(testData.get(168).get(i));
//		setOutsSandingamt3(testData.get(169).get(i));
//		setInstalAmt3(testData.get(170).get(i));
//		setCardMemberSince3(testData.get(171).get(i));
//		setLoanRelatedcCient(testData.get(172).get(i));
//		setAccountNo(testData.get(173).get(i));
//		setCreditcardEmbossedName(testData.get(174).get(i));
//		setCardDeliveryAddType(testData.get(175).get(i));
//		setCardCollectionBranch(testData.get(176).get(i));
//		setLoanAmount(testData.get(177).get(i));
//		setTermMonths(testData.get(178).get(i));
//		setCurrency(testData.get(179).get(i));
//		setPreferredBranch(testData.get(180).get(i));
//		setLoanDisbaAcountno(testData.get(181).get(i));
//		setInterestrateodFacility(testData.get(182).get(i));
//		setDirectorotherBanks(testData.get(183).get(i));
//		
//		/**
//		 * Customer Due Diligenece
//		 */
//		
//		setAoForBusinessPuspose(testData.get(185).get(i));
//		setPurposeAccOpen(testData.get(186).get(i));
//		setPurposeOthersSpecify(testData.get(187).get(i));
//		setDepositAmountUsd(testData.get(188).get(i));
//		setModeOfInitialFundsDeposit(testData.get(189).get(i));
//		setDerWealthFromSanctionedCountries(testData.get(190).get(i));
//		setSavingsNetWorthUsd(testData.get(191).get(i));
//		setSourceOfWealth(testData.get(192).get(i));
//		setSsourceFundSpecify(testData.get(193).get(i));
//		
//		
//		/**
//		 * Fatca
//		 */
//		
//		setUsResidentFlag(testData.get(195).get(i));
//		setsCitizenFlag(testData.get(196).get(i));
//		setPrFlag(testData.get(197).get(i));
//		setConfirmation(testData.get(198).get(i));
//		
//		
//		/**
//		 * For Internal Use
//		 */
//		
//		setNbArmCode(testData.get(200).get(i));
//		setInstitutionClassification(testData.get(201).get(i));
//		setRelationshipNo(testData.get(202).get(i));
//		setLocationDhaka(testData.get(203).get(i));
//		setAcqChannelCode(testData.get(204).get(i));
//		setPreApprOffer(testData.get(205).get(i));
//		setPreApprOfferDetails(testData.get(206).get(i));
//		setPreApprOfferIdNo(testData.get(207).get(i));
//		setDseCode(testData.get(208).get(i));
//		setSegment(testData.get(209).get(i));
//		setSubSegment(testData.get(210).get(i));
//		setPlSegment(testData.get(211).get(i));
//		setArea(testData.get(212).get(i));
//		setArmCode(testData.get(213).get(i));
//		setCampaignCode(testData.get(214).get(i));
//		setDeviationLevel(testData.get(215).get(i));
//		setLoanNo(testData.get(216).get(i));
//		setMasterNo(testData.get(217).get(i));
//		setPayrollIndicator(testData.get(218).get(i));
//		setSpotApproval(testData.get(219).get(i));
//		setTopUp(testData.get(220).get(i));
//		setCibReportFetching(testData.get(221).get(i));
//		setForwardedBy(testData.get(222).get(i));
//		setReferralCode(testData.get(223).get(i));
//		setSalesStaffDesignation(testData.get(224).get(i));
//		setReferenceNoCampaign(testData.get(225).get(i));
//
//	}
//
//	private String title;
//	private String firstName;
//	private String middleName;
//	private String lastName;
//	private String fullName;
//	private String aliasName;
//	private String idNo;
//	private String idIssueDate;
//	private String otherIdDetails;
//	private String gender;
//	private String maritalStatus;
//	private String dateOfBirth;
//	private String countryOfBirth;
//	private String districtOfBirth;
//	private String nationality;
//	private String otherNation;
//	private String passportNo;
//	private String passportIssuanceDate;
//	private String passportCountry;
//	private String passportExpiryDate;
//	private String drivingLicenseNo;
//	private String drivingLicenseExpiryDate;
//	private String drivingLicenseIssueDate;
//	private String drivingLicenseIssueCountry;
//	private String qualification;
//	private String mothersMaidenName;
//	private String fatherName;
//	private String taxIdNo;
//	private String residenceCountry;
//	private String residentialStatus;
//	private String noOfDependants;
//	private String noOfCarOwned;
//	private String staffCategory;
//	private String spouseFullName;
//	private String spouseProfession;
//	private String spouseOrganisation;
//	private String spouseOfficeLine1;
//	private String spouseOfficeLine2;
//	private String spouseOfficeLine3;
//	private String spouseContactNo;
//	private String spouseEmail;
//	private String spouseFavColour;
//	private String spouseFavCity;
//
//	private String resAddressLine1;
//	private String resAddressLine2;
//	private String resAddressLine3;
//	private String resAddressLine4;
//	private String resPostalCode;
//	private String resCity;
//	private String resCountry;
//	private String residenceType;
//	private String rentPerAnnum;
//	private String timeAtAddressYrs;
//	private String perSameAsResidentialAddress;
//	private String perAddressLine1;
//	private String perAddressLine2;
//	private String perAddressLine3;
//	private String perAddressLine4;
//	private String perPostalCode;
//	private String perCity;
//	private String perCountry;
//	private String offAddressLine1;
//	private String offAddressLine2;
//	private String offAddressLine3;
//	private String offAddressLine4;
//	private String offPostalCode;
//	private String offCity;
//	private String offCountry;
//	private String mailingAddress;
//	private String othAddressLine1;
//	private String othAddressLine2;
//	private String othAddressLine3;
//	private String othAddressLine4;
//	private String othPostalCode;
//	private String othCity;
//	private String othCountry;
//	private String proofAddressDoc;
//
//	private String home;
//	private String work;
//	private String mobile;
//	private String fax;
//	private String email;
//	private String otherContact;
//
//	/*
//	 * Income Window field declarations
//	 */
//	private String monSalaryIncome;
//	private String monAllowances;
//	private String monTotalIncome;
//	private String sourceOfOtherIncome;
//	private String spouseMonthlyIncome;
//	private String othIncomeAvgTurnover;
//	private String monthlyRentalIncome;
//	private String monBizIncome;
//	private String monRentUtility;
//	private String monFoodExp;
//	private String monEduExp;
//	private String monLoanRepay;
//	private String monOthExp;
//	private String monTotalExp;
//
//	/**
//	 * Employee
//	 * 
//	 * @return
//	 */
//
//	private String employmentType;
//	private String employmentStatus;
//	private String company;
//	private String businessType;
//	private String businessSetupDate;
//	private String businessOwnership;
//	private String officePremiseStatus;
//	private String prevBusinessName;
//	private String totalLengthCurrBizYears;
//	private String totalLengthCurrBizMonths;
//	private String totalBizExpYears;
//	private String totalBizExpMonths;
//	private String profession;
//	private String designation;
//	private String employerCode;
//	private String employeeStaffId;
//	private String totalCurrEmpYears;
//	private String totalCurrEmpMonths;
//	private String totalLengthOfEmploymentYears;
//	private String totalLengthOfEmploymentMonths;
//	private String nameOfPrevEmployer;
//	private String totalPrevEmpYears;
//	private String totalPrevEmpMonths;
//
//	/**
//	 * Bank details
//	 * 
//	 * @return
//	 */
//	
//	private String	chequeBookRequiredCa;
//	private String	chequeBookTypeCa;
//	private String	requiredAtmDebitCard;
//	private String	accountLinksToDebitCardAtm;
//	private String	internetBanking;
//	private String	smsAlerts;
//	private String	eStatementCasa;
//	private String	EeStatementTypeCasa;
//	private String	statementHardcopyCasa;
//	private String	statementFrequencyCasa;
//	private String	eStatementCreditCard;
//	private String	eStatementTypeCreditCard;
//	private String	statementHardcopyCreditCard;
//	private String	statementFrequencyCreditCard;
//	
//	
//	/**
//	 * Product specific
//	 * @return
//	 */
//	
//	private String	noNominee;
//	private String	nomName1;
//	private String	percent1;
//	private String	nomName2;
//	private String	percent2;
//	private String	nomName3;
//	private String	percent3;
//	private String	bankName1;
//	private String	branch1;
//	private String	typeAccount1;
//	private String	accountCardno1;
//	private String	creditLoan1;
//	private String	outstandingAmt1;
//	private String	instalamt1;
//	private String	cardMemberSince1;
//	private String	bankName2;
//	private String	branch2;
//	private String	typeAccount2;
//	private String	accountCardno2;
//	private String	creditLoan2;
//	private String	outstandingAmt2;
//	private String	instalAmt2;
//	private String	cardMemberSince2;
//	private String	bankName3;
//	private String	branch3;
//	private String	typeAccount3;
//	private String	accountCardno3;
//	private String	creditLoan3;
//	private String	outsSandingamt3;
//	private String	instalAmt3;
//	private String	cardMemberSince3;
//	private String	loanRelatedcCient;
//	private String	accountNo;
//	private String	creditcardEmbossedName;
//	private String	cardDeliveryAddType;
//	private String	cardCollectionBranch;
//	private String	loanAmount;
//	private String	termMonths;
//	private String	currency;
//	private String	preferredBranch;
//	private String	loanDisbaAcountno;
//	private String	interestrateodFacility;
//	private String	directorotherBanks;
//	
//	/**
//	 * Customer Due diligence
//	 * @return
//	 */
//	
//	private String	aoForBusinessPuspose;
//	private String	purposeAccOpen;
//	private String	purposeOthersSpecify;
//	private String	depositAmountUsd;
//	private String	modeOfInitialFundsDeposit;
//	private String	derWealthFromSanctionedCountries;
//	private String	savingsNetWorthUsd;
//	private String	sourceOfWealth;
//	private String	SsourceFundSpecify;
//	
//	/**
//	 * Facta
//	 * @return
//	 */
//	
//	private String usResidentFlag;
//	private String sCitizenFlag;
//	private String prFlag;
//	private String confirmation;
//	
//	/**
//	 * For Internal Use
//	 */
//	
//	private String	nbArmCode;
//	private String	institutionClassification;
//	private String	relationshipNo;
//	private String	locationDhaka;
//	private String	acqChannelCode;
//	private String	preApprOffer;
//	private String	preApprOfferDetails;
//	private String	preApprOfferIdNo;
//	private String	dseCode;
//	private String	segment;
//	private String	subSegment;
//	private String	plSegment;
//	private String	area;
//	private String	armCode;
//	private String	campaignCode;
//	private String	deviationLevel;
//	private String	loanNo;
//	private String	masterNo;
//	private String	payrollIndicator;
//	private String	spotApproval;
//	private String	topUp;
//	private String	cibReportFetching;
//	private String	forwardedBy;
//	private String	referralCode;
//	private String	salesStaffDesignation;
//	private String	referenceNoCampaign;
//	
//
//	public String getTitle() {
//		return title;
//	}
//
//	public void setTitle(String title) {
//		this.title = title;
//	}
//
//	public String getFirstName() {
//		return firstName;
//	}
//
//	public void setFirstName(String firstName) {
//		this.firstName = firstName;
//	}
//
//	public String getMiddleName() {
//		return middleName;
//	}
//
//	public void setMiddleName(String middleName) {
//		this.middleName = middleName;
//	}
//
//	public String getLastName() {
//		return lastName;
//	}
//
//	public void setLastName(String lastName) {
//		this.lastName = lastName;
//	}
//
//	public String getFullName() {
//		return fullName;
//	}
//
//	public void setFullName(String fullName) {
//		this.fullName = fullName;
//	}
//
//	public String getAliasName() {
//		return aliasName;
//	}
//
//	public void setAliasName(String aliasName) {
//		this.aliasName = aliasName;
//	}
//
//	public String getIdNo() {
//		return idNo;
//	}
//
//	public void setIdNo(String idNo) {
//		this.idNo = idNo;
//	}
//
//	public String getIdIssueDate() {
//		return idIssueDate;
//	}
//
//	public void setIdIssueDate(String idIssueDate) {
//		this.idIssueDate = idIssueDate;
//	}
//
//	public String getOtherIdDetails() {
//		return otherIdDetails;
//	}
//
//	public void setOtherIdDetails(String otherIdDetails) {
//		this.otherIdDetails = otherIdDetails;
//	}
//
//	public String getGender() {
//		return gender;
//	}
//
//	public void setGender(String gender) {
//		this.gender = gender;
//	}
//
//	public String getMaritalStatus() {
//		return maritalStatus;
//	}
//
//	public void setMaritalStatus(String maritalStatus) {
//		this.maritalStatus = maritalStatus;
//	}
//
//	public String getDateOfBirth() {
//		return dateOfBirth;
//	}
//
//	public void setDateOfBirth(String dateOfBirth) {
//		this.dateOfBirth = dateOfBirth;
//	}
//
//	public String getCountryOfBirth() {
//		return countryOfBirth;
//	}
//
//	public void setCountryOfBirth(String countryOfBirth) {
//		this.countryOfBirth = countryOfBirth;
//	}
//
//	public String getDistrictOfBirth() {
//		return districtOfBirth;
//	}
//
//	public void setDistrictOfBirth(String districtOfBirth) {
//		this.districtOfBirth = districtOfBirth;
//	}
//
//	public String getNationality() {
//		return nationality;
//	}
//
//	public void setNationality(String nationality) {
//		this.nationality = nationality;
//	}
//
//	public String getOtherNation() {
//		return otherNation;
//	}
//
//	public void setOtherNation(String otherNation) {
//		this.otherNation = otherNation;
//	}
//
//	public String getPassportNo() {
//		return passportNo;
//	}
//
//	public void setPassportNo(String passportNo) {
//		this.passportNo = passportNo;
//	}
//
//	public String getPassportIssuanceDate() {
//		return passportIssuanceDate;
//	}
//
//	public void setPassportIssuanceDate(String passportIssuanceDate) {
//		this.passportIssuanceDate = passportIssuanceDate;
//	}
//
//	public String getPassportCountry() {
//		return passportCountry;
//	}
//
//	public void setPassportCountry(String passportCountry) {
//		this.passportCountry = passportCountry;
//	}
//
//	public String getPassportExpiryDate() {
//		return passportExpiryDate;
//	}
//
//	public void setPassportExpiryDate(String passportExpiryDate) {
//		this.passportExpiryDate = passportExpiryDate;
//	}
//
//	public String getDrivingLicenseNo() {
//		return drivingLicenseNo;
//	}
//
//	public void setDrivingLicenseNo(String drivingLicenseNo) {
//		this.drivingLicenseNo = drivingLicenseNo;
//	}
//
//	public String getDrivingLicenseExpiryDate() {
//		return drivingLicenseExpiryDate;
//	}
//
//	public void setDrivingLicenseExpiryDate(String drivingLicenseExpiryDate) {
//		this.drivingLicenseExpiryDate = drivingLicenseExpiryDate;
//	}
//
//	public String getDrivingLicenseIssueDate() {
//		return drivingLicenseIssueDate;
//	}
//
//	public void setDrivingLicenseIssueDate(String drivingLicenseIssueDate) {
//		this.drivingLicenseIssueDate = drivingLicenseIssueDate;
//	}
//
//	public String getDrivingLicenseIssueCountry() {
//		return drivingLicenseIssueCountry;
//	}
//
//	public void setDrivingLicenseIssueCountry(String drivingLicenseIssueCountry) {
//		this.drivingLicenseIssueCountry = drivingLicenseIssueCountry;
//	}
//
//	public String getQualification() {
//		return qualification;
//	}
//
//	public void setQualification(String qualification) {
//		this.qualification = qualification;
//	}
//
//	public String getMothersMaidenName() {
//		return mothersMaidenName;
//	}
//
//	public void setMothersMaidenName(String mothersMaidenName) {
//		this.mothersMaidenName = mothersMaidenName;
//	}
//
//	public String getFatherName() {
//		return fatherName;
//	}
//
//	public void setFatherName(String fatherName) {
//		this.fatherName = fatherName;
//	}
//
//	public String getTaxIdNo() {
//		return taxIdNo;
//	}
//
//	public void setTaxIdNo(String taxIdNo) {
//		this.taxIdNo = taxIdNo;
//	}
//
//	public String getResidenceCountry() {
//		return residenceCountry;
//	}
//
//	public void setResidenceCountry(String residenceCountry) {
//		this.residenceCountry = residenceCountry;
//	}
//
//	public String getResidentialStatus() {
//		return residentialStatus;
//	}
//
//	public void setResidentialStatus(String residentialStatus) {
//		this.residentialStatus = residentialStatus;
//	}
//
//	public String getNoOfDependants() {
//		return noOfDependants;
//	}
//
//	public void setNoOfDependants(String noOfDependants) {
//		this.noOfDependants = noOfDependants;
//	}
//
//	public String getNoOfCarOwned() {
//		return noOfCarOwned;
//	}
//
//	public void setNoOfCarOwned(String noOfCarOwned) {
//		this.noOfCarOwned = noOfCarOwned;
//	}
//
//	public String getStaffCategory() {
//		return staffCategory;
//	}
//
//	public void setStaffCategory(String staffCategory) {
//		this.staffCategory = staffCategory;
//	}
//
//	public String getSpouseFullName() {
//		return spouseFullName;
//	}
//
//	public void setSpouseFullName(String spouseFullName) {
//		this.spouseFullName = spouseFullName;
//	}
//
//	public String getSpouseProfession() {
//		return spouseProfession;
//	}
//
//	public void setSpouseProfession(String spouseProfession) {
//		this.spouseProfession = spouseProfession;
//	}
//
//	public String getSpouseOrganisation() {
//		return spouseOrganisation;
//	}
//
//	public void setSpouseOrganisation(String spouseOrganisation) {
//		this.spouseOrganisation = spouseOrganisation;
//	}
//
//	public String getSpouseOfficeLine1() {
//		return spouseOfficeLine1;
//	}
//
//	public void setSpouseOfficeLine1(String spouseOfficeLine1) {
//		this.spouseOfficeLine1 = spouseOfficeLine1;
//	}
//
//	public String getSpouseOfficeLine2() {
//		return spouseOfficeLine2;
//	}
//
//	public void setSpouseOfficeLine2(String spouseOfficeLine2) {
//		this.spouseOfficeLine2 = spouseOfficeLine2;
//	}
//
//	public String getSpouseOfficeLine3() {
//		return spouseOfficeLine3;
//	}
//
//	public void setSpouseOfficeLine3(String spouseOfficeLine3) {
//		this.spouseOfficeLine3 = spouseOfficeLine3;
//	}
//
//	public String getSpouseContactNo() {
//		return spouseContactNo;
//	}
//
//	public void setSpouseContactNo(String spouseContactNo) {
//		this.spouseContactNo = spouseContactNo;
//	}
//
//	public String getSpouseEmail() {
//		return spouseEmail;
//	}
//
//	public void setSpouseEmail(String spouseEmail) {
//		this.spouseEmail = spouseEmail;
//	}
//
//	public String getSpouseFavColour() {
//		return spouseFavColour;
//	}
//
//	public void setSpouseFavColour(String spouseFavColour) {
//		this.spouseFavColour = spouseFavColour;
//	}
//
//	public String getSpouseFavCity() {
//		return spouseFavCity;
//	}
//
//	public void setSpouseFavCity(String spouseFavCity) {
//		this.spouseFavCity = spouseFavCity;
//	}
//
//	public String getResAddressLine1() {
//		return resAddressLine1;
//	}
//
//	public void setResAddressLine1(String resAddressLine1) {
//		this.resAddressLine1 = resAddressLine1;
//	}
//
//	public String getResAddressLine2() {
//		return resAddressLine2;
//	}
//
//	public void setResAddressLine2(String resAddressLine2) {
//		this.resAddressLine2 = resAddressLine2;
//	}
//
//	public String getResAddressLine3() {
//		return resAddressLine3;
//	}
//
//	public void setResAddressLine3(String resAddressLine3) {
//		this.resAddressLine3 = resAddressLine3;
//	}
//
//	public String getResAddressLine4() {
//		return resAddressLine4;
//	}
//
//	public void setResAddressLine4(String resAddressLine4) {
//		this.resAddressLine4 = resAddressLine4;
//	}
//
//	public String getResPostalCode() {
//		return resPostalCode;
//	}
//
//	public void setResPostalCode(String resPostalCode) {
//		this.resPostalCode = resPostalCode;
//	}
//
//	public String getResCity() {
//		return resCity;
//	}
//
//	public void setResCity(String resCity) {
//		this.resCity = resCity;
//	}
//
//	public String getResCountry() {
//		return resCountry;
//	}
//
//	public void setResCountry(String resCountry) {
//		this.resCountry = resCountry;
//	}
//
//	public String getResidenceType() {
//		return residenceType;
//	}
//
//	public void setResidenceType(String residenceType) {
//		this.residenceType = residenceType;
//	}
//
//	public String getRentPerAnnum() {
//		return rentPerAnnum;
//	}
//
//	public void setRentPerAnnum(String rentPerAnnum) {
//		this.rentPerAnnum = rentPerAnnum;
//	}
//
//	public String getTimeAtAddressYrs() {
//		return timeAtAddressYrs;
//	}
//
//	public void setTimeAtAddressYrs(String timeAtAddressYrs) {
//		this.timeAtAddressYrs = timeAtAddressYrs;
//	}
//
//	public String getPerSameAsResidentialAddress() {
//		return perSameAsResidentialAddress;
//	}
//
//	public void setPerSameAsResidentialAddress(
//			String perSameAsResidentialAddress) {
//		this.perSameAsResidentialAddress = perSameAsResidentialAddress;
//	}
//
//	public String getPerAddressLine1() {
//		return perAddressLine1;
//	}
//
//	public void setPerAddressLine1(String perAddressLine1) {
//		this.perAddressLine1 = perAddressLine1;
//	}
//
//	public String getPerAddressLine2() {
//		return perAddressLine2;
//	}
//
//	public void setPerAddressLine2(String perAddressLine2) {
//		this.perAddressLine2 = perAddressLine2;
//	}
//
//	public String getPerAddressLine3() {
//		return perAddressLine3;
//	}
//
//	public void setPerAddressLine3(String perAddressLine3) {
//		this.perAddressLine3 = perAddressLine3;
//	}
//
//	public String getPerAddressLine4() {
//		return perAddressLine4;
//	}
//
//	public void setPerAddressLine4(String perAddressLine4) {
//		this.perAddressLine4 = perAddressLine4;
//	}
//
//	public String getPerPostalCode() {
//		return perPostalCode;
//	}
//
//	public void setPerPostalCode(String perPostalCode) {
//		this.perPostalCode = perPostalCode;
//	}
//
//	public String getPerCity() {
//		return perCity;
//	}
//
//	public void setPerCity(String perCity) {
//		this.perCity = perCity;
//	}
//
//	public String getPerCountry() {
//		return perCountry;
//	}
//
//	public void setPerCountry(String perCountry) {
//		this.perCountry = perCountry;
//	}
//
//	public String getOffAddressLine1() {
//		return offAddressLine1;
//	}
//
//	public void setOffAddressLine1(String offAddressLine1) {
//		this.offAddressLine1 = offAddressLine1;
//	}
//
//	public String getOffAddressLine2() {
//		return offAddressLine2;
//	}
//
//	public void setOffAddressLine2(String offAddressLine2) {
//		this.offAddressLine2 = offAddressLine2;
//	}
//
//	public String getOffAddressLine3() {
//		return offAddressLine3;
//	}
//
//	public void setOffAddressLine3(String offAddressLine3) {
//		this.offAddressLine3 = offAddressLine3;
//	}
//
//	public String getOffAddressLine4() {
//		return offAddressLine4;
//	}
//
//	public void setOffAddressLine4(String offAddressLine4) {
//		this.offAddressLine4 = offAddressLine4;
//	}
//
//	public String getOffPostalCode() {
//		return offPostalCode;
//	}
//
//	public void setOffPostalCode(String offPostalCode) {
//		this.offPostalCode = offPostalCode;
//	}
//
//	public String getOffCity() {
//		return offCity;
//	}
//
//	public void setOffCity(String offCity) {
//		this.offCity = offCity;
//	}
//
//	public String getOffCountry() {
//		return offCountry;
//	}
//
//	public void setOffCountry(String offCountry) {
//		this.offCountry = offCountry;
//	}
//
//	public String getMailingAddress() {
//		return mailingAddress;
//	}
//
//	public void setMailingAddress(String mailingAddress) {
//		this.mailingAddress = mailingAddress;
//	}
//
//	public String getOthAddressLine1() {
//		return othAddressLine1;
//	}
//
//	public void setOthAddressLine1(String othAddressLine1) {
//		this.othAddressLine1 = othAddressLine1;
//	}
//
//	public String getOthAddressLine2() {
//		return othAddressLine2;
//	}
//
//	public void setOthAddressLine2(String othAddressLine2) {
//		this.othAddressLine2 = othAddressLine2;
//	}
//
//	public String getOthAddressLine3() {
//		return othAddressLine3;
//	}
//
//	public void setOthAddressLine3(String othAddressLine3) {
//		this.othAddressLine3 = othAddressLine3;
//	}
//
//	public String getOthAddressLine4() {
//		return othAddressLine4;
//	}
//
//	public void setOthAddressLine4(String othAddressLine4) {
//		this.othAddressLine4 = othAddressLine4;
//	}
//
//	public String getOthPostalCode() {
//		return othPostalCode;
//	}
//
//	public void setOthPostalCode(String othPostalCode) {
//		this.othPostalCode = othPostalCode;
//	}
//
//	public String getOthCity() {
//		return othCity;
//	}
//
//	public void setOthCity(String othCity) {
//		this.othCity = othCity;
//	}
//
//	public String getOthCountry() {
//		return othCountry;
//	}
//
//	public void setOthCountry(String othCountry) {
//		this.othCountry = othCountry;
//	}
//
//	public String getProofAddressDoc() {
//		return proofAddressDoc;
//	}
//
//	public void setProofAddressDoc(String proofAddressDoc) {
//		this.proofAddressDoc = proofAddressDoc;
//	}
//
//	public String getHome() {
//		return home;
//	}
//
//	public void setHome(String home) {
//		this.home = home;
//	}
//
//	public String getWork() {
//		return work;
//	}
//
//	public void setWork(String work) {
//		this.work = work;
//	}
//
//	public String getMobile() {
//		return mobile;
//	}
//
//	public void setMobile(String mobile) {
//		this.mobile = mobile;
//	}
//
//	public String getFax() {
//		return fax;
//	}
//
//	public void setFax(String fax) {
//		this.fax = fax;
//	}
//
//	public String getEmail() {
//		return email;
//	}
//
//	public void setEmail(String email) {
//		this.email = email;
//	}
//
//	public String getOtherContact() {
//		return otherContact;
//	}
//
//	public void setOtherContact(String otherContact) {
//		this.otherContact = otherContact;
//	}
//
//	/*
//	 * --->Income section Getter Setter<---
//	 */
//	public String getMonSalaryIncome() {
//		return monSalaryIncome;
//	}
//
//	public void setMonSalaryIncome(String monSalaryIncome) {
//		this.monSalaryIncome = monSalaryIncome;
//	}
//
//	public String getMonAllowances() {
//		return monAllowances;
//	}
//
//	public void setMonAllowances(String monAllowances) {
//		this.monAllowances = monAllowances;
//	}
//
//	public String getMonTotalIncome() {
//		return monTotalIncome;
//	}
//
//	public void setMonTotalIncome(String monTotalIncome) {
//		this.monTotalIncome = monTotalIncome;
//	}
//
//	public String getSourceOfOtherIncome() {
//		return sourceOfOtherIncome;
//	}
//
//	public void setSourceOfOtherIncome(String sourceOfOtherIncome) {
//		this.sourceOfOtherIncome = sourceOfOtherIncome;
//	}
//
//	public String getSpouseMonthlyIncome() {
//		return spouseMonthlyIncome;
//	}
//
//	public void setSpouseMonthlyIncome(String spouseMonthlyIncome) {
//		this.spouseMonthlyIncome = spouseMonthlyIncome;
//	}
//
//	public String getOthIncomeAvgTurnover() {
//		return othIncomeAvgTurnover;
//	}
//
//	public void setOthIncomeAvgTurnover(String othIncomeAvgTurnover) {
//		this.othIncomeAvgTurnover = othIncomeAvgTurnover;
//	}
//
//	public String getMonRentalIncome() {
//		return monthlyRentalIncome;
//	}
//
//	public void setMonthlyRentalIncome(String monthlyRentalIncome) {
//		this.monthlyRentalIncome = monthlyRentalIncome;
//	}
//
//	public String getMonBizIncome() {
//		return monBizIncome;
//	}
//
//	public void setMonBizIncome(String monBizIncome) {
//		this.monBizIncome = monBizIncome;
//	}
//
//	public String getMonRentUtility() {
//		return monRentUtility;
//	}
//
//	public void setMonRentUtility(String monRentUtility) {
//		this.monRentUtility = monRentUtility;
//	}
//
//	public String getMonFoodExp() {
//		return monFoodExp;
//	}
//
//	public void setMonFoodExp(String monFoodExp) {
//		this.monFoodExp = monFoodExp;
//	}
//
//	public String getMonEduExp() {
//		return monEduExp;
//	}
//
//	public void setMonEduExp(String monEduExp) {
//		this.monEduExp = monEduExp;
//	}
//
//	public String getMonLoanRepay() {
//		return monLoanRepay;
//	}
//
//	public void setMonLoanRepay(String monLoanRepay) {
//		this.monLoanRepay = monLoanRepay;
//	}
//
//	public String getMonOthExp() {
//		return monOthExp;
//	}
//
//	public void setMonOthExp(String monOthExp) {
//		this.monOthExp = monOthExp;
//	}
//
//	public String getMonTotalExp() {
//		return monTotalExp;
//	}
//
//	public void setMonTotalExp(String monTotalExp) {
//		this.monTotalExp = monTotalExp;
//	}
//
//	public String getMonthlyRentalIncome() {
//		return monthlyRentalIncome;
//	}
//
//	public String getEmploymentType() {
//		return employmentType;
//	}
//
//	public void setEmploymentType(String employmentType) {
//		this.employmentType = employmentType;
//	}
//
//	public String getEmploymentStatus() {
//		return employmentStatus;
//	}
//
//	public void setEmploymentStatus(String employmentStatus) {
//		this.employmentStatus = employmentStatus;
//	}
//
//	public String getCompany() {
//		return company;
//	}
//
//	public void setCompany(String company) {
//		this.company = company;
//	}
//
//	public String getBusinessType() {
//		return businessType;
//	}
//
//	public void setBusinessType(String businessType) {
//		this.businessType = businessType;
//	}
//
//	public String getBusinessSetupDate() {
//		return businessSetupDate;
//	}
//
//	public void setBusinessSetupDate(String businessSetupDate) {
//		this.businessSetupDate = businessSetupDate;
//	}
//
//	public String getBusinessOwnership() {
//		return businessOwnership;
//	}
//
//	public void setBusinessOwnership(String businessOwnership) {
//		this.businessOwnership = businessOwnership;
//	}
//
//	public String getOfficePremiseStatus() {
//		return officePremiseStatus;
//	}
//
//	public void setOfficePremiseStatus(String officePremiseStatus) {
//		this.officePremiseStatus = officePremiseStatus;
//	}
//
//	public String getPrevBusinessName() {
//		return prevBusinessName;
//	}
//
//	public void setPrevBusinessName(String prevBusinessName) {
//		this.prevBusinessName = prevBusinessName;
//	}
//
//	public String getTotalLengthCurrBizYears() {
//		return totalLengthCurrBizYears;
//	}
//
//	public void setTotalLengthCurrBizYears(String totalLengthCurrBizYears) {
//		this.totalLengthCurrBizYears = totalLengthCurrBizYears;
//	}
//
//	public String getTotalLengthCurrBizMonths() {
//		return totalLengthCurrBizMonths;
//	}
//
//	public void setTotalLengthCurrBizMonths(String totalLengthCurrBizMonths) {
//		this.totalLengthCurrBizMonths = totalLengthCurrBizMonths;
//	}
//
//	public String getTotalBizExpYears() {
//		return totalBizExpYears;
//	}
//
//	public void setTotalBizExpYears(String totalBizExpYears) {
//		this.totalBizExpYears = totalBizExpYears;
//	}
//
//	public String getTotalBizExpMonths() {
//		return totalBizExpMonths;
//	}
//
//	public void setTotalBizExpMonths(String totalBizExpMonths) {
//		this.totalBizExpMonths = totalBizExpMonths;
//	}
//
//	public String getProfession() {
//		return profession;
//	}
//
//	public void setProfession(String profession) {
//		this.profession = profession;
//	}
//
//	public String getDesignation() {
//		return designation;
//	}
//
//	public void setDesignation(String designation) {
//		this.designation = designation;
//	}
//
//	public String getEmployerCode() {
//		return employerCode;
//	}
//
//	public void setEmployerCode(String employerCode) {
//		this.employerCode = employerCode;
//	}
//
//	public String getEmployeeStaffId() {
//		return employeeStaffId;
//	}
//
//	public void setEmployeeStaffId(String employeeStaffId) {
//		this.employeeStaffId = employeeStaffId;
//	}
//
//	public String getTotalCurrEmpYears() {
//		return totalCurrEmpYears;
//	}
//
//	public void setTotalCurrEmpYears(String totalCurrEmpYears) {
//		this.totalCurrEmpYears = totalCurrEmpYears;
//	}
//
//	public String getTotalCurrEmpMonths() {
//		return totalCurrEmpMonths;
//	}
//
//	public void setTotalCurrEmpMonths(String totalCurrEmpMonths) {
//		this.totalCurrEmpMonths = totalCurrEmpMonths;
//	}
//
//	public String getTotalLengthOfEmploymentYears() {
//		return totalLengthOfEmploymentYears;
//	}
//
//	public void setTotalLengthOfEmploymentYears(
//			String totalLengthOfEmploymentYears) {
//		this.totalLengthOfEmploymentYears = totalLengthOfEmploymentYears;
//	}
//
//	public String getTotalLengthOfEmploymentMonths() {
//		return totalLengthOfEmploymentMonths;
//	}
//
//	public void setTotalLengthOfEmploymentMonths(
//			String totalLengthOfEmploymentMonths) {
//		this.totalLengthOfEmploymentMonths = totalLengthOfEmploymentMonths;
//	}
//
//	public String getNameOfPrevEmployer() {
//		return nameOfPrevEmployer;
//	}
//
//	public void setNameOfPrevEmployer(String nameOfPrevEmployer) {
//		this.nameOfPrevEmployer = nameOfPrevEmployer;
//	}
//
//	public String getTotalPrevEmpYears() {
//		return totalPrevEmpYears;
//	}
//
//	public void setTotalPrevEmpYears(String totalPrevEmpYears) {
//		this.totalPrevEmpYears = totalPrevEmpYears;
//	}
//
//	public String getTotalPrevEmpMonths() {
//		return totalPrevEmpMonths;
//	}
//
//	public void setTotalPrevEmpMonths(String totalPrevEmpMonths) {
//		this.totalPrevEmpMonths = totalPrevEmpMonths;
//	}
//
//	public String getChequeBookRequiredCa() {
//		return chequeBookRequiredCa;
//	}
//
//	public void setChequeBookRequiredCa(String chequeBookRequiredCa) {
//		this.chequeBookRequiredCa = chequeBookRequiredCa;
//	}
//
//	public String getChequeBookTypeCa() {
//		return chequeBookTypeCa;
//	}
//
//	public void setChequeBookTypeCa(String chequeBookTypeCa) {
//		this.chequeBookTypeCa = chequeBookTypeCa;
//	}
//
//	public String getRequiredAtmDebitCard() {
//		return requiredAtmDebitCard;
//	}
//
//	public void setRequiredAtmDebitCard(String requiredAtmDebitCard) {
//		this.requiredAtmDebitCard = requiredAtmDebitCard;
//	}
//
//	public String getAccountLinksToDebitCardAtm() {
//		return accountLinksToDebitCardAtm;
//	}
//
//	public void setAccountLinksToDebitCardAtm(String accountLinksToDebitCardAtm) {
//		this.accountLinksToDebitCardAtm = accountLinksToDebitCardAtm;
//	}
//
//	public String getInternetBanking() {
//		return internetBanking;
//	}
//
//	public void setInternetBanking(String internetBanking) {
//		this.internetBanking = internetBanking;
//	}
//
//	public String getSmsAlerts() {
//		return smsAlerts;
//	}
//
//	public void setSmsAlerts(String smsAlerts) {
//		this.smsAlerts = smsAlerts;
//	}
//
//	public String geteStatementCasa() {
//		return eStatementCasa;
//	}
//
//	public void seteStatementCasa(String eStatementCasa) {
//		this.eStatementCasa = eStatementCasa;
//	}
//
//	public String getEeStatementTypeCasa() {
//		return EeStatementTypeCasa;
//	}
//
//	public void setEeStatementTypeCasa(String eeStatementTypeCasa) {
//		EeStatementTypeCasa = eeStatementTypeCasa;
//	}
//
//	public String getStatementHardcopyCasa() {
//		return statementHardcopyCasa;
//	}
//
//	public void setStatementHardcopyCasa(String statementHardcopyCasa) {
//		this.statementHardcopyCasa = statementHardcopyCasa;
//	}
//
//	public String getStatementFrequencyCasa() {
//		return statementFrequencyCasa;
//	}
//
//	public void setStatementFrequencyCasa(String statementFrequencyCasa) {
//		this.statementFrequencyCasa = statementFrequencyCasa;
//	}
//
//	public String geteStatementCreditCard() {
//		return eStatementCreditCard;
//	}
//
//	public void seteStatementCreditCard(String eStatementCreditCard) {
//		this.eStatementCreditCard = eStatementCreditCard;
//	}
//
//	public String geteStatementTypeCreditCard() {
//		return eStatementTypeCreditCard;
//	}
//
//	public void seteStatementTypeCreditCard(String eStatementTypeCreditCard) {
//		this.eStatementTypeCreditCard = eStatementTypeCreditCard;
//	}
//
//	public String getStatementHardcopyCreditCard() {
//		return statementHardcopyCreditCard;
//	}
//
//	public void setStatementHardcopyCreditCard(String statementHardcopyCreditCard) {
//		this.statementHardcopyCreditCard = statementHardcopyCreditCard;
//	}
//
//	public String getStatementFrequencyCreditCard() {
//		return statementFrequencyCreditCard;
//	}
//
//	public void setStatementFrequencyCreditCard(String statementFrequencyCreditCard) {
//		this.statementFrequencyCreditCard = statementFrequencyCreditCard;
//	}
//
//	public String getNoNominee() {
//		return noNominee;
//	}
//
//	public void setNoNominee(String noNominee) {
//		this.noNominee = noNominee;
//	}
//
//	public String getNomName1() {
//		return nomName1;
//	}
//
//	public void setNomName1(String nomName1) {
//		this.nomName1 = nomName1;
//	}
//
//	public String getPercent1() {
//		return percent1;
//	}
//
//	public void setPercent1(String percent1) {
//		this.percent1 = percent1;
//	}
//
//	public String getNomName2() {
//		return nomName2;
//	}
//
//	public void setNomName2(String nomName2) {
//		this.nomName2 = nomName2;
//	}
//
//	public String getPercent2() {
//		return percent2;
//	}
//
//	public void setPercent2(String percent2) {
//		this.percent2 = percent2;
//	}
//
//	public String getNomName3() {
//		return nomName3;
//	}
//
//	public void setNomName3(String nomName3) {
//		this.nomName3 = nomName3;
//	}
//
//	public String getPercent3() {
//		return percent3;
//	}
//
//	public void setPercent3(String percent3) {
//		this.percent3 = percent3;
//	}
//
//	public String getBankName1() {
//		return bankName1;
//	}
//
//	public void setBankName1(String bankName1) {
//		this.bankName1 = bankName1;
//	}
//
//	public String getBranch1() {
//		return branch1;
//	}
//
//	public void setBranch1(String branch1) {
//		this.branch1 = branch1;
//	}
//
//	public String getTypeAccount1() {
//		return typeAccount1;
//	}
//
//	public void setTypeAccount1(String typeAccount1) {
//		this.typeAccount1 = typeAccount1;
//	}
//
//	public String getAccountCardno1() {
//		return accountCardno1;
//	}
//
//	public void setAccountCardno1(String accountCardno1) {
//		this.accountCardno1 = accountCardno1;
//	}
//
//	public String getCreditLoan1() {
//		return creditLoan1;
//	}
//
//	public void setCreditLoan1(String creditLoan1) {
//		this.creditLoan1 = creditLoan1;
//	}
//
//	public String getOutstandingAmt1() {
//		return outstandingAmt1;
//	}
//
//	public void setOutstandingAmt1(String outstandingAmt1) {
//		this.outstandingAmt1 = outstandingAmt1;
//	}
//
//	public String getInstalamt1() {
//		return instalamt1;
//	}
//
//	public void setInstalamt1(String instalamt1) {
//		this.instalamt1 = instalamt1;
//	}
//
//	public String getCardMemberSince1() {
//		return cardMemberSince1;
//	}
//
//	public void setCardMemberSince1(String cardMemberSince1) {
//		this.cardMemberSince1 = cardMemberSince1;
//	}
//
//	public String getBankName2() {
//		return bankName2;
//	}
//
//	public void setBankName2(String bankName2) {
//		this.bankName2 = bankName2;
//	}
//
//	public String getBranch2() {
//		return branch2;
//	}
//
//	public void setBranch2(String branch2) {
//		this.branch2 = branch2;
//	}
//
//	public String getTypeAccount2() {
//		return typeAccount2;
//	}
//
//	public void setTypeAccount2(String typeAccount2) {
//		this.typeAccount2 = typeAccount2;
//	}
//
//	public String getAccountCardno2() {
//		return accountCardno2;
//	}
//
//	public void setAccountCardno2(String accountCardno2) {
//		this.accountCardno2 = accountCardno2;
//	}
//
//	public String getCreditLoan2() {
//		return creditLoan2;
//	}
//
//	public void setCreditLoan2(String creditLoan2) {
//		this.creditLoan2 = creditLoan2;
//	}
//
//	public String getOutstandingAmt2() {
//		return outstandingAmt2;
//	}
//
//	public void setOutstandingAmt2(String outstandingAmt2) {
//		this.outstandingAmt2 = outstandingAmt2;
//	}
//
//	public String getInstalAmt2() {
//		return instalAmt2;
//	}
//
//	public void setInstalAmt2(String instalAmt2) {
//		this.instalAmt2 = instalAmt2;
//	}
//
//	public String getCardMemberSince2() {
//		return cardMemberSince2;
//	}
//
//	public void setCardMemberSince2(String cardMemberSince2) {
//		this.cardMemberSince2 = cardMemberSince2;
//	}
//
//	public String getBankName3() {
//		return bankName3;
//	}
//
//	public void setBankName3(String bankName3) {
//		this.bankName3 = bankName3;
//	}
//
//	public String getBranch3() {
//		return branch3;
//	}
//
//	public void setBranch3(String branch3) {
//		this.branch3 = branch3;
//	}
//
//	public String getTypeAccount3() {
//		return typeAccount3;
//	}
//
//	public void setTypeAccount3(String typeAccount3) {
//		this.typeAccount3 = typeAccount3;
//	}
//
//	public String getAccountCardno3() {
//		return accountCardno3;
//	}
//
//	public void setAccountCardno3(String accountCardno3) {
//		this.accountCardno3 = accountCardno3;
//	}
//
//	public String getCreditLoan3() {
//		return creditLoan3;
//	}
//
//	public void setCreditLoan3(String creditLoan3) {
//		this.creditLoan3 = creditLoan3;
//	}
//
//	public String getOutsSandingamt3() {
//		return outsSandingamt3;
//	}
//
//	public void setOutsSandingamt3(String outsSandingamt3) {
//		this.outsSandingamt3 = outsSandingamt3;
//	}
//
//	public String getInstalAmt3() {
//		return instalAmt3;
//	}
//
//	public void setInstalAmt3(String instalAmt3) {
//		this.instalAmt3 = instalAmt3;
//	}
//
//	public String getCardMemberSince3() {
//		return cardMemberSince3;
//	}
//
//	public void setCardMemberSince3(String cardMemberSince3) {
//		this.cardMemberSince3 = cardMemberSince3;
//	}
//
//	public String getLoanRelatedcCient() {
//		return loanRelatedcCient;
//	}
//
//	public void setLoanRelatedcCient(String loanRelatedcCient) {
//		this.loanRelatedcCient = loanRelatedcCient;
//	}
//
//	public String getAccountNo() {
//		return accountNo;
//	}
//
//	public void setAccountNo(String accountNo) {
//		this.accountNo = accountNo;
//	}
//
//	public String getCreditcardEmbossedName() {
//		return creditcardEmbossedName;
//	}
//
//	public void setCreditcardEmbossedName(String creditcardEmbossedName) {
//		this.creditcardEmbossedName = creditcardEmbossedName;
//	}
//
//	public String getCardDeliveryAddType() {
//		return cardDeliveryAddType;
//	}
//
//	public void setCardDeliveryAddType(String cardDeliveryAddType) {
//		this.cardDeliveryAddType = cardDeliveryAddType;
//	}
//
//	public String getCardCollectionBranch() {
//		return cardCollectionBranch;
//	}
//
//	public void setCardCollectionBranch(String cardCollectionBranch) {
//		this.cardCollectionBranch = cardCollectionBranch;
//	}
//
//	public String getLoanAmount() {
//		return loanAmount;
//	}
//
//	public void setLoanAmount(String loanAmount) {
//		this.loanAmount = loanAmount;
//	}
//
//	public String getTermMonths() {
//		return termMonths;
//	}
//
//	public void setTermMonths(String termMonths) {
//		this.termMonths = termMonths;
//	}
//
//	public String getCurrency() {
//		return currency;
//	}
//
//	public void setCurrency(String currency) {
//		this.currency = currency;
//	}
//
//	public String getPreferredBranch() {
//		return preferredBranch;
//	}
//
//	public void setPreferredBranch(String preferredBranch) {
//		this.preferredBranch = preferredBranch;
//	}
//
//	public String getLoanDisbaAcountno() {
//		return loanDisbaAcountno;
//	}
//
//	public void setLoanDisbaAcountno(String loanDisbaAcountno) {
//		this.loanDisbaAcountno = loanDisbaAcountno;
//	}
//
//	public String getInterestrateodFacility() {
//		return interestrateodFacility;
//	}
//
//	public void setInterestrateodFacility(String interestrateodFacility) {
//		this.interestrateodFacility = interestrateodFacility;
//	}
//
//	public String getDirectorotherBanks() {
//		return directorotherBanks;
//	}
//
//	public void setDirectorotherBanks(String directorotherBanks) {
//		this.directorotherBanks = directorotherBanks;
//	}
//
//	public String getAoForBusinessPuspose() {
//		return aoForBusinessPuspose;
//	}
//
//	public void setAoForBusinessPuspose(String aoForBusinessPuspose) {
//		this.aoForBusinessPuspose = aoForBusinessPuspose;
//	}
//
//	public String getPurposeAccOpen() {
//		return purposeAccOpen;
//	}
//
//	public void setPurposeAccOpen(String purposeAccOpen) {
//		this.purposeAccOpen = purposeAccOpen;
//	}
//
//	public String getPurposeOthersSpecify() {
//		return purposeOthersSpecify;
//	}
//
//	public void setPurposeOthersSpecify(String purposeOthersSpecify) {
//		this.purposeOthersSpecify = purposeOthersSpecify;
//	}
//
//	public String getDepositAmountUsd() {
//		return depositAmountUsd;
//	}
//
//	public void setDepositAmountUsd(String depositAmountUsd) {
//		this.depositAmountUsd = depositAmountUsd;
//	}
//
//	public String getModeOfInitialFundsDeposit() {
//		return modeOfInitialFundsDeposit;
//	}
//
//	public void setModeOfInitialFundsDeposit(String modeOfInitialFundsDeposit) {
//		this.modeOfInitialFundsDeposit = modeOfInitialFundsDeposit;
//	}
//
//	public String getDerWealthFromSanctionedCountries() {
//		return derWealthFromSanctionedCountries;
//	}
//
//	public void setDerWealthFromSanctionedCountries(
//			String derWealthFromSanctionedCountries) {
//		this.derWealthFromSanctionedCountries = derWealthFromSanctionedCountries;
//	}
//
//	public String getSavingsNetWorthUsd() {
//		return savingsNetWorthUsd;
//	}
//
//	public void setSavingsNetWorthUsd(String savingsNetWorthUsd) {
//		this.savingsNetWorthUsd = savingsNetWorthUsd;
//	}
//
//	public String getSourceOfWealth() {
//		return sourceOfWealth;
//	}
//
//	public void setSourceOfWealth(String sourceOfWealth) {
//		this.sourceOfWealth = sourceOfWealth;
//	}
//
//	public String getSsourceFundSpecify() {
//		return SsourceFundSpecify;
//	}
//
//	public void setSsourceFundSpecify(String ssourceFundSpecify) {
//		SsourceFundSpecify = ssourceFundSpecify;
//	}
//
//	public String getUsResidentFlag() {
//		return usResidentFlag;
//	}
//
//	public void setUsResidentFlag(String usResidentFlag) {
//		this.usResidentFlag = usResidentFlag;
//	}
//
//	public String getsCitizenFlag() {
//		return sCitizenFlag;
//	}
//
//	public void setsCitizenFlag(String sCitizenFlag) {
//		this.sCitizenFlag = sCitizenFlag;
//	}
//
//	public String getPrFlag() {
//		return prFlag;
//	}
//
//	public void setPrFlag(String prFlag) {
//		this.prFlag = prFlag;
//	}
//
//	public String getConfirmation() {
//		return confirmation;
//	}
//
//	public void setConfirmation(String confirmation) {
//		this.confirmation = confirmation;
//	}
//
//	public String getNbArmCode() {
//		return nbArmCode;
//	}
//
//	public void setNbArmCode(String nbArmCode) {
//		this.nbArmCode = nbArmCode;
//	}
//
//	public String getInstitutionClassification() {
//		return institutionClassification;
//	}
//
//	public void setInstitutionClassification(String institutionClassification) {
//		this.institutionClassification = institutionClassification;
//	}
//
//	public String getRelationshipNo() {
//		return relationshipNo;
//	}
//
//	public void setRelationshipNo(String relationshipNo) {
//		this.relationshipNo = relationshipNo;
//	}
//
//	public String getLocationDhaka() {
//		return locationDhaka;
//	}
//
//	public void setLocationDhaka(String locationDhaka) {
//		this.locationDhaka = locationDhaka;
//	}
//
//	public String getAcqChannelCode() {
//		return acqChannelCode;
//	}
//
//	public void setAcqChannelCode(String acqChannelCode) {
//		this.acqChannelCode = acqChannelCode;
//	}
//
//	public String getPreApprOffer() {
//		return preApprOffer;
//	}
//
//	public void setPreApprOffer(String preApprOffer) {
//		this.preApprOffer = preApprOffer;
//	}
//
//	public String getPreApprOfferDetails() {
//		return preApprOfferDetails;
//	}
//
//	public void setPreApprOfferDetails(String preApprOfferDetails) {
//		this.preApprOfferDetails = preApprOfferDetails;
//	}
//
//	public String getPreApprOfferIdNo() {
//		return preApprOfferIdNo;
//	}
//
//	public void setPreApprOfferIdNo(String preApprOfferIdNo) {
//		this.preApprOfferIdNo = preApprOfferIdNo;
//	}
//
//	public String getDseCode() {
//		return dseCode;
//	}
//
//	public void setDseCode(String dseCode) {
//		this.dseCode = dseCode;
//	}
//
//	public String getSegment() {
//		return segment;
//	}
//
//	public void setSegment(String segment) {
//		this.segment = segment;
//	}
//
//	public String getSubSegment() {
//		return subSegment;
//	}
//
//	public void setSubSegment(String subSegment) {
//		this.subSegment = subSegment;
//	}
//
//	public String getPlSegment() {
//		return plSegment;
//	}
//
//	public void setPlSegment(String plSegment) {
//		this.plSegment = plSegment;
//	}
//
//	public String getArea() {
//		return area;
//	}
//
//	public void setArea(String area) {
//		this.area = area;
//	}
//
//	public String getArmCode() {
//		return armCode;
//	}
//
//	public void setArmCode(String armCode) {
//		this.armCode = armCode;
//	}
//
//	public String getCampaignCode() {
//		return campaignCode;
//	}
//
//	public void setCampaignCode(String campaignCode) {
//		this.campaignCode = campaignCode;
//	}
//
//	public String getDeviationLevel() {
//		return deviationLevel;
//	}
//
//	public void setDeviationLevel(String deviationLevel) {
//		this.deviationLevel = deviationLevel;
//	}
//
//	public String getLoanNo() {
//		return loanNo;
//	}
//
//	public void setLoanNo(String loanNo) {
//		this.loanNo = loanNo;
//	}
//
//	public String getMasterNo() {
//		return masterNo;
//	}
//
//	public void setMasterNo(String masterNo) {
//		this.masterNo = masterNo;
//	}
//
//	public String getPayrollIndicator() {
//		return payrollIndicator;
//	}
//
//	public void setPayrollIndicator(String payrollIndicator) {
//		this.payrollIndicator = payrollIndicator;
//	}
//
//	public String getSpotApproval() {
//		return spotApproval;
//	}
//
//	public void setSpotApproval(String spotApproval) {
//		this.spotApproval = spotApproval;
//	}
//
//	public String getTopUp() {
//		return topUp;
//	}
//
//	public void setTopUp(String topUp) {
//		this.topUp = topUp;
//	}
//
//	public String getCibReportFetching() {
//		return cibReportFetching;
//	}
//
//	public void setCibReportFetching(String cibReportFetching) {
//		this.cibReportFetching = cibReportFetching;
//	}
//
//	public String getForwardedBy() {
//		return forwardedBy;
//	}
//
//	public void setForwardedBy(String forwardedBy) {
//		this.forwardedBy = forwardedBy;
//	}
//
//	public String getReferralCode() {
//		return referralCode;
//	}
//
//	public void setReferralCode(String referralCode) {
//		this.referralCode = referralCode;
//	}
//
//	public String getSalesStaffDesignation() {
//		return salesStaffDesignation;
//	}
//
//	public void setSalesStaffDesignation(String salesStaffDesignation) {
//		this.salesStaffDesignation = salesStaffDesignation;
//	}
//
//	public String getReferenceNoCampaign() {
//		return referenceNoCampaign;
//	}
//
//	public void setReferenceNoCampaign(String referenceNoCampaign) {
//		this.referenceNoCampaign = referenceNoCampaign;
//	}
//
//}
