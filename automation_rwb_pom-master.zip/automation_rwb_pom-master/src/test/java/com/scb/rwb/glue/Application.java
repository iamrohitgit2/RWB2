package com.scb.rwb.glue;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javassist.bytecode.stackmap.TypeData.ClassName;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static org.hamcrest.CoreMatchers.*;

import com.scb.rwb.appium.pages.AOFPage;
import com.scb.rwb.appium.pages.ApplicationQueuesPage;
import com.scb.rwb.appium.pages.ApplicationSubmitSucessfulPage;
import com.scb.rwb.appium.pages.DashboardPage;
import com.scb.rwb.wrappers.ApplicationWrappers;
import com.standardchartered.genie.FrameworkGlue;
import com.standardchartered.genie.TestDriver; 
public class Application extends ApplicationWrappers {
	
	WebDriverWait wait = new WebDriverWait(wd, 30);
	public  WebDriver driver;
	
	@Then("^Application should be submitted$")
	public void application_should_be_submitted() throws Throwable {	
		new ApplicationSubmitSucessfulPage().verifyStatusOfApplication();
	}

	
	@When("^I navigate back to home screen$")
	public void i_navigate_back_to_home_screen(){
		new ApplicationSubmitSucessfulPage().navigatetoHomePage();
	}
	
	
	@When("^I go to Application Queues$")
	public void i_go_to_Application_Queues() throws Throwable {
		new DashboardPage().clickApplication();
	}

	
	@Then("^I should see submitted application in \"(.*?)\" queue$")
	public void i_should_see_submitted_application_in_queue(String queuename) throws Throwable {
		new ApplicationQueuesPage().checkSubmittedApplicationInQueue(queuename);    
	}
	
	
	@Then("^I should be able to view incomplete pendingsubmission error and returnqueues sections$")
	public void i_should_be_able_to_view_incomplete_pendingsubmission_error_and_returnqueues_sections() throws Throwable {
		new ApplicationQueuesPage().verifyColumns();
	}
	
	
	@When("^I navigate back to home screen from Queues$")
	public void i_navigate_back_to_home_screen_from_Queues() throws Throwable {
		new ApplicationQueuesPage().navigateToHomeScreen();
	}
	
	
	@When("^I click application$")
	public void i_click_from_Queues() throws Throwable {	
		 List<WebElement> applicationsList = wd.findElementsByCssSelector(".appNumber");
			for ( WebElement element : applicationsList ) {
				System.out.println(element.getText());
				if ((TestData.applicationId).equalsIgnoreCase(element.getText()))
				{
				    Thread.sleep(5000);
					element.click();
					Thread.sleep(50000);
					break; 
				}
			}
	} 
	
	
	@When("^I click application in Ipad$")
	public void i_click_application_in_Ipad() throws Throwable {
		System.out.println("app no is :"+TestData.applicationId);
		 List<WebElement> applicationsList = wd.findElementsByCssSelector(".search-app-number a");
		 System.out.println("check 1....");
			for ( WebElement element : applicationsList ) {
				System.out.println("check 2 ...");
				System.out.println(element.getText());
				if ((TestData.applicationId).equalsIgnoreCase(element.getText()))
				{
					element.click();
					Thread.sleep(20000);
					break; 
				}
			}
	}
	
	
	@Then("^I click the reject button along with notes$")
	public void i_click_the_reject_button_along_with_notes() throws Throwable {
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Assert.assertTrue(wd.findElement(By.xpath("//span[@class='application-rmreject']")).isDisplayed()); // added by me
		wd.findElement(By.xpath("//span[@class='application-rmreject']")).click();
		Set<String>Availablecontext=wd.getContextHandles();
		for(String context: Availablecontext)
		{
			if(context.contains("WEBVIEW"))
				wd.context(context);
		}
		Boolean Rejectbutton = false; 
		Rejectbutton = wd.findElement(By.id("button-ok")).isEnabled();
		if (Rejectbutton = false)
		{

			System.out.println("Reject Button Enabled status before Enter value" + Rejectbutton);
			
		}	
		wd.findElement(By.xpath("//textarea[@placeholder='Add a note here.']")).sendKeys("Automated notes"+RandomStringUtils.randomNumeric(2));

		Thread.sleep(2000);
		Rejectbutton = wd.findElement(By.id("button-ok")).isEnabled();
		if (Rejectbutton = true)
		{
			System.out.println("Reject Button Enabled status After enter value" + Rejectbutton);
		}		
		wd.findElement(By.id("button-ok")).click();	
		Thread.sleep(10000);
		
	}

	
	@And("^I click on view button$")
	public void i_click_on_view_button() throws Throwable 
	{
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		wd.findElement(By.xpath("//div[@class='add-doc reply-btn']")).click();
		
	}
	
	
	@When("^I click on application in ipad Master Queue$")
	public void i_click_on_application_in_ipad_Master_Queue() throws Throwable 
	{
		wd.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);

		 Thread.sleep(10000);
		boolean Application_present= false;
		List<WebElement> elements = wd.findElementsByCssSelector(".search-result-table-row");
		
		String AppID = wd.findElement(By.linkText("8HFQU5CMK2")).getText();
		 
		  System.out.println(AppID);
		
		  Iterator<WebElement> itr1 = elements.iterator();
		  itr1.next();
			
		  while(itr1.hasNext()) 
		  {
			  WebElement Approw = itr1.next();
			  Thread.sleep(3000);
			  System.out.println("ID from Application"+AppID);
			  System.out.println("ID from TestData"+TestData.applicationId);

	        if (AppID.equalsIgnoreCase(TestData.applicationId))
	        {
	       ((JavascriptExecutor) wd).executeScript("document.getElementsByClassName('search-app-number')[0].getElementsByTagName('a')[0].click()");
	        	 break;
	        }
	        
	       
		 }
		 if(!Application_present)
			{
			  throw new RuntimeException(TestData.applicationId + " in the search result");
			}	    
	}
	
	
	@And("^I  should check same text format in Coding return notes as \"(.*?)\"$")
	public void i_should_check_same_text_format_in_Coding_return_notes_as(String ExpectedCodingRetunNotes) throws Throwable 
	
	{
		Thread.sleep(1000);
		String CodingRetunNotes = wd.findElement(By.xpath("//p[@class='message']")).getText();
		if (CodingRetunNotes.equalsIgnoreCase(ExpectedCodingRetunNotes))
				{
					System.out.println("Coding return notes text format got matched" + CodingRetunNotes);
				}
	}

	
	@And("^I close the notes popup$")
	public void i_close_the_notes_popup() throws Throwable 
	{
		Thread.sleep(3000);
		wd.findElement(By.cssSelector("#primary-modals .modal---close-button .icon-close")).click();	
	}
	
	
	
	@When("^I should check the remaining character count is displayed bottom of the notes after typing Nine Hundred as \"(.*?)\"$")
	public void i_should_check_the_remaining_character_count_is_displayed_bottom_of_the_notes_after_typing_Nine_Hundred_as(String NotesDescription) throws Throwable 
	{
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Set<String>Availablecontext=wd.getContextHandles();
		for(String context: Availablecontext)
		{
			if(context.contains("WEBVIEW"))
				wd.context(context);
		}		
	wd.findElement(By.xpath("//textarea[@placeholder='Add a note here.']")).sendKeys(NotesDescription+RandomStringUtils.randomNumeric(2));
	
	String RemainingCharCount = wd.findElementByClassName("display-count").getText();
	assertTrue (wd.findElementByClassName("display-count").getText().contains("Characters Remaining"));	
	}
	
	
	@Then("^I should be able to see created application number$")
	public void i_should_be_able_to_see_created_application_number() throws Throwable {
		Thread.sleep(5000);
		new DashboardPage().verifyCreatedApplicationNumber();
	}
	
	
	@Then("^I should be able to see created application number with rejected status$")
	public void i_should_be_able_to_see_created_application_number_with_rejected_status() throws Throwable {
		Thread.sleep(5000);
		 wd.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		Assert.assertTrue(wd.findElementByName("Select applications below to move to server").isDisplayed()); // added by me
		wd.findElementByName(TestData.applicationId); 
		if(wd.findElementByName("icon medium rejected").isDisplayed())
		  System.out.println("Reject status icon is displaying in app sync screen");
	}
	
	
	@Then("^Get Table contents$")
	public void gtc() throws Throwable {
		Thread.sleep(10000);
		System.out.println(wd.findElementsByClassName("UIATableView").size());
		MobileElement table = (MobileElement) wd.findElementsByClassName("UIATableView").get(3);
		System.out.println(table.getSize());
		System.out.println(table.getText());
		System.out.println(table.getAttribute("value"));
		MobileElement row =  table.findElementByName("3EAABG94NY");
		// MobileElement row = table.findElementByXPath("//UIATableCell[contains(@name,'3EAABG94NY')]");
		 MobileElement a = row.findElementsByClassName("UIAButton").get(1);
		System.out.println(a.getAttribute("name"));
		 wd.findElementByName("3EAABG94NY");
		wd.findElementByXPath("//UIATableCell[contains(@name,'3EAABG94NY')]").findElement(By.name("pending@3x"));
	}
	
	
	@Then("^Application should be resumed$")
	public void application_should_be_resumed() throws Throwable {
	   System.out.println("waiting to resume application");
	   wait.until(ExpectedConditions.visibilityOf(wd.findElement(By.cssSelector(".commitment-forms .sc-form"))));
	   System.out.println("Application resumed application");
	}
	
	
	@When("^I Enter more than thousand character as \"(.*?)\"$")
	public void i_Enter_more_than_thousand_character_as(String MorethanThousand) throws Throwable 
	{
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Set<String>Availablecontext=wd.getContextHandles();
		for(String context: Availablecontext)
		{
			if(context.contains("WEBVIEW"))
				wd.context(context);
		}		
	wd.findElement(By.xpath("//textarea[@placeholder='Add a note here.']")).sendKeys(MorethanThousand+RandomStringUtils.randomNumeric(2));
		
	}

	
	@Then("^I Should see remaining character Count is \"(.*?)\"$")
	public void i_Should_see_remaining_character_Count_is(String arg1) throws Throwable 
	{
		String RemainingCharCountZero = wd.findElementByClassName("display-count").getText();
		Assert.assertEquals(RemainingCharCountZero,"0 Characters Remaining");
		
	}
	
	
	@Then("^I switch to documents section$")
	public void i_switch_to_documents_section() throws Throwable {
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Set<String>Availablecontext=wd.getContextHandles();
		for(String context: Availablecontext)
		{
			if(context.contains("WEBVIEW"))
				wd.context(context);
		}
	     
		Assert.assertTrue(wd.findElement(By.xpath("//a[contains(text(),'Documents')]")).isDisplayed());  // added by me
		wd.findElement(By.xpath("//a[contains(text(),'Documents')]")).click();
		Thread.sleep(30000);
	}

	
	@Then("^I click the resubmit button along with notes$")
	public void i_click_the_resubmit_button() throws Throwable {
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(4000);
		Assert.assertTrue(wd.findElement(By.className("document-resubmit")).isDisplayed()); // added by me
		wd.findElement(By.xpath("//span[@class='document-resubmit']")).click();
		Set<String>Availablecontext=wd.getContextHandles();
		for(String context: Availablecontext)
		{
			if(context.contains("WEBVIEW"))
				wd.context(context);
		}
		Thread.sleep(2000);
		wd.findElementByXPath("//textarea[@class='ember-view ember-text-area']").sendKeys("Automated notes"+RandomStringUtils.randomNumeric(2));
		Thread.sleep(2000);
		wd.findElement(By.id("button-ok")).click();
		Thread.sleep(80000);
	}

	
	/**Module- Ipad error queue check [Release-2]
	 **Verifying the Error application status and master appplication view in Ipad
	 * 
	 */ 
	@Then("^I should see the application \"(.*?)\" in error queue$")
	public void i_should_see_the_application_in_error_queue(String appid) throws Throwable {
		wd.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
	    String queuename = "Error";
		System.out.println(queuename);
	    Set<String> AvailableContexts = wd.getContextHandles();
	    for (String context : AvailableContexts)
		{
			if(context.contains("WEBVIEW"))
				wd.context(context);
		}
	    Thread.sleep(4000);
	    wait.until(ExpectedConditions.visibilityOf(wd.findElementByCssSelector("."+queuename.replace(" ", "-").toLowerCase()+"").findElement(By.cssSelector(".app-status-number"))));
	    wd.findElementByCssSelector("."+queuename.replace(" ", "-").toLowerCase()+"").findElement(By.cssSelector(".app-status-number")).click();
	    
	    boolean applicationPresent= false;
	    assertTrue( wd.findElementByCssSelector(".active").getText().equalsIgnoreCase(queuename));
	    wd.findElementByCssSelector(".app-queue-table-row");
	    
	    assertTrue( wd.findElementByXPath("//div[@class='ember-view app-queue-table-row app-product']/div[1]").getText().equalsIgnoreCase("APP NUMBER"));
	    assertTrue( wd.findElementByXPath("//div[@class='ember-view app-queue-table-row app-product']/div[2]").getText().equalsIgnoreCase("CLIENT"));
	    assertTrue( wd.findElementByXPath("//div[@class='ember-view app-queue-table-row app-product']/div[3]").getText().equalsIgnoreCase("PRODUCTS"));
	    
	    System.out.println("APPNO CLIENT PRODUCTS fields are displaying");
	    
	    System.out.println(appid);
	    
	    List<WebElement> applicationsList = wd.findElementsByCssSelector(".appNumber");
	    Thread.sleep(3000);
		for ( WebElement element : applicationsList ) {
			System.out.println(element.getText());
			if ((appid).equalsIgnoreCase(element.getText()))
			{
				//element.click();
				applicationPresent= true;
				break;
			}
		}
		if (!applicationPresent)
			throw new RuntimeException(TestData.applicationId + " not found in the queue");
	}   
		
	
	/**Module- Ipad error queue check [Release-2]
	**Verifying the Error application status and master appplication view in Ipad
	*/
	@When("^I tap on the error application \"(.*?)\"$")
	public void i_tap_on_the_error_application(String appno) throws Throwable {
		System.out.println("app no is :"+appno);
		List<WebElement> applicationsList = wd.findElementsByCssSelector(".app-queue-table-row .app-number");
		for ( WebElement element : applicationsList ) {
				System.out.println(element.getText());
				if ((appno).equalsIgnoreCase(element.getText()))
				{
					element.click();
					Thread.sleep(20000);
					break; 
				}
			}
	}
	
	
	/**Module- Ipad error queue check [Release-2]
	**Verifying the Error application status and master appplication view in Ipad
	*/
	@Then("^I should be able view the application status as Error for \"(.*?)\"$")
	public void i_should_be_able_view_the_application_status_as_Error(String appno) throws Throwable {
		Thread.sleep(10000);
		wait.until(ExpectedConditions.visibilityOf(wd.findElementByClassName(("application-master"))));	
		System.out.println("Master app view is displayed for error application");
		
		
		Thread.sleep(3000);
		WebElement element2 = wait.until(ExpectedConditions
				.elementToBeClickable(By.cssSelector(".app-info div")));
		element2.click();
		Thread.sleep(3000);
        String expecappno=wd.findElementByXPath("//div[@class='tooltipster-content']/descendant::div[@class='tooltip-app-number']/span[2]").getText();
		
		System.out.println("expapp no "+expecappno); //
		
		assertTrue(wd.findElementByXPath("//div[@class='tooltipster-content']/descendant::div[@class='tooltip-app-number']/span[2]").getText().equalsIgnoreCase(appno));
		assertTrue(wd.findElementByClassName("client-name").isDisplayed());
		System.out.println("App number and client details are displaying");
		wd.findElementByXPath("//span[contains(text(),'App Status')]").getText().equalsIgnoreCase("App Status");
		String appstatus = wd.findElementByXPath("//div[@class='master-app-status application-status']/span[contains(text(),'error')]").getText();
		System.out.println("app state" +appstatus);
		wd.findElementByXPath("//div[@class='master-app-status application-status']/span[contains(text(),'error')]").getText().equalsIgnoreCase("Error");
		
		wd.findElementByXPath("//span[contains(text(),'Doc Status')]").getText().equalsIgnoreCase("Doc Status");
		wd.findElementByXPath("//div[@class='master-app-status document-status']/span[contains(text(),'COMPLETE')]").getText().equalsIgnoreCase("COMPLETE");
		
		List<WebElement> TabList = wd.findElementsByCssSelector(".tabs .active");
		for ( WebElement element : TabList ) {
			if((TabList.size()==1)&&(element.getText().equalsIgnoreCase("Applications")))
			System.out.println("Tab size is "+TabList.size());
			break; 
			}
		wd.findElementByXPath("//div[@class='table-container']/div[2]/div[@class='app-number ref-number col2']/descendant::div[@class='refErrorStatus needsclick']").click(); //doub
		assertTrue(wd.findElementByClassName("tooltipster-content").isDisplayed());
		System.out.println("Tooltip message box is displaying for error application");
		
		assertTrue(wd.findElementByXPath("//div[@class='tooltipster-content']/div[@class='tooltip-content app-details']/div[2]/span[contains(text(),'SYSTEM')]").getText().equalsIgnoreCase("SYSTEM"));
		assertTrue(wd.findElementByXPath("//div[@class='tooltipster-content']/div[@class='tooltip-content app-details']/div[3]/span").getText().equalsIgnoreCase("ERROR CODE"));
		assertTrue(wd.findElementByXPath("//div[@class='tooltipster-content']/div[@class='tooltip-content app-details']/div[4]/span").getText().equalsIgnoreCase("MESSAGE"));
		assertTrue(wd.findElementByXPath("//div[@class='tooltipster-content']/div[@class='tooltip-content app-details']/div[5]/span").getText().equalsIgnoreCase("ERROR DESCRIPTION"));
		System.out.println("Fields inside the tooltip message box is displaying");
	}
		
	
	
	/**MODULE: Ipad  [RELEASE-2]
	** Verifying the master application view for returned application is displaying correctly or not
	*/
	@Then("^I should see the Master Application Detail for returned application in ipad$")
	public void i_should_see_the_Master_Application_Detail_for_returned_application_in_ipad()
			throws Throwable {

		wd.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		Thread.sleep(20000);
	
		assertTrue(wd.findElementByXPath("//div[@class='modal-content']").getText()!=null);
		System.out.println("Master application view is displaying");
		
		//client name display check
		String clientname=wd.findElementByXPath("//h2[@class='client-name']").getText();
		assertTrue(wd.findElementByXPath("//h2[@class='client-name']").getText()!=null);
		System.out.println("Client name is displaying in master application view: " +clientname);
		Thread.sleep(10000);
		
		//client id display check
		String clientid=wd.findElementByXPath("//div[@class='name-block']").getText();
		assertTrue(wd.findElementByXPath("//div[@class='name-block']").getText()!=null);
		System.out.println("Client id is displaying in master application view:" +clientid);
		Thread.sleep(10000);
		
		//doc status app status
		String app_status = wd.findElement(By.cssSelector(".application-status .top-status")).getText();
		System.out.println(app_status);
		assertTrue(app_status.equalsIgnoreCase("Returned"));
		
		String doc_status = wd.findElement(By.cssSelector(".document-status .top-status")).getText();
		System.out.println(doc_status);
		assertTrue(doc_status.equalsIgnoreCase("Returned"));
		
		//retake
		Assert.assertTrue(wd.findElementByXPath("//span[@class='retake-app']").getText()!=null);
		System.out.println("Retake icon is displaying in master application view");
		
		//tap on info icon
		WebDriverWait wait = new WebDriverWait(wd, 70);
		Thread.sleep(3000);
		WebElement element2 = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".app-info div")));
		element2.click();
		//logger.info("Info Icon is clicked");
		
		//info icon details
		wd.findElement(By.cssSelector(".tooltipster-content"));
		// driver.findElement(By.cssSelector(".tooltip-app-number"));
		String actualappno = wd.findElement(By.xpath("//div[@class='tooltipster-content']/descendant::div[@class='tooltip-app-number']/span[2]")).getText(); // added by me
		Assert.assertTrue(actualappno.equalsIgnoreCase(TestData.applicationId)); 
		wd.findElement(By.cssSelector("body")).click();
		
		//Application and document tabs are displaying
		assertTrue(wd.findElementByXPath("//a[contains(text(),'Applications')]").getText().equalsIgnoreCase("Applications"));
		assertTrue(wd.findElementByXPath("//a[contains(text(),'Documents')]").getText().equalsIgnoreCase("Documents"));
		System.out.println("Application and document tabs are displaying");
		
		//verifying the headers in application tab
		
		assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref.no')]").getText().equalsIgnoreCase("Ref.no"));
		assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Product')]").getText().equalsIgnoreCase("Product"));
		assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Sub product')]").getText().equalsIgnoreCase("Sub product"));
		assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref submitted Date')]").getText().equalsIgnoreCase("Ref submitted Date"));
		assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref Status')]").getText().equalsIgnoreCase("Ref Status"));
	
	    //Verifying Reject and Resumbit buttons are displaying
		assertTrue(wd.findElementByClassName("application-rmreject").getText()!=null);
		assertTrue(wd.findElementByClassName("document-resubmit").getText()!=null);
		System.out.println("Reject and Resumbit buttons are displaying");
		
	}
			
	/**MODULE: Ipad  [RELEASE-2]
	 ** Verifying the Master Application Detail for returned application as RM2
	 */
		@Then("^I should see the Master Application Detail for returned application in ipad as RMtwo$")
		public void i_should_see_the_Master_Application_Detail_for_returned_application_in_ipad_as_RMtwo()
				throws Throwable {

			//driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			Thread.sleep(20000);
		
			assertTrue(wd.findElementByXPath("//div[@class='modal-content']").getText()!=null);
			System.out.println("Master application view is displaying");
			
			//client name display check
			String clientname=wd.findElementByXPath("//h2[@class='client-name']").getText();
			assertTrue(wd.findElementByXPath("//h2[@class='client-name']").getText()!=null);
			System.out.println("Client name is displaying in master application view: " +clientname);
			Thread.sleep(10000);
			
			//client id display check
			String clientid=wd.findElementByXPath("//div[@class='name-block']").getText();
			assertTrue(wd.findElementByXPath("//div[@class='name-block']").getText()!=null);
			System.out.println("Client id is displaying in master application view:" +clientid);
			Thread.sleep(10000);
			
			//doc status app status
			String app_status = wd.findElement(By.cssSelector(".application-status .top-status")).getText();
			System.out.println(app_status);
			assertTrue(app_status.equalsIgnoreCase("Returned"));
			
			String doc_status = wd.findElement(By.cssSelector(".document-status .top-status")).getText();
			System.out.println(doc_status);
			assertTrue(doc_status.equalsIgnoreCase("Returned"));
			
			//retake
			Assert.assertTrue(wd.findElementByXPath("//span[@class='retake-app']").getText()!=null);
			System.out.println("Retake icon is displaying in master application view");
			
			//tap on info icon
			WebDriverWait wait = new WebDriverWait(wd, 70);
			Thread.sleep(3000);
			WebElement element2 = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".app-info div")));
			element2.click();
			//logger.info("Info Icon is clicked");
			
			//info icon details
			wd.findElement(By.cssSelector(".tooltipster-content"));
			// driver.findElement(By.cssSelector(".tooltip-app-number"));
			String actualappno = wd.findElement(By.xpath("//div[@class='tooltipster-content']/descendant::div[@class='tooltip-app-number']/span[2]")).getText(); // added by me
			Assert.assertTrue(actualappno.equalsIgnoreCase(TestData.applicationId)); 
			wd.findElement(By.cssSelector("body")).click();
			
			//Application and document tabs are displaying
			List<WebElement> TabList = wd.findElementsByCssSelector(".tabs .active");
			for ( WebElement element : TabList ) {
				if((TabList.size()==1)&&(element.getText().equalsIgnoreCase("Applications")))
				System.out.println("Tab size is "+TabList.size());
				break; 
				}
			System.out.println("Application tab is displaying");
			
			//verifying the headers in application tab
			assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref.no')]").getText().equalsIgnoreCase("Ref.no"));
			assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Product')]").getText().equalsIgnoreCase("Product"));
			assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Sub product')]").getText().equalsIgnoreCase("Sub product"));
			assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref submitted Date')]").getText().equalsIgnoreCase("Ref submitted Date"));
			assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref Status')]").getText().equalsIgnoreCase("Ref Status"));
		}		
	/**MODULE: Ipad  [RELEASE-2]
	 ** Verifying the Reject and Return buttons are displaying while accessing the application submitted by another RM
	*/	
		
		@Then("^I should not be able to view the Reject and Return buttons in Ipad$")
		public void i_should_not_be_able_to_view_the_Reject_and_Return_buttons_in_Ipad() throws Throwable 
		{
			 wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			 String resumbitbtn=wd.findElement(By.xpath("//span[@class='document-resubmit']")).getText();
			 System.out.println("resubmitbtn:" +resumbitbtn);
			 String rejectbutton = wd.findElement(By.xpath("//span[@class='application-rmreject']")).getText();
			 System.out.println("reject button:" +rejectbutton);
			 assertTrue(resumbitbtn.isEmpty());
			 assertTrue(rejectbutton.isEmpty());
			 //assertFalse(wd.findElement(By.xpath("//span[@class='application-rmreject']")).isDisplayed());
			// assertFalse(wd.findElement(By.xpath("//span[@class='document-resubmit']")).isDisplayed());	 
			 System.out.println("Reject and Resubmit buttons are not displaying");
		}
	


	/**
	* Module - Coding [Release -2] 
	* Scenario-1.Return and re-take 
	* 
	* User can re-take the application by clicking the retake button from the iPAD
	* from Application diary
	* 
	* Author -Vignesh Ramamurthy 
	*/
	@Then("^I click on re-take option$")
	public void i_click_on_re_take_option() throws Throwable 
	{
		wd.findElement(By.className("retake-app")).click();
		Thread.sleep(2000);
		wd.findElement(By.className("modal---button-no")).click();
		Thread.sleep(2000);
		wd.findElement(By.className("retake-app")).click();
		Thread.sleep(2000);
		wd.findElement(By.className("modal---button-yes")).click();
		Thread.sleep(3000);
		wait = new WebDriverWait(wd, 10);
		
		WebElement retakeButton = wait.until(ExpectedConditions.elementToBeClickable(wd.findElement(By
						.className("step-name---text"))));
		System.out.println("!-------------------------------------Form rendered-----------------------------------------!");
		
	}
	
	/**
	* Module - Ipad [Release -2] 
	* Scenario-1.Click on search toggle in ipad
	* Author -Kasthuri
	*/
	
	@When("^I navigate to application search from ipad$")
	public void i_navigate_to_application_search_from_ipad() throws Throwable {
		Set<String> AvailableContexts = wd.getContextHandles();
	    for (String context : AvailableContexts)
		{
			if(context.contains("WEBVIEW"))
				wd.context(context);
		}
	    Thread.sleep(10000);
	    System.out.println("search toggle click....");
     
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(wd, 30);
		wait.until(ExpectedConditions.visibilityOf((WebElement) wd.findElement(By.cssSelector(".search-toggle"))));
		wd.findElement(By.cssSelector(".search-toggle")).click();
		System.out.println("Inside the application search screen in ipad");
		Thread.sleep(5000);
	}
	
	/**
	* Module - Ipad [Release -2] 
	* Scenario-1.Searching an application from application diary in ipad
	* Author -Kasthuri
	*/
	@When("^I Search an application in ipad$")
	public void i_Search_an_application_in_ipad() throws Throwable {

		WebDriverWait wait = new WebDriverWait(wd, 30);
		wait.until(ExpectedConditions.visibilityOf((WebElement) wd.findElement(By.className("modal-search---input-field"))));
		wd.findElement(By.className("modal-search---input-field")).sendKeys(TestData.applicationId);
		Thread.sleep(15000);
	}
	
	@When("^I tap on the application from search result in ipad$")
	public void i_tap_on_the_application_from_search_result_in_ipad() throws Throwable {
		Thread.sleep(2000);
		boolean Application_present = false;
		List<WebElement> elements = wd.findElements(By.cssSelector(".search-result-table-row"));

		Iterator<WebElement> itr1 = elements.iterator();
		itr1.next();
		while (itr1.hasNext()) {
			WebElement Approw = itr1.next();
			String AppID = Approw.findElement(By.cssSelector(".search-app-number a")).getText();
			System.out.println("Application Id present in the browser ="+ AppID);
			if (AppID.equalsIgnoreCase(TestData.applicationId)) {
				Application_present = true;
				System.out.println("App present");
				((JavascriptExecutor) wd).executeScript("document.getElementsByClassName('search-app-number')[0].getElementsByTagName('a')[0].click()");
				// Approw.findElement(By.cssSelector(".search-app-number")).click();
				break;
			}
		}
		if (!Application_present) {
			throw new RuntimeException(TestData.applicationId
					+ " Application not present ");
		}
	   
	}


	/**
	* Module - Ipad [Release -2] 
	* Scenario: Viewing the searched result in ipad
	* Author -Kasthuri
	*/
	@Then("^I should see the search result in ipad$")
	public void i_should_see_the_search_result_in_ipad() throws Throwable {
		wd.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		wd.findElement(By.cssSelector(".search-result-table"));

		Assert.assertTrue(wd.findElement(By.cssSelector(".search-result-table-row")).isDisplayed());
		Thread.sleep(20000);
	}
	
	/**MODULE: APP ENQUIRY  [RELEASE-2]
	** Verifying the master application view for processed (Approved) application
	*/
	@Then("^I should see the Master Application Detail for processed application in ipad$")
	public void i_should_see_the_Master_Application_Detail_for_processed_application_in_ipad()
			throws Throwable {

		wd.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		Thread.sleep(20000);
	
		assertTrue(wd.findElementByXPath("//div[@class='modal-content']").getText()!=null);
		System.out.println("Master application view is displaying");
		
		//client name display check
		String clientname=wd.findElementByXPath("//h2[@class='client-name']").getText();
		assertTrue(wd.findElementByXPath("//h2[@class='client-name']").getText()!=null);
		System.out.println("Client name is displaying in master application view: " +clientname);
		Thread.sleep(3000);
		
		//client id display check
		String clientid=wd.findElementByXPath("//div[@class='name-block']").getText();
		assertTrue(wd.findElementByXPath("//div[@class='name-block']").getText()!=null);
		System.out.println("Client id is displaying in master application view:" +clientid);
		Thread.sleep(3000);
		
		//doc status app status
		String app_status = wd.findElement(By.cssSelector(".application-status .top-status")).getText();
		System.out.println(app_status);
		assertTrue(app_status.equalsIgnoreCase("approved"));
		
		String doc_status = wd.findElement(By.cssSelector(".document-status .top-status")).getText();
		System.out.println(doc_status);
		assertTrue(doc_status.equalsIgnoreCase("COMPLETE"));
		
		//tap on info icon
		WebDriverWait wait = new WebDriverWait(wd, 70);
		Thread.sleep(3000);
		WebElement element2 = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".app-info div")));
		element2.click();
		//logger.info("Info Icon is clicked");
		
		//info icon details
		wd.findElement(By.cssSelector(".tooltipster-content"));
		// driver.findElement(By.cssSelector(".tooltip-app-number"));
		String actualappno = wd.findElement(By.xpath("//div[@class='tooltipster-content']/descendant::div[@class='tooltip-app-number']/span[2]")).getText(); // added by me
		Assert.assertTrue(actualappno.equalsIgnoreCase(TestData.applicationId)); 
		wd.findElement(By.cssSelector("body")).click();
		
		//Application and document tabs are displaying
		List<WebElement> TabList = wd.findElementsByCssSelector(".tabs .active");
		for ( WebElement element : TabList ) {
			if((TabList.size()==1)&&(element.getText().equalsIgnoreCase("Applications")))
			System.out.println("Tab size is "+TabList.size());
			break; 
			}
	     System.out.println("Application tab alone is displaying");
		
		//verifying the headers in application tab
		
		assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref.no')]").getText().equalsIgnoreCase("Ref.no"));
		assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Product')]").getText().equalsIgnoreCase("Product"));
		assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Sub product')]").getText().equalsIgnoreCase("Sub product"));
		assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref submitted Date')]").getText().equalsIgnoreCase("Ref submitted Date"));
		assertTrue(wd.findElementByXPath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref Status')]").getText().equalsIgnoreCase("Ref Status"));
		}
		
	
	/**MODULE: APP ENQUIRY  [RELEASE-2]
	 ** Verifying the master application view for processed (Approved) application in coding station
	 */
		@Then("^I should see the Master Application Detail for processed application in coding station$")
		public void i_should_see_the_Master_Application_Detail_for_processed_application_in_coding_station()
				throws Throwable {

			//driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			Thread.sleep(20000);
		
			assertTrue(driver.findElement(By.xpath("//div[@class='modal-content']")).getText()!=null);
			System.out.println("Master application view is displaying");
			
			//client name display check
			String clientname=driver.findElement(By.xpath("//h2[@class='client-name']")).getText();
			assertTrue(driver.findElement(By.xpath("//h2[@class='client-name']")).getText()!=null);
			System.out.println("Client name is displaying in master application view: " +clientname);
			Thread.sleep(3000);
			
			//client id display check
			String clientid=driver.findElement(By.xpath("//div[@class='name-block']")).getText();
			assertTrue(driver.findElement(By.xpath("//div[@class='name-block']")).getText()!=null);
			System.out.println("Client id is displaying in master application view:" +clientid);
			Thread.sleep(3000);
			
			//doc status app status
			String app_status = driver.findElement(By.cssSelector(".application-status .top-status")).getText();
			System.out.println(app_status);
			assertTrue(app_status.equalsIgnoreCase("approved"));
			
			String doc_status = driver.findElement(By.cssSelector(".document-status .top-status")).getText();
			System.out.println(doc_status);
			assertTrue(doc_status.equalsIgnoreCase("COMPLETE"));
			
			//tap on info icon
			WebDriverWait wait = new WebDriverWait(driver, 70);
			Thread.sleep(3000);
			WebElement element2 = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".app-info div")));
			element2.click();
			//logger.info("Info Icon is clicked");
			
			//info icon details
			driver.findElement(By.cssSelector(".tooltipster-content"));
			// driver.findElement(By.cssSelector(".tooltip-app-number"));
			String actualappno = driver.findElement(By.xpath("//div[@class='tooltipster-content']/descendant::div[@class='tooltip-app-number']/span[2]")).getText(); // added by me
			Assert.assertTrue(actualappno.equalsIgnoreCase(TestData.applicationId)); 
			driver.findElement(By.cssSelector("body")).click();
			
			//Application and document tabs are displaying
			List<WebElement> TabList = driver.findElements(By.cssSelector(".tabs .active"));
			for ( WebElement element : TabList ) {
				if((TabList.size()==1)&&(element.getText().equalsIgnoreCase("Applications")))
				System.out.println("Tab size is "+TabList.size());
				break; 
				}
		     System.out.println("Application tab alone is displaying");
			
			//verifying the headers in application tab
			
			assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref.no')]")).getText().equalsIgnoreCase("Ref.no"));
			assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Product')]")).getText().equalsIgnoreCase("Product"));
			assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Sub product')]")).getText().equalsIgnoreCase("Sub product"));
			assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref submitted Date')]")).getText().equalsIgnoreCase("Ref submitted Date"));
			assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref Status')]")).getText().equalsIgnoreCase("Ref Status"));
		}
		
		
	/**
	* Module - App Enquiry [Release -2] 
	* Scenario-1.Click on Reference number in ipad
	* Author -Kasthuri
	*/
		@Then("^I tap on the reference number in ipad$")
		  public void i_tap_on_the_reference_number_in_ipad() throws Throwable {
		  wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  wd.findElement(By.xpath("//div[@class='ember-view app-queue-table-row selected-product-list'][1]/div[@class='app-number ref-number col2']/span[@class='errortooltip']")).click();
		}
		
	/**
	* Module - App Enquiry [Release -2] 
	* Scenario-1.Click on Reference number in coding station
	* Author -Kasthuri
	*/
		@Then("^I tap on the reference number in coding station$")
		public void i_tap_on_the_reference_number_in_ipad_coding_station() throws Throwable {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//div[@class='ember-view app-queue-table-row selected-product-list'][1]/div[@class='app-number ref-number col2']/span[@class='errortooltip']")).click();
		}
	
		
	/** Module - Ipad [Release -2] 
	* Scenario-1.Viewing the application enquiry screen in ipad
	* Author -Kasthuri
	*/	
	@Then("^I should be able to view the application enquiry screen in ipad$")
	public void i_should_be_able_to_view_the_application_enquiry_screen_in_ipad() throws Throwable {
	    wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	    //App Enquiry screen is displaying
		assertTrue(wd.findElement(By.xpath("//div[@id='third-modals']/div/descendant::div[@class='wrapper']/div/div[@class='application-master']")).getText()!=null);
		System.out.println("App Enquiry screen is displaying");
		
		//Client name is displaying
		String clientname = wd.findElement(By.xpath("//div[@class='app-master-header']/div[@class='name-number-block']/h2[@class='client-name']")).getText();
		assertTrue(clientname!=null);
		System.out.println("Client name is displaying as : " +clientname);
		
		//Client id is displaying
		String clientid = wd.findElement(By.xpath("//div[@id='third-modals']/descendant::div[@class='name-number-block']/div[@class='app-number-block']/div[@class='name-block']/span[1]")).getText();
		assertTrue(clientid!=null);
		System.out.println("Client id is displaying as : " +clientid);
		
		//Ref No is displaying
		String refno = wd.findElement(By.xpath("//div[@id='third-modals']/descendant::div[@class='name-number-block']/div[@class='app-number-block']/div[@class='name-block']/span[2]")).getText();
		assertTrue(refno!=null);
		System.out.println("Ref No. is displaying as : " +clientid);	
		
		//Headers are displaying
		wd.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Product')]")).getText().equalsIgnoreCase("Product");
		wd.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Sub product')]")).getText().equalsIgnoreCase("Sub product");
		wd.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Ref submitted date')]")).getText().equalsIgnoreCase("Ref submitted date");
		
		wd.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Credit Limit Applied')]")).getText().equalsIgnoreCase("Credit Limit Applied");
		wd.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Credit Limit Approved')]")).getText().equalsIgnoreCase("Credit Limit Approved");
		wd.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Account Setup Date')]")).getText().equalsIgnoreCase("Account Setup Date");
		wd.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Application Closed Date')]")).getText().equalsIgnoreCase("Application Closed Date");
		wd.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Decision Date')]")).getText().equalsIgnoreCase("Decision Date");
		
		System.out.println("All headers are displaying");
		
		//Data for the fields Product, SubProduct & RefSubmittedDate are displaying
		String Productdata = wd.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Product')]/following-sibling::p")).getText();
		assertTrue(Productdata!=null);
		
		String SubProductdata = wd.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Sub product')]/following-sibling::p")).getText();
		assertTrue(SubProductdata!=null);
		
		String Refsubmitteddatedata = wd.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Ref submitted date')]/following-sibling::p")).getText();
		assertTrue(Refsubmitteddatedata!=null);
		
		String creditlimitapplieddata = wd.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Credit Limit Applied')]/following-sibling::dd")).getText();
		assertTrue(creditlimitapplieddata!=null);
		
		String creditlimitapproveddata = wd.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Credit Limit Approved')]/following-sibling::dd")).getText();
		assertTrue(creditlimitapproveddata!=null);
		
		String accsetupdata = wd.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Account Setup Date')]/following-sibling::dd")).getText();
		assertTrue(accsetupdata!=null);
		
		String appcloseddata = wd.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Application Closed Date')]/following-sibling::dd")).getText();
		assertTrue(appcloseddata!=null);
		
		String decisiondatedata = wd.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Decision Date')]/following-sibling::dd")).getText();
		assertTrue(decisiondatedata!=null);
		
		System.out.println("Data 's are displaying for all the fields");
	}
		
	/** Module - coding station [Release -2] 
	 * Scenario-1.Viewing the application enquiry screen in coding station
	 * Author -Kasthuri
	 */	
		@Then("^I should be able to view the application enquiry screen in coding station$")
		public void i_should_be_able_to_view_the_application_enquiry_screen_in_coding_station() throws Throwable {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
		    //App Enquiry screen is displaying
			assertTrue(driver.findElement(By.xpath("//div[@id='third-modals']/div/descendant::div[@class='wrapper']/div/div[@class='application-master']")).getText()!=null);
			System.out.println("App Enquiry screen is displaying");
			
			//Client name is displaying
			String clientname = driver.findElement(By.xpath("//div[@class='app-master-header']/div[@class='name-number-block']/h2[@class='client-name']")).getText();
			assertTrue(clientname!=null);
			System.out.println("Client name is displaying as : " +clientname);
			
			//Client id is displaying
			String clientid = driver.findElement(By.xpath("//div[@id='third-modals']/descendant::div[@class='name-number-block']/div[@class='app-number-block']/div[@class='name-block']/span[1]")).getText();
			assertTrue(clientid!=null);
			System.out.println("Client id is displaying as : " +clientid);
			
			//Ref No is displaying
			String refno = driver.findElement(By.xpath("//div[@id='third-modals']/descendant::div[@class='name-number-block']/div[@class='app-number-block']/div[@class='name-block']/span[2]")).getText();
			assertTrue(refno!=null);
			System.out.println("Ref No. is displaying as : " +clientid);	
			
			//Headers are displaying
			driver.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Product')]")).getText().equalsIgnoreCase("Product");
			driver.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Sub product')]")).getText().equalsIgnoreCase("Sub product");
			driver.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Ref submitted date')]")).getText().equalsIgnoreCase("Ref submitted date");
			
			driver.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Credit Limit Applied')]")).getText().equalsIgnoreCase("Credit Limit Applied");
			driver.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Credit Limit Approved')]")).getText().equalsIgnoreCase("Credit Limit Approved");
			driver.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Account Setup Date')]")).getText().equalsIgnoreCase("Account Setup Date");
			driver.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Application Closed Date')]")).getText().equalsIgnoreCase("Application Closed Date");
			driver.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Decision Date')]")).getText().equalsIgnoreCase("Decision Date");
			
			System.out.println("All headers are displaying");
			
			//Data for the fields Product, SubProduct & RefSubmittedDate are displaying
			String Productdata = driver.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Product')]/following-sibling::p")).getText();
			assertTrue(Productdata!=null);
			
			String SubProductdata = driver.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Sub product')]/following-sibling::p")).getText();
			assertTrue(SubProductdata!=null);
			
			String Refsubmitteddatedata = driver.findElement(By.xpath("//div[@class='product-detail-header']/descendant::p[contains(text(),'Ref submitted date')]/following-sibling::p")).getText();
			assertTrue(Refsubmitteddatedata!=null);
			
			String creditlimitapplieddata = driver.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Credit Limit Applied')]/following-sibling::dd")).getText();
			assertTrue(creditlimitapplieddata!=null);
			
			String creditlimitapproveddata = driver.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Credit Limit Approved')]/following-sibling::dd")).getText();
			assertTrue(creditlimitapproveddata!=null);
			
			String accsetupdata = driver.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Account Setup Date')]/following-sibling::dd")).getText();
			assertTrue(accsetupdata!=null);
			
			String appcloseddata = driver.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Application Closed Date')]/following-sibling::dd")).getText();
			assertTrue(appcloseddata!=null);
			
			String decisiondatedata = driver.findElement(By.xpath("//div[@class='product-detail-block']/descendant::dt[contains(text(),'Decision Date')]/following-sibling::dd")).getText();
			assertTrue(decisiondatedata!=null);
			
			System.out.println("Data 's are displaying for all the fields");
		}
		
	/** Module - Ipad [Release -2] 
	 * Scenario-1.Viewing the processed application status in ipad
	 * Author -Kasthuri
	 */
	@Then("^I should see the Reference status and APPL status as \"(.*?)\"$")
	public void i_should_see_the_Reference_status_and_APPL_status_as(String Expappstatus)
	{
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String ActualAppStatus = wd.findElement(By.xpath("//div[@class='product-status-block']/div[@class='approved refStatus']")).getText();
		assertTrue(Expappstatus.equalsIgnoreCase(Expappstatus));
		System.out.println("Appstatus in app enq screen is : "+ActualAppStatus);
	}
		
		
	/** Module - App enquiry-coding station [Release -2] 
	 * Scenario-1.Viewing the processed application status in coding station
	 * Author -Kasthuri
	 */
	@Then("^I should see the Reference status and APPL status as \"(.*?)\" in coding station$")
	public void i_should_see_the_Reference_status_and_APPL_status_as_in_coding_station(String Expappstatus)
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String ActualAppStatus = driver.findElement(By.xpath("//div[@class='product-status-block']/div[@class='approved refStatus']")).getText();
		assertTrue(Expappstatus.equalsIgnoreCase(Expappstatus));
		System.out.println("Appstatus in app enq screen is : "+ActualAppStatus);
	}
		
}

