package com.scb.rwb.glue;

import static org.junit.Assert.fail;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rwb.appium.pages.SearchPage;
import com.scb.rwb.wrappers.ApplicationWrappers;

import io.appium.java_client.AppiumDriver;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ApplicationSearch extends ApplicationWrappers{
	
	

	WebDriverWait wait = new WebDriverWait(wd, 30);

	

	@When("^I search for the submitted application$")
	public void i_search_for_the_submitted_application() throws Throwable {
		new SearchPage().searchSubmittedApplication();
	}

	@Then("^I should see the application status as \"(.*?)\"$")
	public void i_should_see_the_application_status_as(String status) throws Throwable {
		new SearchPage().verifyApplicationStatus(status);
	}
	
	
}
