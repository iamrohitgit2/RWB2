package com.scb.rwb.appium.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.aspectj.weaver.patterns.IfPointcut.IfFalsePointcut;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.utility.ReadTestData;

public class FFIncomePage extends AppiumBasePage {


	FFClientKeyInformationPage ffCKI = new FFClientKeyInformationPage();

	/*
	 * Income Section Web elements
	 */

	/*@FindBy(id = "text-component_i-monthly-salary-income-lcy_wrapper")
	WebElement txtMonthlySalaryIncome;

	@FindBy(id = "text-component_i-monthly-allowances-lcy_wrapper")
	WebElement txtMonthlyAllowances;

	@FindBy(id = "text-component_i-monthly-total-income-lcy_wrapper")
	WebElement txtMonthlyTotalIncome;

	@FindBy(id = "select-component_i-source-of-other-income_wrapper")
	WebElement slctSourceOfOtherIncome;

	@FindBy(id = "text-component_i-spouses-monthly-income-lcy_wrapper")
	WebElement txtSpouseMonthlyIncome;

	@FindBy(id = "text-component_i-other-income-avg-turnover-for-self-employed-lcy_wrapper")
	WebElement txtOthIncomeAvgTurnover;

	@FindBy(id = "text-component_i-monthly-rental-income-lcy_wrapper")
	WebElement txtMonthlyRentalIncome;

	@FindBy(id = "text-component_i-monthly-biz-income-lcy_wrapper")
	WebElement txtMonthlyBizIncome;

	@FindBy(id = "text-component_i-monthly-rent-utility-exp-lcy_wrapper")
	WebElement txtMonthlyRentUtility;

	@FindBy(id = "text-component_i-monthly-food-exp-lcy_wrapper")
	WebElement txtMonthlyFoodExp;

	@FindBy(id = "text-component_i-monthly-edu-exp-lcy_wrapper")
	WebElement txtMonthlyEduExp;

	@FindBy(id = "text-component_i-monthly-loan-repay-lcy_wrapper")
	WebElement txtMonthlyLoanRepay;

	@FindBy(id = "text-component_i-monthly-oth-exp-lcy_wrapper")
	WebElement txtMonthlyOthExp;

	@FindBy(id = "text-component_i-monthly-total-exp-lcy_wrapper")
	WebElement txtMonthlyTotalExp;*/

	/**
	 * This method will enter the data for Income section details
	 * 
	 * @return
	 */
	
	@FindBy(xpath = "//div[contains(@id,'_i-') and input[@type='text']]")
	List<WebElement> textFields;
	@FindBy(xpath = "//div[contains(@id,'_i-') and input[@type='date']]")
	List<WebElement> dateFeilds;

	@FindBy(xpath = "//div[.//input[@class='ui-autocomplete-input']][contains(@id,'_i-')]")
	List<WebElement> dropdownFeilds;

	@FindBy(xpath = "//div[input[@type='checkbox']][contains(@id,'_i-')]")
	List<WebElement> switchFeilds;

	@FindBy(xpath = "//div[.//input[@type='radio']][contains(@id,'_i-')]")
	List<WebElement> radioFeilds;

	@FindBy(css = "body")
	WebElement body;

	@FindBy(id = "next-button")
	WebElement btnNext;

	By tagNameInput = By.tagName("input");

	By tagNameLabel = By.tagName("label");
	
	Set<String> webele = new HashSet<String>();
	Set<String> csvkeys  = new HashSet<String>();
	HashMap<String, ArrayList<String>> addMap;
	
	public FFEmploymentPage formFillForIncomeSection(int count) throws Exception {
		
		getNeedDataFromCSVMap(count);
		fillTextfields();
		filldatefields();
		filldropdownFeilds();
		fillswitchFeilds();
		verificationOfRequiedElemetsPresentInPage(webele, csvkeys);
		body.click();
		waitForvisiblityOfGivenElement(btnNext);
		btnNext.click();

		return new FFEmploymentPage();
	}

	public  void fillTextfields() throws Exception {
		webele = formFillEnterText(textFields, addMap, webele);
	}

	public void filldatefields() throws Exception {
		webele = formFillEnterText(dateFeilds, addMap, webele);
		
	}

	public void fillswitchFeilds() throws Exception {
		webele = formFillSwitchElementToClick(switchFeilds, addMap, webele);
	}

	public void fillradioFeilds() {
		for (WebElement element : radioFeilds) {
			// if(Map.field contains element.getAttribute("id");
			// element.sendKeys( the value of the map);
		}
	}

	public void filldropdownFeilds() throws Exception {
		webele = formFillSelectElementFromDropdown(dropdownFeilds, addMap, webele);
	}
	
	
	public void getNeedDataFromCSVMap(int requiredCol){
		addMap = new HashMap<>();
		for (String data : ReadTestData.ffIncomeMap.keySet()) {
			if(!ReadTestData.ffIncomeMap.get(data).get(requiredCol).equals("N")){
				addMap.put(data, ReadTestData.ffIncomeMap.get(data));
			}
		}
//		System.out.println(addMap);
		for (String dat : addMap.keySet()) {
			csvkeys.add(dat);
		}
	}
	
	/*public FFEmploymentPage enterIncomeDetails() {
		formFillEnterText(txtMonthlyTotalIncome,
				ReadTestData.ffData.getMonTotalIncome());

		ffCKI.body.click();
		waitForvisiblityOfGivenElement(ffCKI.btnNext);
		ffCKI.btnNext.click();
		return new FFEmploymentPage();

	}*/

}
