package com.scb.rwb.glue;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.standardchartered.genie.FrameworkGlue;

public class GetProductName extends FrameworkGlue {
	
	public static WebDriver driver;
	public static void main(String[] args) throws Throwable  {
				
		         System.setProperty("webdriver.chrome.driver", "Dependencies//chromedriver");
				 driver = new ChromeDriver();
				 ChromeOptions options = new ChromeOptions();
			    	options.addArguments("--start-maximized");
			    	
				driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
				Thread.sleep(5000);
				driver.get("https://pt.sc.com/origination/#/?COUNTRYCODE=AE&PAGE=PO&PWID=1100012"
						+ "&SSO=fake_rcwb");
				Thread.sleep(10000);
				//addMessage("Open Browser");
				List<WebElement> id = driver.findElements(By.cssSelector(".product-list .name"));
				Iterator<WebElement> itr1 = id.iterator();
				while(itr1.hasNext()) 
				{
					String TextfromPage = itr1.next().getText();
					System.out.println(TextfromPage);
					
				}
			}
	
		
}




