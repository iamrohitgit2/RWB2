package com.scb.rwb.glue;

import static org.junit.Assert.assertTrue;
import io.appium.java_client.AppiumDriver;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rwb.appium.pages.ProductOfferingPage;
import com.scb.rwb.wrappers.ApplicationWrappers;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ProductOfferingStepDefenitionFile {

	AppiumDriver wd = ApplicationWrappers.wd;
	WebDriverWait wait = new WebDriverWait(wd, 60);

	@Then("^I should see Product Offering$")
	public void i_should_see() throws Throwable {

		wd.manage().timeouts().implicitlyWait(95, TimeUnit.SECONDS);
		Thread.sleep(10000);
		Assert.assertTrue("Product offering is not displaying", wd
				.findElementByCssSelector(".product-offering").isDisplayed()); // added
																				// by
																				// me
		// wd.findElementByCssSelector(".product-offering");
	}

	@And("^I should able view all products$")
	public void I_should_verify_the_list_of_product_existence()
			throws Throwable {
		new ProductOfferingPage().viewAllProduct();
	}

	@When("^I should see the list of sub products$")
	public void I_should_see_the_list_of_sub_products() throws Throwable {
		new ProductOfferingPage().verifyTheVerificationErrorMessageIsDispayed();
	}

	@Then("^I should see Product Name as \"([^\"]*)\"$")
	public void I_should_see_Product_Name_as(String expectedProductName)
			throws Throwable {
		new ProductOfferingPage().verifyProductName(expectedProductName);
	}

	@Then("^I should see No of Product count as \"([^\"]*)\"$")
	public void I_should_see_No_of_Product_count_as(
			String ExpectedProductCountCheck) throws Throwable {
		new ProductOfferingPage()
				.verifyTheNoOFProduct(ExpectedProductCountCheck);
	}

	@And("^I should see Product description as \"([^\"]*)\"$")
	public void I_should_see_Product_description_as(String expectedSubTitle)
			throws Throwable {
		new ProductOfferingPage().verifyProductDecription(expectedSubTitle);
	}

	@And("^I should see Features$")
	public void I_should_see_Features() throws Throwable {
		Assert.assertTrue("Verification Error: Features are not displaying", wd
				.findElement(By.className("featured-features")).isDisplayed());
	}

	@And("^I should see below details:$")
	public void I_should_see_below_details(List<String> data) throws Throwable {
		Iterator itr2 = data.listIterator();

		while (itr2.hasNext()) {
			String ExpectedText = itr2.next().toString();
			System.out.println("ExpectedText =" + ExpectedText);
			boolean TextPresent = false;
			wait.until(ExpectedConditions.visibilityOf(wd.findElement(By
					.className("literal-value"))));
			List<WebElement> listOfDetail = wd.findElements(By
					.className("literal-value"));
			Iterator<WebElement> itr1 = listOfDetail.iterator();

			while (itr1.hasNext()) {
				String TextfromPage = itr1.next().getText();
				System.out.println("TextfromPage = " + TextfromPage);

				if (ExpectedText.equalsIgnoreCase(TextfromPage)) {
					TextPresent = true;
					break;
				}

			}
			if (!TextPresent) {
				throw new RuntimeException(ExpectedText
						+ " is not present in the webpage");
			}
		}
	}

	@When("^I tap on \"([^\"]*)\"$")
	public void I_tap_on(String productName) throws Throwable {
		new ProductOfferingPage().tapOnTheGivenProduct(productName);
	}

	@When("^I tap on Shopping Cart button$")
	public void I_tap_on_Shopping_Cart_button() throws Throwable {

		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		((JavascriptExecutor) wd).executeScript("mobile: tap",
				new HashMap<String, Double>() {
					{
						put("tapCount", (double) 1);
						put("touchCount", (double) 1);
						put("duration", 0.5);
						put("x", (double) 42);
						put("y", (double) 737);
					}
				});
	}

	@Then("^I should not be able to add \"(.*?)\"$")
	public void I_should_not_be_able_to_add_JustOne_Personal_Savings_Account(
			String productName) throws Throwable {
		new ProductOfferingPage().verifyNotAbleToAddProduct(productName);
	}

	@When("^I tap on the I agree with Terms & Conditions button$")
	public void I_tap_on_i_agree() throws Throwable {
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Assert.assertTrue(wd.findElement(
				By.cssSelector(".terms-and-conditions-menu---button-accept"))
				.isDisplayed()); // added by me
		wd.findElement(
				By.cssSelector(".terms-and-conditions-menu---button-accept"))
				.click();

	}

	@Then("^I should see Terms and Conditions in details page$")
	public void I_should_terms_in_details_page() throws Throwable
	{
		new ProductOfferingPage().verifyTermsAndConditionInDetilsPage();
	}

	@Then("^I should see \"([^\"]*)\" in the cart$")
	public void I_should_see_in_the_cart(String productName) throws Throwable {
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		boolean productPresent = false;
		List<WebElement> ProductsinShoppingCart = wd.findElements(By
				.cssSelector(".products-cart---item"));
		Iterator<WebElement> itr1 = ProductsinShoppingCart.iterator();

		while (itr1.hasNext()) {
			Thread.sleep(3000);
			String availableProduct = itr1.next()
					.findElement(By.tagName("span")).getText();
			System.out.println("Available Product" + availableProduct);
			if (productName.equalsIgnoreCase(availableProduct)) {
				productPresent = true;
				break;
			}

		}

		if (!productPresent) {
			throw new RuntimeException(productName
					+ " product not present in the shopping cart");
		}

	}

	@Then("^I should see  \"(.*?)\" in the cart$")
	public void i_should_see_in_the_cart(String productName) throws Throwable {
		wd.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		boolean productPresent = false;
		List<WebElement> ProductsinShoppingCart = wd.findElements(By
				.cssSelector(".products-cart---item"));
		Iterator<WebElement> itr1 = ProductsinShoppingCart.iterator();
		while (itr1.hasNext()) {
			String availableProduct = itr1.next()
					.findElement(By.tagName("span")).getText();
			System.out.println("Available Product" + availableProduct);
			if (productName.equalsIgnoreCase(availableProduct)) {
				productPresent = true;
				break;
			}

		}

		if (!productPresent) {
			throw new RuntimeException(productName
					+ " product not present in the shopping cart");
		}
	}

	@When("^I tap on delete icon for \"([^\"]*)\"$")
	public void I_tap_on_delete_icon_for(String productName) throws Throwable {
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		List<WebElement> ProductsinShoppingCart = wd.findElements(By
				.cssSelector(".products-cart---item"));
		Iterator<WebElement> itr1 = ProductsinShoppingCart.iterator();

		for (int i = 0; i < ProductsinShoppingCart.size(); i++) {
			String availableProduct = ProductsinShoppingCart.get(i)
					.findElement(By.tagName("span")).getText();
			if (productName.equalsIgnoreCase(availableProduct))

			{
				System.out.println("Going to delete " + availableProduct);
				((JavascriptExecutor) wd)
						.executeScript("(document.getElementsByClassName('products-cart---item')["
								+ i
								+ "].getElementsByClassName('products-cart---button-trash'))[0].click()");
			}

		}

	}

	@Then("^I should see \"([^\"]*)\" removed in the shopping Cart screen$")
	public void I_should_see_removed_in_the_shopping_Cart_screen(
			String productName) throws Throwable {
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean productPresent = false;
		List<WebElement> ProductsinShoppingCart = wd.findElements(By
				.cssSelector(".products-cart---item span"));
		Iterator<WebElement> itr1 = ProductsinShoppingCart.iterator();
		while (itr1.hasNext()) {
			String availableProduct = itr1.next().getText();
			if (productName.equalsIgnoreCase(availableProduct)) {
				productPresent = true;
				break;
			}

		}

		if (productPresent) {
			throw new RuntimeException(productName
					+ " product present in the shopping cart");
		}
	}

	@When("^I tap on close icon for Shopping Cart screen$")
	public void I_tap_on_close_icon_for_Shopping_Cart_screen() throws Throwable {
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		((JavascriptExecutor) wd)
				.executeScript("document.getElementsByClassName('products-cart---button-close')[0].click()");

	}

	@When("^I tap on the Checkout button$")
	public void I_tap_on_the_button() throws Throwable {
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println("Tapping on checkout button");

		((JavascriptExecutor) wd).executeScript("mobile: tap",
				new HashMap<String, Double>() {
					{
						put("tapCount", (double) 1);
						put("touchCount", (double) 1);
						put("duration", 0.5);
						put("x", (double) 42);
						put("y", (double) 737);
					}
				});

	}

	@Then("^I should see the Terms & Conditions page$")
	public void I_should_see_terms_and_conditions() throws Throwable {
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		wd.findElement(By.cssSelector(".title"));
		assert (wd.findElement(By.cssSelector(".title")).getText()
				.equalsIgnoreCase("Please Accept The Terms & Conditions"));

	}

	@When("^I tap on \"([^\"]*)\" button$")
	public void I_tap_on_button(String TapAddCart) throws Throwable {
		new ProductOfferingPage().tapOnAddCardButtonOnProductDetailSection();
		System.out.println("Add cart button clicked");
	}

	@Then("^the sub-product should be added to the shopping cart$")
	public void the_sub_product_should_be_added_to_the_shopping_cart()
			throws Throwable {
	}

	public static String get_product_id(String productName) {
		String countryCode = (Login.countryCode).toLowerCase();
		String elementId = countryCode + "-"
				+ (StringUtils.replace(productName, " ", "-")).toLowerCase();

		return elementId;
	}

	@When("^I remove \"([^\"]*)\"$")
	public void I_remove(String productName) throws Throwable {
		new ProductOfferingPage().removeTheGivenProductFromCart(productName);
	}

	@Then("^cart should be empty$")
	public void cart_should_be_empty() throws Throwable {
		new ProductOfferingPage().verifyTheCartIsEmpty();
	}

	@Then("^I should see Main Features$")
	public void i_should_see_Main_Features() throws Throwable {
		Assert.assertTrue("Main Feature is not displaying",
				wd.findElement(By.cssSelector(".main-features")).isDisplayed());
	}

	@Then("^I should see Additional details$")
	public void i_should_see_Additional_details() throws Throwable {

		Assert.assertTrue("Additional details are not displaying", wd
				.findElement(By.cssSelector(".additional-details"))
				.isDisplayed()); // added by me

	}

	@Then("^I should see product age limit$")
	public void i_should_see_product_age_limit() throws Throwable {
		Assert.assertTrue("Product age limit is not displaying", wd
				.findElement(By.cssSelector(".product-eligibility"))
				.isDisplayed()); // added by me

	}
}
