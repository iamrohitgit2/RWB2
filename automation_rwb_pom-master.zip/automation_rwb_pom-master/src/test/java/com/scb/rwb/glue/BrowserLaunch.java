package com.scb.rwb.glue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BrowserLaunch {
	
	public static WebDriver driver;
	
	public static void main(String[] args) 
	{
		
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver",
				"Dependencies//chromedriver");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		driver = new ChromeDriver(options);
		driver.navigate().to("http://stackoverflow.com/questions/15546589/what-causes-httphostconnectexception");
//		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);

	}

}
