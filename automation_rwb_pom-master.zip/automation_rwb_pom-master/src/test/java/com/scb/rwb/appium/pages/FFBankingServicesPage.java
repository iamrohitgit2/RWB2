package com.scb.rwb.appium.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.utility.ReadTestData;

public class FFBankingServicesPage extends AppiumBasePage {


	/*@FindBy(id = "switch-component_bs-cheque-book-required-ca_wrapper")
	WebElement swchChequeBookRequiredCa;

	@FindBy(id = "select-component_bs-cheque-book-type-ca_wrapper")
	WebElement slctChequeBookTypeCa;

	@FindBy(id = "switch-component_bs-required-atm-debit-card_wrapper")
	WebElement swchRequiredAtmDebitCard;

	@FindBy(id = "text-component_bs-account-links-to-debit-card-atm_wrapper")
	WebElement txtAccountLinksToDebitCardAtm;

	@FindBy(id = "switch-component_bs-internet-banking_wrapper")
	WebElement swchInternetBanking;

	@FindBy(id = "switch-component_bs-sms-alerts_wrapper")
	WebElement swchSmsAlerts;

	@FindBy(id = "switch-component_bs-e-statement-casa_wrapper")
	WebElement swchEStatementCasa;

	@FindBy(id = "select-component_bs-e-statement-type-casa_wrapper")
	WebElement slctEStatementTypeCasa;

	@FindBy(id = "switch-component_bs-statement-hardcopy-casa_wrapper")
	WebElement swchStatementHardcopyCasa;

	@FindBy(id = "select-component_bs-statement-frequency-casa_wrapper")
	WebElement slctStatementFrequencyCasa;

	@FindBy(id = "switch-component_bs-e-statement-credit-card_wrapper")
	WebElement swchEStatementCreditCard;

	@FindBy(id = "select-component_bs-e-statement-type-credit-card_wrapper")
	WebElement slctEStatementTypeCreditCard;

	@FindBy(id = "switch-component_bs-statement-hardcopy-credit-card_wrapper")
	WebElement swchStatementHardcopyCreditCard;

	@FindBy(id = "select-component_bs-statement-frequency-credit-card_wrapper")
	WebElement slctStatementFrequencyCreditCard;*/

	FFClientKeyInformationPage ffCKI = new FFClientKeyInformationPage();
	
	
	@FindBy(xpath = "//div[contains(@id,'_bs-') and input[@type='text']]")
	List<WebElement> textFields;
	@FindBy(xpath = "//div[contains(@id,'_bs-') and input[@type='date']]")
	List<WebElement> dateFeilds;

	@FindBy(xpath = "//div[.//input[@class='ui-autocomplete-input']][contains(@id,'_bs-')]")
	List<WebElement> dropdownFeilds;

	@FindBy(xpath = "//div[input[@type='checkbox']][contains(@id,'_bs-')]")
	List<WebElement> switchFeilds;

	@FindBy(xpath = "//div[.//input[@type='radio']][contains(@id,'_bs-')]")
	List<WebElement> radioFeilds;

	@FindBy(css = "body")
	WebElement body;

	@FindBy(id = "next-button")
	WebElement btnNext;

	By tagNameInput = By.tagName("input");

	By tagNameLabel = By.tagName("label");
	
	Set<String> webele = new HashSet<String>();
	Set<String> csvkeys  = new HashSet<String>();
	HashMap<String, ArrayList<String>> addMap;
	public FFProductSpecificPage formFillForBankingServiceSection(int count) throws Exception {
		
		getNeedDataFromCSVMap(count);
		fillswitchFeilds();
		fillTextfields();
		filldatefields();
		filldropdownFeilds();
		
		verificationOfRequiedElemetsPresentInPage(webele, csvkeys);
		body.click();
		waitForvisiblityOfGivenElement(btnNext);
		btnNext.click();
		
		return new FFProductSpecificPage();

	}

	public  void fillTextfields() throws Exception {
		webele = formFillEnterText(textFields, addMap, webele);
		
	}

	public void filldatefields() throws Exception {
		webele = formFillEnterText(dateFeilds, addMap, webele);
		
	}

	public void fillswitchFeilds() throws Exception {
		webele = formFillSwitchElementToClick(switchFeilds, addMap, webele);
	}

	public void fillradioFeilds() {
		for (WebElement element : radioFeilds) {
			// if(Map.field contains element.getAttribute("id");
			// element.sendKeys( the value of the map);
		}
	}

	public void filldropdownFeilds() throws Exception {
		webele = formFillSelectElementFromDropdown(dropdownFeilds, addMap, webele);
	}
	
	
	public void getNeedDataFromCSVMap(int requiredCol){
		addMap = new HashMap<>();
		for (String data : ReadTestData.ffBSMap.keySet()) {
			if(!ReadTestData.ffBSMap.get(data).get(requiredCol).equals("N")){
				addMap.put(data, ReadTestData.ffBSMap.get(data));
			}
		}
		
		for (String dat : addMap.keySet()) {
			csvkeys.add(dat);
		}
	}

	/*public FFProductSpecificPage enterBankDetails() {
		formFillSwitchElementToClick(
				swchChequeBookRequiredCa,
				ReadTestData.ffData.getChequeBookRequiredCa());
		formFillSelectElementFromDropdown(
				slctChequeBookTypeCa,
				ReadTestData.ffData.getChequeBookTypeCa());
		formFillSwitchElementToClick(
				swchRequiredAtmDebitCard,
				ReadTestData.ffData.getRequiredAtmDebitCard());
		formFillEnterText(txtAccountLinksToDebitCardAtm,
				ReadTestData.ffData.getAccountLinksToDebitCardAtm());
		formFillSwitchElementToClick(swchInternetBanking,
				ReadTestData.ffData.getInternetBanking());
		formFillSwitchElementToClick(swchSmsAlerts,
				ReadTestData.ffData.getInternetBanking());
		formFillSwitchElementToClick(swchEStatementCasa,
				ReadTestData.ffData.geteStatementCasa());
		formFillSelectElementFromDropdown(
				slctEStatementTypeCasa,
				ReadTestData.ffData.getEeStatementTypeCasa());
		formFillSwitchElementToClick(
				swchStatementHardcopyCasa,
				ReadTestData.ffData.getStatementHardcopyCasa());
		formFillSelectElementFromDropdown(
				slctStatementFrequencyCasa,
				ReadTestData.ffData.getStatementFrequencyCasa());
		formFillSwitchElementToClick(
				swchEStatementCreditCard,
				ReadTestData.ffData.geteStatementCreditCard());
		formFillSelectElementFromDropdown(
				slctEStatementTypeCreditCard,
				ReadTestData.ffData.geteStatementTypeCreditCard());
		formFillSwitchElementToClick(
				swchStatementHardcopyCreditCard,
				ReadTestData.ffData.getStatementHardcopyCreditCard());
		formFillSelectElementFromDropdown(
				slctStatementFrequencyCreditCard,
				ReadTestData.ffData.getStatementFrequencyCreditCard());

		ffCKI.body.click();
		ffCKI.btnNext.click();

		return new FFProductSpecificPage();
	}*/

}
