package com.scb.rwb.appium.pages;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AOFPage extends AppiumBasePage {


	@FindBy(className = "UIAImage")
	WebElement imgUIA;
	
	@FindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAToolbar[3]/UIAButton[2]")
	WebElement btnSubmit;
	
	@FindBy(css = "#next-button")
	WebElement btnSubmitApplication;
		
	@FindBy(className= "component---info---title")
	WebElement lblTitle;
	
	@FindBy(className= "component---info---text")
	WebElement lblText;
	

	/**
	 * This Method Will Verify Whether The OZ Page Is Displayed Or Not And Click
	 * 
	 * @return
	 */
	public AOFPage verifyOZPageIsDisplaye() {
		imgUIA.click();
		return this;
	}
	
	/**
	 * This Method Will Verify Whether The Application Is Submitted Sucessfully Or Not
	 * 
	 * @return
	 */
	public ApplicationSubmitSucessfulPage clickSubmitButton(){
		sleep(10000);
		btnSubmit.click();
		sleep(5000);
		return new ApplicationSubmitSucessfulPage();
	}
	
	/**
	 * This Method Will Submit The Created Application
	 * 
	 * @return
	 */
	public AOFPage submitApplication(){
		waitForvisiblityOfGivenElement(btnSubmitApplication);
		btnSubmitApplication.click();
		return this;
	}
	
	/**
	 * This Method Will Verify Whether The OZ Form Is Displayed Or Not And Click
	 * 
	 * @return
	 */
	public AOFPage ozFormShouldBeDisplayed(){
		switchToNativeApp();	
		System.out.println("OZ Form Is Displayed");
		return this;
	}
	
	/**
	 * This Method Will Submit The OZ Form
	 * 
	 * @return
	 */
	public AOFPage submitOZForm(){
		sleep(10000);
		switchToNativeApp();
		waitForvisiblityOfGivenElement(btnSubmit);
		btnSubmit.click();
		sleep(5000);
		System.out.println("Submitting Application...");
		return this;
	}
	
	/**
	 * This Method Will Verify Whether Application Is Submitted Successfully Or Not
	 * 
	 * @return
	 */
	public AOFPage applicationShouldBeSubmitted(){
		sleep(15000);
		assertTrue(lblTitle.getText().equalsIgnoreCase("Application submitted successfully"));
		assertTrue(lblText.getText().contains("Once your application is reviewed, you'll receive a notification with your PDF application form."));
		return this;
	}

}
