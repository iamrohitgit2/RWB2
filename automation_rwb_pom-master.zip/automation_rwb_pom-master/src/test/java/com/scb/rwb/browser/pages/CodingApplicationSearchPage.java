package com.scb.rwb.browser.pages;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.text.StyledEditorKit.BoldAction;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Sleeper;
import org.openqa.selenium.support.ui.Wait;

import com.google.common.base.Function;
import com.scb.rwb.glue.TestData;

public class CodingApplicationSearchPage extends BrowserBasePage
{

	
	
	@FindBy(css=".search-toggle")
	WebElement searchToggle;
	
	@FindBy(css=".modal-search---input-field")
	WebElement searchInputField;
	
	@FindBy(css=".modal-search---placeholder")
	WebElement searchPlaceholder;
	
	@FindBy(css=".search-result-table")
	WebElement searchResult;
	
	@FindBy(className="modal-search---input-field")
	WebElement searchField;
	
	@FindBy(css=".search-result-table")
	WebElement searchTable;
	
	@FindBy(css=".status-icon-medium-")
	WebElement statusIcon;
	
	@FindBy(css=".search-result-table-row")
	List<WebElement> searchResultTable;
	
	By searchAppNumber = By.cssSelector(".search-app-number a");
	
	

	
	
	public CodingApplicationSearchPage landOnSearchPage()
	{
		
		browserWaitForVisibilityOfGivenElement(searchToggle);
		searchToggle.click();
		sleep(5000);
		return this;
		
	}
	
	public CodingApplicationSearchPage checkApplicationSearchWindowIsDisplayed()
	{
		specificImplicitWaitInSeconds(4);
		searchInputField.isDisplayed();
		sleep(10000);
		assertElementIsEnabled(searchPlaceholder);
		assertElementIsDisplayed(searchPlaceholder);
		return this;
		
	}
	
	
	public CodingApplicationSearchPage searchApplication()
	{
		
		sleep(2000);
		searchField.sendKeys(TestData.applicationId);
		sleep(12000);
		browserWaitForVisibilityOfGivenElement(searchResult);
		return this;
		
	}
	
	public CodingApplicationSearchPage searchResult()
	{
		specificImplicitWaitInSeconds(60);
		assertElementIsDisplayed(searchResult);
		sleep(2000);
		return this;
		
	}
	
	public CodingApplicationSearchPage checkApplicationStatus(String applicationStatus)
	{
		specificImplicitWaitInSeconds(40);
		verifyApplicationStatusInCodingStation(applicationStatus);
		return  this;
		
	}
	
	
	/**
	 * This method will helps the user to tap on the application from the search result
	 * Vicky 
	 * Mar 15, 2017
	 * 
	 * @return
	 */
	
	public CodingApplicationSearchPage tapOnTheApplication()
	{
		sleep(2000);
		boolean Application_present = false;
		System.out.println(searchResultTable);
		Iterator<WebElement> itr1 = searchResultTable.iterator();
		
		itr1.next();
		
		while (itr1.hasNext()) {
			WebElement Approw = itr1.next();
			String AppID = Approw.findElement(searchAppNumber).getText();
			System.out.println("Application Id present in the browser ="+ AppID);

			if (AppID.equalsIgnoreCase(TestData.applicationId)) {
				Application_present = true;
				System.out.println("Application "+AppID+ " is present!");
				jsClickTheApplicationFromTheSearchResult();
				break;
			}
		}
		if (!Application_present) {
			throw new RuntimeException(TestData.applicationId+ " Application not present ");
		}
		
		return this;
		
	}
	
	

}
