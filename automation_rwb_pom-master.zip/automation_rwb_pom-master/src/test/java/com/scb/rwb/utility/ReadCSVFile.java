package com.scb.rwb.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ReadCSVFile {

	/**
	 * This method will read the data from given csv file and return 2dArraylist
	 * 
	 * @param filePath
	 * @return
	 */
	public static ArrayList<ArrayList<String>> getDataFromCsvFile(
			String filePath) {
		ArrayList<ArrayList<String>> testData = new ArrayList<>();
		String line;
		try {
			BufferedReader file = new BufferedReader(new FileReader(new File(
					filePath)));
			while ((line = file.readLine()) != null) {
				ArrayList<String> data = new ArrayList<>();
				String[] colData = line.split(",", -1);
				for (int i = 0; i < colData.length; i++) {
					data.add(colData[i]);
				}
				testData.add(data);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return testData;

	}

	public static Map<String, HashMap<String, ArrayList<String>>> getDataFromAllCsvFile(
			String filePath) {
		Map<String, HashMap<String, ArrayList<String>>> testData = new HashMap<>();
		String line;
		File fil = new File(filePath);
		System.out.println(fil.isFile());
		String[] dst = fil.list();
		System.out.println("yyyy" + dst.length);
		for (String fileName : dst) {
			System.out.println(fileName);
			String fPath = filePath+fileName;
			HashMap<String, ArrayList<String>> td= getDataFromCsvFileReturnMap(fPath);
			testData.put(fileName, td);
			
		}
		return testData;

	}

	public static HashMap<String, ArrayList<String>> getDataFromCsvFileReturnMap(
			String filePath) {
		String line;
		HashMap<String, ArrayList<String>> testData = new HashMap<>();
		try {
			BufferedReader file = new BufferedReader(new FileReader(new File(
					filePath)));
			while ((line = file.readLine()) != null) {
				ArrayList<String> data = new ArrayList<>();
				String[] colData = line.split(",", -1);
				for (int i = 1; i < colData.length; i++) {
					data.add(colData[i]);
					
				}
				testData.put(colData[0], data);

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return testData;
	}
}
