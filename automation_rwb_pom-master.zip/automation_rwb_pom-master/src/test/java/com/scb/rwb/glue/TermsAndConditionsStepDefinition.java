package com.scb.rwb.glue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import com.scb.rwb.appium.pages.TermsAndConditionPage;
import com.scb.rwb.wrappers.ApplicationWrappers;

import io.appium.java_client.AppiumDriver;
import cucumber.api.PendingException;
import cucumber.api.java.en.When;

public class TermsAndConditionsStepDefinition extends ApplicationWrappers
{
	@When("^I \"([^\"]*)\" terms and conditions$")
	public void i_terms_and_conditions(String arg1) throws Throwable {
		new TermsAndConditionPage().clickTermsAndCondition();
	}

	@When("^I checkout the product and accept terms and conditions$")
	public void i_checkout_the_product_and_accept_terms_and_conditions()
			throws Throwable {
		new TermsAndConditionPage().clickCheckOutProductAndAcceptTermsAndCondition();
	}

}
