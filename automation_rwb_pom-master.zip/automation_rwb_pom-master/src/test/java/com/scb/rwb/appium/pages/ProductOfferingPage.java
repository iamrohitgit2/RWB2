package com.scb.rwb.appium.pages;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.scb.rwb.glue.AddProductstoCart;
import com.scb.rwb.glue.Login;
import com.scb.rwb.utility.ExcelRead;
import com.scb.rwb.utility.ReadTestData;

public class ProductOfferingPage extends AppiumBasePage {


	@FindBy(xpath = "//XCUIElementTypeStaticText[@value='PRODUCT OFFERING']")
	WebElement btnAddProduct;

	By nameProductOffering = By.name("PRODUCT OFFERING");

	@FindBy(css = ".number-of-items")
	WebElement iconCart;

	@FindBy(css = ".product-list")
	WebElement lstSubProduct;

	@FindBy(css = ".product-header .title")
	WebElement lblProductHeader;

	@FindBy(css = ".subtitle")
	WebElement lblProductDescription;

	@FindBy(css = ".product-tc .title")
	WebElement lnkTermsAndCondition;
	
	@FindBy(css = ".search-toggle")
	WebElement toggleSearch;

	/**
	 * This method will click the add product button and swtich the controll
	 * from native to web view.
	 * 
	 * @return
	 */
	public ProductOfferingPage clickAddProductAndSwitchToWebview() {
//		btnAddProduct.click();
		
//		waitForvisiblityOfGivenElement(SetupPage.winSetupWindow);
		waitForinvisiblityOfElementLocated(nameProductOffering);
		SetupPage.winSetupWindow.click();
		sleep(10000);
		switchFromNativeToWebView();
		return this;
	}

	/**
	 * This method will verify the given count and the actual count form the
	 * page
	 * 
	 * @param count
	 * @return
	 */
	public ProductOfferingPage verifyTheNoOFProduct(String count) {
		sleep(5000);
		waitForvisiblityOfGivenElement(iconCart);
		sleep(10000);
		String ActualProductCountCheck = iconCart.getText();
		System.out.println("Number of Addcart count should be  "
				+ ActualProductCountCheck);
		sleep(10000);
		Assert.assertEquals(count, ActualProductCountCheck);

		return this;
	}

	/**
	 * This method will add the given product to the cart
	 * 
	 * @param product
	 * @return
	 */
	public ProductOfferingPage addTheGivenProductToTheCart(String product) {
		AddProductstoCart.logger.info("Executing add products");
		String productID = getId(product);
		waitForvisiblityOfGivenCssselector(productID);
		jsClickOnAddProduct(productID);
		return this;
	}

	/**
	 * This method will remove the given product from the cart
	 * 
	 * @param product
	 * @return
	 */
	public ProductOfferingPage removeTheGivenProductFromCart(String productName) {
		String productId = getId(productName);
		System.out.println("Executing remove" + productId);
		jsClickOnAddProduct(productId);
		return this;
	}

	/**
	 * This method will verify the cart is empty
	 * 
	 * @return
	 */
	public ProductOfferingPage verifyTheCartIsEmpty() {
		String ActualProductCountCheck = iconCart.getText();
		System.out.println("actual result is" + ActualProductCountCheck);
		Assert.assertEquals("", ActualProductCountCheck);
		return this;
	}

	/**
	 * This method will verify the verification error message is displayed or
	 * not
	 * 
	 * @return
	 */
	public ProductOfferingPage verifyTheVerificationErrorMessageIsDispayed() {
		Assert.assertTrue(
				"Verification Error: Subproduct list is not displaying",
				lstSubProduct.isDisplayed());
		return this;
	}

	/**
	 * This method will verify all the sub product
	 * 
	 * @return
	 */
	public ProductOfferingPage viewAllProduct() {
		ArrayList<String> data = ExcelRead
				.getSubProductListFromProductOfferingXLS(Login.countryCode);
		for (int i = 0; i < data.size(); i++) {
			String product_id = getId(data.get(i));
			System.out.println(product_id);
			getWebElementById(product_id);
		}
		return this;
	}

	/**
	 * This method will tap on the given product name
	 * 
	 * @param productName
	 * @return
	 */
	public ProductOfferingPage tapOnTheGivenProduct(String productName) {
		String productId = getId(productName);
		System.out.println(productId);
		switchToNativeApp();
		getWebElementByXpath(
				"//UIAStaticText[contains(@name,'" + productName.toUpperCase()
						+ "')]").click();
		switchFromNativeToWebView();
		return this;
	}

	/**
	 * This method will verify the given product name.
	 * 
	 * @param expectedProductName
	 * @return
	 */
	public ProductOfferingPage verifyProductName(String expectedProductName) {
		sleep(2000);
		waitForvisiblityOfGivenElement(lblProductHeader);
		String subProductActName = lblProductHeader.getText();
		Assert.assertEquals(expectedProductName, subProductActName);
		System.out.println("Expected Sub Product Name got matched = "
				+ subProductActName);
		return this;
	}

	/**
	 * This method will verify the given Product description
	 * 
	 * @param expectedSubTitle
	 * @return
	 */
	public ProductOfferingPage verifyProductDecription(String expectedSubTitle) {
		String actualSubtitle = lblProductDescription.getText();
		Assert.assertEquals(expectedSubTitle.toUpperCase(), actualSubtitle);
		System.out.println("Expected Sub Title Name got matched = "
				+ actualSubtitle);
		return this;
	}

	/**
	 * This method will verify the terms and condition in the detail page
	 * 
	 * @return
	 */
	public ProductOfferingPage verifyTermsAndConditionInDetilsPage() {

		waitForvisiblityOfGivenElement(lnkTermsAndCondition);
		String expectedTerms = "Terms and Conditions";
		String actualTerms = lnkTermsAndCondition.getText();
		assertTrue(expectedTerms.equalsIgnoreCase(actualTerms));
		System.out.println("ExpectedTerms " + expectedTerms);
		return this;
	}

	/**
	 * This method will tap on the add cart button in product detail section
	 * 
	 * @return
	 */
	public ProductOfferingPage tapOnAddCardButtonOnProductDetailSection() {
		jsToClicAddCartButton();
		return this;
	}

	/**
	 * This method will verify that the product cant be addedd.
	 * 
	 * @param productName
	 * @return
	 */
	public ProductOfferingPage verifyNotAbleToAddProduct(String productName) {

		String productId = getId(productName);
		String AddButtonStatus = wd.findElement(
				By.cssSelector("." + productId + " .inner-text")).getText();
		Assert.assertEquals("ADD", AddButtonStatus);
		return this;
	}

	/**
	 * This method will add current product card product and loan product to the
	 * cart
	 * 
	 * @return
	 */
	public TermsAndConditionPage addCurrentProdCardProdLoanProdToCart() {
		ArrayList<String> data = ExcelRead
				.getSubProductListFromCurrentCardAndLoanXLS(ReadTestData.loginTD.getCountryCode());
//		sleep(20000);
		addProductsToCart(data);
//		sleep(20000);
		return new TermsAndConditionPage();
	}

	/**
	 * This method will add the given products to the cart
	 * 
	 * @param data
	 * @return
	 */
	public ProductOfferingPage addProductsToCart(ArrayList<String> data) {
		for (int i = 0; i < data.size(); i++) {
			String field = data.get(i);
			AddProductstoCart.logger.info("Product to add from excel " + field);
//			sleep(3000);
			addTheGivenProductToTheCart(field);
		}
		return this;
	}
	
	/**
	 * This Method Will Toggle Search In Search Page
	 * 
	 * @return
	 */
	public SearchPage navigateToApplicationSearch(){
		switchFromNativeToWebView();
		waitForvisiblityOfGivenElement(toggleSearch);
		toggleSearch.click();
		((JavascriptExecutor) wd).executeScript("document.getElementsByClassName('ember-view nav-button search-toggle toggle-button---off')[0].click()");
		return new SearchPage();
	}
}
