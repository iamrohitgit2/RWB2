package com.scb.rwb.browser.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.scb.rwb.wrappers.ApplicationWrappers;
import com.scb.rwb.wrappers.GenericWrappers;

public class BrowserBasePage extends ApplicationWrappers {


	public BrowserBasePage ()
	{
		PageFactory.initElements(driver,this);
		
	}

}
