package com.scb.rwb.appium.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.utility.ReadTestData;

public class FFCustomerDueDiligencePage extends AppiumBasePage {


	@FindBy(id = "switch-component_cdd-ao-for-business-puspose_wrapper")
	WebElement swchAoForBusinessPuspose;

	@FindBy(id = "select-component_cdd-purpose-acc-open_wrapper")
	WebElement slctPurposeAccOpen;

	@FindBy(id = "text-component_cdd-purpose-others-specify_wrapper")
	WebElement txtPurposeOthersSpecify;

	@FindBy(id = "text-component_cdd-deposit-amount-usd_wrapper")
	WebElement txtDepositAmountUsd;

	@FindBy(id = "select-component_cdd-mode-of-initial-funds-deposit_wrapper")
	WebElement slctModeOfInitialFundsDeposit;

	@FindBy(id = "switch-component_cdd-der-wealth-from-sanctioned-countries_wrapper")
	WebElement swchDerWealthFromSanctionedCountries;

	@FindBy(id = "select-component_cdd-savings-net-worth-usd_wrapper")
	WebElement slctSavingsNetWorthUsd;

	@FindBy(id = "select-component_cdd-source-of-wealth_wrapper")
	WebElement slctSourceOfWealth;

	@FindBy(id = "text-component_cdd-source-fund-specify_wrapper")
	WebElement txtSourceFundSpecify;

	FFClientKeyInformationPage ffCKI = new FFClientKeyInformationPage();
	
	@FindBy(xpath = "//div[contains(@id,'_cdd-') and input[@type='text']]")
	List<WebElement> textFields;
	@FindBy(xpath = "//div[contains(@id,'_cdd-') and input[@type='date']]")
	List<WebElement> dateFeilds;

	@FindBy(xpath = "//div[.//input[@class='ui-autocomplete-input']][contains(@id,'_cdd-')]")
	List<WebElement> dropdownFeilds;

	@FindBy(xpath = "//div[input[@type='checkbox']][contains(@id,'_cdd-')]")
	List<WebElement> switchFeilds;

	@FindBy(xpath = "//div[.//input[@type='radio']][contains(@id,'_cdd-')]")
	List<WebElement> radioFeilds;

	@FindBy(css = "body")
	WebElement body;

	@FindBy(id = "next-button")
	WebElement btnNext;

	By tagNameInput = By.tagName("input");

	By tagNameLabel = By.tagName("label");
	
	Set<String> webele = new HashSet<String>();
	Set<String> csvkeys  = new HashSet<String>();
	HashMap<String, ArrayList<String>> addMap;
	
	public FFFatcaPage formFillForCustomerDueDiligenceSection(int count) throws Exception {
		
		getNeedDataFromCSVMap(count);
		fillTextfields();
		filldatefields();
		filldropdownFeilds();
		fillswitchFeilds();
		verificationOfRequiedElemetsPresentInPage(webele, csvkeys);
		body.click();
		waitForvisiblityOfGivenElement(btnNext);
		btnNext.click();
		
		return new FFFatcaPage();

	}

	public  void fillTextfields() throws Exception {
		webele = formFillEnterText(textFields, addMap, webele);
		
	}

	public void filldatefields() throws Exception {
		webele = formFillEnterText(dateFeilds, addMap, webele);
		
	}

	public void fillswitchFeilds() throws Exception {
		webele = formFillSwitchElementToClick(switchFeilds, addMap, webele);
	}

	public void fillradioFeilds() {
		for (WebElement element : radioFeilds) {
			// if(Map.field contains element.getAttribute("id");
			// element.sendKeys( the value of the map);
		}
	}

	public void filldropdownFeilds() throws Exception {
		webele = formFillSelectElementFromDropdown(dropdownFeilds, addMap, webele);
	}

	
	public void getNeedDataFromCSVMap(int requiredCount){
		addMap = new HashMap<>();
		for (String data : ReadTestData.ffCDDMap.keySet()) {
			if(!ReadTestData.ffCDDMap.get(data).get(requiredCount).equals("N")){
				addMap.put(data, ReadTestData.ffCDDMap.get(data));
			}
		}
		
		for (String dat : addMap.keySet()) {
			csvkeys.add(dat);
		}
	}
	
	/*public FFFatcaPage enterCustomerDueDiligencePage() {
		formFillSwitchElementToClick(
				swchAoForBusinessPuspose,
				ReadTestData.ffData.getAoForBusinessPuspose());
		formFillSelectElementFromDropdown(
				slctPurposeAccOpen,
				ReadTestData.ffData.getPurposeAccOpen());
		formFillEnterText(txtDepositAmountUsd,
				ReadTestData.ffData.getDepositAmountUsd());
		formFillSelectElementFromDropdown(
				slctModeOfInitialFundsDeposit,
				ReadTestData.ffData.getModeOfInitialFundsDeposit());
		formFillSelectElementFromDropdown(
				slctSavingsNetWorthUsd,
				ReadTestData.ffData.getSavingsNetWorthUsd());
		formFillSelectElementFromDropdown(
				slctSourceOfWealth,
				ReadTestData.ffData.getSourceOfWealth());

		ffCKI.body.click();
		ffCKI.btnNext.click();
		return new FFFatcaPage();
	}*/

}
