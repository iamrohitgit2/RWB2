package com.scb.rwb.glue;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.scb.rwb.appium.pages.DocumentChekListPage;
import com.scb.rwb.wrappers.ApplicationWrappers;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class CaptureDocuments extends ApplicationWrappers{
	
	
	@When("^I capture mandatory documents$")
	public void i_capture_mandatory_documents() throws Throwable {
		
		new DocumentChekListPage().captureMandatoryDocument().clickNextButton();
	}

	
	@Then("^I should see all the captured docs$")
	public void i_should_see_all_the_captured_docs() throws Throwable {
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		List <WebElement> camera = wd.findElementsByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component .wb-upload");
		
		String dataSheetpath = TestData.TestDataPath;
		boolean Document_present;
		boolean CapturedImage_present; 
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
		
		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
		int noofRows= sheets.getLastRowNum();
		for(int i=0;i<=noofRows ;i++)
		{
			XSSFRow row = sheets.getRow(i);
			if ((row.getCell(0).getStringCellValue().equalsIgnoreCase("Frontline")) && (row.getCell(1).getStringCellValue().equalsIgnoreCase("Mandatory")))
				{
				String field=  row.getCell(2).getStringCellValue();
				System.out.println("value from excel "+ field );
				Document_present = false;
					for (WebElement cam : camera)
					{
						System.out.println("Value from browser for document check"+cam.getText());
						if (field.equalsIgnoreCase(cam.getText()))
						{
						Document_present=true;
						System.out.println(field+ " is present in the browser");
						cam.findElement(By.cssSelector(".ikon-camera")).click();
						wd.context("NATIVE_APP");
						wd.findElement(By.name("Cancel")).click();
						wd.findElement(By.name("done16px")).click();
						
						Set<String> AvailableContexts = wd.getContextHandles();
						for (String context : AvailableContexts)
						{
							if(context.contains("WEBVIEW"))
								wd.context(context);
						}
						break;
					}	
				}				
				CapturedImage_present= false;
				for (WebElement cam : camera)
				{
					String doc_title= cam.findElement(By.cssSelector(".wb-upload---variation")).getText();
					if (field.equalsIgnoreCase(doc_title))
					{
						CapturedImage_present=true;
						//System.out.println("Image present for "+ field);
						String no_of_pics = cam.findElement(By.cssSelector(".pics-counter")).getText();
						//System.out.println("value of number of pics" + no_of_pics);
						assertTrue(no_of_pics.equalsIgnoreCase("1 pics"));
						break;
					}
				
				}
				
				if(!CapturedImage_present)
				{
					throw new RuntimeException(field + " Images not found");
					
				}
			}
		}
		wd.findElementByCssSelector("#next-button").click(); 
	}
	
	
	@When("^I click on Next without capturing any document$")
	public void i_click_next() throws InterruptedException
	{
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	wd.findElementByCssSelector("#next-button").click();

	}
	
	@Then("^I should see a message of \"(.*?)\"$")
	public void i_should_see_message(String Message)
	{
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	
		List <WebElement> camera = wd.findElementsByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component .wb-upload");
		
		for(WebElement el : camera)
		{
			el.findElement(By.cssSelector(".wb-upload_show-error-alert"));
		}
	}
	
	@When ("^I tap on the \"(.*?)\" document and add image$")
	public void i_tap_and_image_in_the_document(String DocumentName)
	{
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		List <WebElement> camera = wd.findElementsByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component .wb-upload");
		boolean proof_present = false;
		for(WebElement cam : camera)
		{
			System.out.println(cam.getText());
			if (DocumentName.equalsIgnoreCase(cam.getText()))
			{
				proof_present=true;
				cam.findElement(By.cssSelector(".ikon-camera")).click();
				wd.context("NATIVE_APP");
				wd.findElement(By.name("PhotoCapture")).click();
				wd.findElement(By.name("Use Photo")).click();
				wd.findElement(By.name("done16px")).click();
				
				//Thread.sleep(3000);
				Set<String> AvailableContexts = wd.getContextHandles();
				for (String context : AvailableContexts)
				{
					if(context.contains("WEBVIEW"))
						wd.context(context);
				}
				break;
			}
		}
		System.out.println("executed statement befor if statement");
		if(!proof_present)
			throw new RuntimeException(DocumentName + " Documents not found");
	}

	@Then ("^I should be able add a image in \"(.*?)\" document$")
	public void image_should_be_present_in_the_document(String DocumentName)
	{
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		List <WebElement> camera = wd.findElementsByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component .wb-upload");
		boolean CapturedImage_present= false;
		for (WebElement cam : camera)
		{			
			String doc_title= cam.findElement(By.cssSelector(".wb-upload---variation")).getText();
			if (DocumentName.equalsIgnoreCase(doc_title))
			{
				CapturedImage_present=true;
				String no_of_pics = cam.findElement(By.cssSelector(".pics-counter")).getText();
				assertTrue(no_of_pics.equalsIgnoreCase("1 pics"));
				break;
			}
		}
		if(!CapturedImage_present)
			throw new RuntimeException(DocumentName + " Documents not found");
	}
	
	

	@When ("^I delete added image in \"(.*?)\" document$")	
	public void i_delete_image_in_document(String DocumentName) throws InterruptedException
		{
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		List <WebElement> camera = wd.findElementsByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component .wb-upload");
		
		for (WebElement cam : camera)
		{			
			String doc_title= cam.findElement(By.cssSelector(".wb-upload---variation")).getText();
			if (DocumentName.equalsIgnoreCase(doc_title))
			{
				cam.findElement(By.cssSelector(".delete")).click();
				//Thread.sleep(5000);
			}
		}
	}
	
	@Then ("^Image in \"(.*?)\" document should be removed$")	
	public void image_should_be_removed(String DocumentName){
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		List <WebElement> camera = wd.findElementsByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component .wb-upload");
		for (WebElement cam : camera)
		{			
			String doc_title= cam.findElement(By.cssSelector(".wb-upload---variation")).getText();
			if (DocumentName.equalsIgnoreCase(doc_title))
			{
				//String no_of_pics = cam.findElement(By.cssSelector(".pics-counter")).getText();
				//assertTrue(no_of_pics.equalsIgnoreCase("1 pics"));
				assertFalse(isElementPresent(By.cssSelector(".pics-counter")));
				break;
			}		
		}
	}
	
	private boolean isElementPresent(By by) {
	    try {
	    	wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	      wd.findElement(by);
	      return true;
	    } catch (NoSuchElementException e) {
	      return false;
	    }
	  }
	

	@When ("^I capture multiple images in mandatory documents$")
	public void i_capture_multiple_images_in_mandatory_document() throws IOException
	{
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		List <WebElement> camera = wd.findElementsByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component .wb-upload");
		
		String dataSheetpath = TestData.TestDataPath;
		boolean Document_present;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
		
		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
		int noofRows= sheets.getLastRowNum();
		for(int i=0;i<=noofRows ;i++)
		{
			XSSFRow row = sheets.getRow(i);
			if ((row.getCell(0).getStringCellValue().equalsIgnoreCase("Frontline")) && (row.getCell(1).getStringCellValue().equalsIgnoreCase("Mandatory")))	
				{
				String field=  row.getCell(2).getStringCellValue();
				System.out.println("value from excel "+ field );
				Document_present = false;
				for (WebElement cam : camera)
				{
					System.out.println(cam.getText());
					if (field.equalsIgnoreCase(cam.getText()))
					{
						Document_present=true;
						cam.findElement(By.cssSelector(".ikon-camera")).click();
						wd.context("NATIVE_APP");
						wd.findElement(By.name("PhotoCapture")).click();
						wd.findElement(By.name("Use Photo")).click();
						double no_of_images= row.getCell(4).getNumericCellValue();
						System.out.println("No of images needs to be captured " + no_of_images);
							for(int j=0 ; j< no_of_images-1; j++)
							{	
								wd.findElement(By.name("document capture camera")).click();
								wd.findElement(By.name("PhotoCapture")).click();
								wd.findElement(By.name("Use Photo")).click();
							}
						wd.findElement(By.name("done16px")).click();
						Set<String> AvailableContexts = wd.getContextHandles();
						for (String context : AvailableContexts)
						{
							if(context.contains("WEBVIEW"))
								wd.context(context);
						}
						break;
					}
				}
				if(!Document_present)
					throw new RuntimeException(field + " Documents not found");
			}
		}
	}
	
	@When ("^I capture multiple images in optional documents$")
	public void i_capture_multiple_images_in_optional_document() throws IOException, InterruptedException
	{	
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String dataSheetpath = TestData.TestDataPath;
		boolean Document_present;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
		
		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
		int noofRows= sheets.getLastRowNum();
		for(int i=0;i<=noofRows ;i++)
		{
			XSSFRow row = sheets.getRow(i);
			if ((row.getCell(0).getStringCellValue().equalsIgnoreCase("Frontline")) && (row.getCell(1).getStringCellValue().equalsIgnoreCase("Optional")))
				{
				String field=  row.getCell(2).getStringCellValue();
				((JavascriptExecutor) wd).executeScript("document.getElementsByClassName('ui-selectmenu-button')[0].click()");
				List<WebElement> dropdownItems = wd.findElementsByCssSelector(".wb-extra-upload .ui-menu-item");
				boolean OptionalDocument_Present= false;
				for (WebElement e : dropdownItems)
				{
					if (e.getText().equalsIgnoreCase(field))
						{
						OptionalDocument_Present= true;
						e.click();
						break;
						}		
				}
				if(!OptionalDocument_Present)
					throw new RuntimeException(field + " Optional Documents not found");
				
				List <WebElement> camera = wd.findElementsByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component .wb-upload");
				Document_present = false;
				for (WebElement cam : camera)
				{
					//System.out.println(cam.getText());
					String doc_title= cam.findElement(By.cssSelector(".wb-upload---variation")).getText();
					System.out.println("doc_title for optional = "+ doc_title);
					if (field.equalsIgnoreCase(doc_title))
					{
						Document_present=true;
						cam.findElement(By.cssSelector(".ikon-camera")).click();
						wd.context("NATIVE_APP");
						wd.findElement(By.name("PhotoCapture")).click();
						wd.findElement(By.name("Use Photo")).click();
						double no_of_images= row.getCell(4).getNumericCellValue();
						System.out.println("No of images needs to be captured " + no_of_images);
							for(int j=0 ; j< no_of_images-1; j++)
							{
								wd.findElement(By.name("document capture camera")).click();
								wd.findElement(By.name("PhotoCapture")).click();
								wd.findElement(By.name("Use Photo")).click();
							}
						wd.findElement(By.name("done16px")).click();
						Set<String> AvailableContexts = wd.getContextHandles();
						for (String context : AvailableContexts)
						{
							if(context.contains("WEBVIEW"))
								wd.context(context);
						}
						break;
					}
				}
				System.out.println("executed statement befor if statement");
				if(!Document_present)
					throw new RuntimeException(field + " Documents not found");
			}
		}
	}
	
	@Then("^All images should be added to documents successfully$")
	public void all_images_should_be_added_to_documents_successfully() throws Throwable {
		String dataSheetpath = TestData.TestDataPath;
		boolean Document_present;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
		
		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
		int noofRows= sheets.getLastRowNum();
		for(int i=0;i<=noofRows ;i++)
		{
			XSSFRow row = sheets.getRow(i);
			if ((row.getCell(0).getStringCellValue().equalsIgnoreCase("Frontline")))
				
				{
				String field=  row.getCell(2).getStringCellValue();
				double no_of_images= row.getCell(4).getNumericCellValue();
				int images1= (int) no_of_images;
				String images = String.valueOf(images1);
				System.out.println("no of image from excel"+ images);
				
				List <WebElement> camera = wd.findElementsByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component .wb-upload");
				Document_present = false;
				boolean CapturedImage_present= false;
				for (WebElement cam : camera)
				{
					String doc_title= cam.findElement(By.cssSelector(".wb-upload---variation")).getText();
					System.out.println("doc_title for optional = "+ doc_title);
					CapturedImage_present =false;
					if (field.equalsIgnoreCase(doc_title))
					{
						Document_present = true;
						CapturedImage_present=true;
						String no_of_pics = cam.findElement(By.cssSelector(".pics-counter")).getText();
						assertTrue(no_of_pics.equalsIgnoreCase(images+" pics"));
						break;
					}
				}
				if(!CapturedImage_present)
					throw new RuntimeException(field + " Documents not found");
			}
		}
	}
}