package com.scb.rwb.glue;

import java.io.FileInputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rwb.wrappers.ApplicationWrappers;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class ApplicationEnquiry extends ApplicationWrappers
{
	WebDriverWait wait = new WebDriverWait(wd, 30);
	public XSSFRow row = null;
	
	
	@And("^I enter the application number in the search screen and verify childReference for\"(.*?)\"$")
public void I_enter_the_application_number_in_the_search_screen_and_verify_childReference(String Country) throws Throwable 
	{
		
		XSSFSheet sheet;
		String FilePath = "/Users/scopeinternational/Desktop/APP_Enquiry/cems-mobile-automation/Dependencies/Application-Inquiry.xlsx";
		System .out.println(FilePath);
		FileInputStream fis = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
	     sheet = workbook.getSheet("AE");
		Thread.sleep(4000);
		
		switch(Country) 
		{
		case "AE" :
			int noofRows= (sheet.getLastRowNum());
			System.out.println(noofRows);
			for(int i=1;i<=noofRows;i++)
			{
				XSSFRow row= sheet.getRow(i);
				String ApplicationID = row.getCell(3).getStringCellValue();
				System.out.println(ApplicationID);
				wd.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				
				//if( ApplicationID == "SameID")
				//{
				
					wd.findElementByCssSelector(".modal-search---input-field").sendKeys(ApplicationID);
					
					
				//}
				for(int j=1;j<=i;j++)
				{
					
				wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	
				 Thread.sleep(20000);
				boolean ReferenceID_present= false;
				XSSFRow Refrow= sheet.getRow(j);
				String ExpectedreferenceNumber = Refrow.getCell(4).getStringCellValue();
				System.out.println("FromExcel" +ExpectedreferenceNumber);
				List<WebElement> elements = wd.findElementsByCssSelector(".search-result-table-row");
				System.out.println(elements.size());
				 Iterator<WebElement> itr1 = elements.iterator();
				  itr1.next();
					
				  while(itr1.hasNext()) 
				  {
					  WebElement Approw = itr1.next();
					  List<WebElement> insiderow= Approw.findElements(By.cssSelector(".search-app-number a"));
					  System.out.println(insiderow.size());
					  String RefereceID=insiderow.get(1).getText();
					  //String RefereceID = Approw.findElement(By.xpath("//div[@class='search-app-number']")).getText();
					   System.out.println("FromApplication"+ RefereceID);
			        if (RefereceID.equalsIgnoreCase(ExpectedreferenceNumber))
			        {
			        	ReferenceID_present = true;
			        	Approw.findElement(By.cssSelector(".search-app-number a")).click();
			        	break;
			        }
			        
			       
				 }
				  
				  if(!ReferenceID_present)
					{
					  throw new RuntimeException(ExpectedreferenceNumber + " in the search result");
					}
			    
				}
				
				
				}
			break;
				
		}
			
			
	}

	



	
	@Then("^search result should be displayed to the RM with relevant application ID and Ref$")
	public void search_result_should_be_displayed_to_the_RM_with_relevant_application_ID() throws Throwable 
	{
			
		
	}

	@When("^I navigate to Application search in IPAD$")
	public void i_navigate_to_Application_search() throws Throwable {
	
		Set<String> AvailableContexts = wd.getContextHandles();
		for (String context : AvailableContexts)
		{
			if(context.contains("WEBVIEW"))
				wd.context(context);
		}
		
		System.out.println("click search toggle ");
		wd.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		wd.findElement(By.cssSelector(".search-toggle")).click();
		//((JavascriptExecutor) wd).executeScript("document.getElementsByClassName('ember-view nav-button search-toggle toggle-button---off')[0].click()");
		wd.findElement(By.cssSelector(".modal-search---input-field")).click();
		System.out.println("toggle clicked");
		
	}




}
