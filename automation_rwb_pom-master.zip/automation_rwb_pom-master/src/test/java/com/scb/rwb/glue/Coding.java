package com.scb.rwb.glue;

import static org.junit.Assert.assertTrue;
import io.appium.java_client.AppiumDriver;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.scb.rwb.browser.pages.CodingApplicationMasterView;
import com.scb.rwb.browser.pages.CodingApplicationQueuesPage;
import com.scb.rwb.browser.pages.CodingApplicationSearchPage;
import com.scb.rwb.wrappers.ApplicationWrappers;
import com.standardchartered.genie.FrameworkGlue;
import com.thoughtworks.xstream.mapper.Mapper.Null;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Coding extends ApplicationWrappers {

	public FileInputStream fileInputstream = null;
	public FileOutputStream fileOutputstream = null;
	private XSSFWorkbook workbook = null;
	private XSSFSheet sheet = null;
	private XSSFRow row = null;
	private XSSFCell cell = null;

	Logger logger = Logger.getLogger("Coding");

//	public static WebDriver driver;
	//WebDriverWait wait = new WebDriverWait(wd, 30);

	WebDriverWait expwait;
	private HashMap<String, String> fieldset;
	public HashMap<String, String> sectionCode;
	public HashMap<String, String> sectionId;

	@Given("^I am on the Coding home page$")
	public void i_am_on_the_Coding_home_page() throws Throwable {
//		System.setProperty("webdriver.chrome.driver",
//				"Dependencies//chromedriver");
//		ChromeOptions options = new ChromeOptions();
//		options.addArguments("--start-maximized");
//		driver = new ChromeDriver(options);
//		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
//		driver.get("https://sit.staff.global.standardchartered.com/origination/#/?COUNTRYCODE="
//				+ Login.countryCode
//				+ "&INSTANCECODE=CB_"
//				+ Login.countryCode
//				+ "&PWID=" + Login.CodingUsername + "&SSO=fake_coding");
//		driver.findElement(By.cssSelector(".app-queue-container"));
//		driver.findElement(By.cssSelector("#app-queue"));

		new CodingApplicationQueuesPage().lauchCodingStation();
		logger.info("Inside the Coding Station Home Screen");
	}

	@When("^I navigate to application search from coding$")
	public void i_navigate_to_application_search_from_coding() throws Throwable {

//		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
//		WebDriverWait wait = new WebDriverWait(driver, 30);
//		wait.until(ExpectedConditions.visibilityOf((WebElement) driver.findElement(By.cssSelector(".search-toggle"))));
//		specificImplicitWaitInSeconds(1);
//		driver.findElement(By.cssSelector(".search-toggle")).click();
		new CodingApplicationSearchPage().landOnSearchPage();
		logger.info("Inside the search Application Screen");
		
	}

	@Then("^Application search window should be displayed$")
	public void application_search_window_should_be_displayed()
			throws Throwable {

//		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//		driver.findElement(By.cssSelector(".modal-search---input-field"));
//		Thread.sleep(12000);
//		Assert.assertTrue(driver.findElement(
//				By.cssSelector(".modal-search---placeholder")).isEnabled()); // added
		new CodingApplicationSearchPage().checkApplicationSearchWindowIsDisplayed();	
																				
	}

	@When("^I Search an application$")
	public void i_Search_an_application() throws Throwable {

//		Thread.sleep(5000);
       
//		driver.findElement(By.className("modal-search---input-field")).sendKeys(TestData.applicationId);
//		Thread.sleep(3000);
		new CodingApplicationSearchPage().searchApplication();
		logger.info("Search screen passing the ApplicationId");
//		Thread.sleep(15000);
	}

	@Then("^I should see the search result$")
	public void i_should_see_the_search_result() throws Throwable {
//		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
//		driver.findElement(By.cssSelector(".search-result-table"));

//		Assert.assertTrue(driver.findElement(By.cssSelector(".search-result-table-row")).isDisplayed()); // added
																			// by
		new CodingApplicationSearchPage().searchResult();																	// me
		logger.info("Search results displayed successfully");
//		Thread.sleep(20000);
	}

	@Then("^I should be able to see the searched application with \"(.*?)\" status$")
	public void i_should_be_able_to_see_the_searched_application_in_the_result(
			String applicationStatus) throws Throwable {
		
		new CodingApplicationSearchPage().checkApplicationStatus(applicationStatus);
//		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
//		Thread.sleep(7000);
//		String statusId = ".status-icon-medium-" + applicationStatus;
//		statusId = StringUtils.replace(statusId, " ", "-").toLowerCase();
//		boolean Application_present = false;
//
//		List<WebElement> elements = driver.findElements(By
//				.cssSelector(".search-result-table-row"));
//		Iterator<WebElement> itr1 = elements.iterator();
//		itr1.next();
//
//		while (itr1.hasNext()) {
//			WebElement Approw = itr1.next();
//			String AppID = Approw.findElement(
//					By.cssSelector(".search-app-number a")).getText();
//			Wait<WebDriver> fwait = new FluentWait<WebDriver>(driver)
//					.withTimeout(50, TimeUnit.SECONDS).pollingEvery(1,
//							TimeUnit.SECONDS);
//			WebElement Search_list = fwait
//					.until(new Function<WebDriver, WebElement>() {
//
//						public WebElement apply(WebDriver driver) {
//							String searhApp = driver
//									.findElement(
//											By.xpath("//div[@class='search-result-table']"))
//									.getText();
//
//							System.out.println(searhApp);
//							return driver.findElement(By
//									.xpath("//div[@class='search-result-table']"));
//
//						}
//
//					});
//
//			System.out.println("Application Id present in the browser ="
//					+ AppID);
//
//			if (AppID.equalsIgnoreCase(TestData.applicationId)) {
//				Application_present = true;
//				Approw.findElement(By.cssSelector(statusId));
//				break;
//			}
//
//		}
//
//		if (!Application_present) {
//			throw new RuntimeException(TestData.applicationId
//					+ " Application not present ");
//		}
	}

	@When("^I tap on the application from search result$")
	public void i_tap_on_the_application_from_search_result() throws Throwable {

//		Thread.sleep(2000);

		logger.info("I tap on the application number from the search result screen");
		new CodingApplicationSearchPage().tapOnTheApplication();
//		boolean Application_present = false;
//
//		List<WebElement> elements = driver.findElements(By
//				.cssSelector(".search-result-table-row"));
//
//		Iterator<WebElement> itr1 = elements.iterator();
//		itr1.next();
//
//		while (itr1.hasNext()) {
//			WebElement Approw = itr1.next();
//			String AppID = Approw.findElement(
//					By.cssSelector(".search-app-number a")).getText();
//			System.out.println("Application Id present in the browser ="
//					+ AppID);
//
//			if (AppID.equalsIgnoreCase(TestData.applicationId)) {
//
//				Application_present = true;
//
//				System.out.println("App present");
//
//				((JavascriptExecutor) driver)
//						.executeScript("document.getElementsByClassName('search-app-number')[0].getElementsByTagName('a')[0].click()");
//
//				// Approw.findElement(By.cssSelector(".search-app-number")).click();
//				break;
//			}
//		}
//		if (!Application_present) {
//			throw new RuntimeException(TestData.applicationId
//					+ " Application not present ");
//		}
	   
	}

	@Then("^I should see the Master Application Detail$")
	public void i_should_see_the_Master_Application_Detail() throws Throwable {

		// driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		Thread.sleep(20000);

		Assert.assertTrue(driver.findElement(
				By.xpath("//div[@class='modal-content']")).isDisplayed());
		System.out.println("Master Application Detail page is displaying");
		Assert.assertTrue(driver.findElement(
				By.xpath("//h2[@class='client-name']")).isDisplayed()); // added
																		// by me
		System.out.println("Client name is displaying");
		Thread.sleep(10000);
	}

		
	

	@Then("^I should see the application status as \"(.*?)\" in master details$")
	public void i_should_see_the_application_status_as_coding_in_master_detail(
			String AppStatus) throws Throwable {
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		Thread.sleep(5000);

		String app_status = driver.findElement(
				By.cssSelector(".application-status .top-status")).getText();
		System.out.println(app_status);
		Thread.sleep(7000);
		assertTrue(app_status.equalsIgnoreCase(AppStatus));
	}

	

	@When("^I tap on Info Icon$")
	public void i_tap_on_info_icon() throws Throwable {

		WebDriverWait wait = new WebDriverWait(driver, 70);
		Thread.sleep(3000);
		WebElement element2 = wait.until(ExpectedConditions
				.elementToBeClickable(By.cssSelector(".app-info div")));
		element2.click();
		logger.info("Info Icon is clicked");

	}

	

	

	@Then("^I should be able to see info icon details$")
	public void i_should_be_able_to_see_info_icon_details() throws Throwable {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.cssSelector(".tooltipster-content"));
		// driver.findElement(By.cssSelector(".tooltip-app-number"));
		String actualappno = driver
				.findElement(
						By.xpath("//div[@class='tooltipster-content']/descendant::div[@class='tooltip-app-number']/span[2]"))
				.getText(); // added by me
		Assert.assertTrue(actualappno.equalsIgnoreCase(TestData.applicationId)); // added by me
																					
																					
		driver.findElement(By.cssSelector("body")).click();
	}

	

	@When("^I tap on \"(.*?)\" tab in coding$")
	public void i_tap_on_documents_tab_in_coding(String tabName)
			throws Throwable {
		new CodingApplicationMasterView().switchToRespectiveTab(tabName);
//		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//        Thread.sleep(20000);
		//wait.until(ExpectedConditions.visibilityOf((WebElement) driver.findElements(By.cssSelector("li.ember-view"))));
		
//		List<WebElement> Tabs = driver.findElements(By
//				.cssSelector("li.ember-view"));
//		for (WebElement Tab : Tabs) {
//			System.out.println(Tab.getText());
//			Thread.sleep(2000);
//			if ((tabName).equalsIgnoreCase(Tab.getText())) {
//				Thread.sleep(6000);
//				Tab.click();
//			}
//		}
	}

	@Then("^I should be able to see \"(.*?)\" documents$")
	public void i_should_be_able_to_see_frontline_supporting_documents(
			String Doctype) throws Throwable {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		if (Doctype.equalsIgnoreCase("Frontline supporting"))
			Doctype = "Frontline";

		String dataSheetpath = TestData.TestDataPath;
		boolean Documet_present = false;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);

		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
		int noofRows = sheets.getLastRowNum();
		for (int i = 0; i <= noofRows; i++) {
			XSSFRow row = sheets.getRow(i);
			if ((row.getCell(0).getStringCellValue().equalsIgnoreCase(Doctype))
					&& (row.getCell(1).getStringCellValue()
							.equalsIgnoreCase("Mandatory")))

			{
				String doc_required = row.getCell(2).getStringCellValue();
				System.out.println("documentTocheck from excel" + doc_required);
				Documet_present = false;
				List<WebElement> a = driver.findElements(By
						.className("doc-title"));
				Iterator<WebElement> ab = a.iterator();
				while (ab.hasNext()) {
					String docvalue = ab.next().getText();
					if (docvalue.trim().equalsIgnoreCase(doc_required)) {
						System.out.println(" Mandatory Documents are  "
								+ doc_required);
						Documet_present = true;
						break;
					}
				}
				if (!Documet_present) {
					throw new RuntimeException(
							"MandatoryDocuments are not found " + doc_required);
				}
			}

		}
	}

	@When("^I tap on Add documents in coding$")
	public void i_tap_on_add_documents_in_coding() throws Throwable {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		Thread.sleep(10000);

		List<WebElement> Tabs = driver.findElements(By
				.cssSelector("li.ember-view"));
		for (WebElement Tab : Tabs) {
			System.out.println(Tab.getText());
			if (("Documents").equalsIgnoreCase(Tab.getText())) {
				Tab.click();
			}
		}
		driver.findElement(By.xpath("//button[@class='add-doc']")).click();
		// driver.findElement(By.className("add-doc")).click();
		// driver.findElement(By.xpath("//div[contains(text(),'Add Document')]")).click();

	}

	@When("^I add additional coding supporting document$")
	public void i_add_additional_coding_supporting_document() throws Throwable {
		Thread.sleep(2000);

		String dataSheetpath = TestData.TestDataPath;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);

		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
		int noofRows = sheets.getLastRowNum();
		for (int i = 0; i <= noofRows; i++) {
			XSSFRow row = sheets.getRow(i);
			if ((row.getCell(0).getStringCellValue()
					.equalsIgnoreCase("Additional supporting document"))
					&& (row.getCell(1).getStringCellValue()
							.equalsIgnoreCase("Mandatory")))

			{
				String doc_name = row.getCell(2).getStringCellValue();

				driver.findElement(By.id("documentType")).sendKeys(doc_name);
				Thread.sleep(10000);
				System.out.println("document type added");
				driver.findElement(By.className("file_input_div")).click();
				driver.manage().timeouts()
						.implicitlyWait(120, TimeUnit.SECONDS);
				File file = new File(System.getProperty("user.dir")
						+ "/Dependencies/docutitlt.pdf");
				// using robot class for file uploading
				StringSelection stringSelection = new StringSelection(
						file.getAbsolutePath());
				Toolkit.getDefaultToolkit().getSystemClipboard()
						.setContents(stringSelection, null);
				// Cmd + Tab is needed since it launches a Java app and the
				// browser looses focus
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_META);
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyRelease(KeyEvent.VK_META);
				robot.keyRelease(KeyEvent.VK_TAB);
				robot.delay(500);
				// Open Goto window
				robot.keyPress(KeyEvent.VK_META);
				robot.keyPress(KeyEvent.VK_SHIFT);
				robot.keyPress(KeyEvent.VK_G);
				robot.keyRelease(KeyEvent.VK_META);
				robot.keyRelease(KeyEvent.VK_SHIFT);
				robot.keyRelease(KeyEvent.VK_G);
				// Paste the clipboard value
				robot.keyPress(KeyEvent.VK_META);
				robot.keyPress(KeyEvent.VK_V);
				robot.keyRelease(KeyEvent.VK_META);
				robot.keyRelease(KeyEvent.VK_V);
				// Press Enter key to close the Goto window and Upload window
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);
				robot.delay(500);
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.delay(500);
				robot.keyRelease(KeyEvent.VK_ENTER);
				// robot.delay(500);
				// robot.keyRelease(KeyEvent.VK_ENTER);
				Thread.sleep(40000);
				driver.findElement(By.id("button-cancel")).click();
				Thread.sleep(10000);
				logger.info("Additional Supporting Document upload successfully");

			}
		}
	}

	@When("^Added document should be displayed in coding supporting documents$")
	public void added_additional_document_should_be_displayed_in_coding_supporting_document()
			throws Throwable {

		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		Thread.sleep(10000);
		String dataSheetpath = TestData.TestDataPath;
		boolean Documet_present = false;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);

		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
		int noofRows = sheets.getLastRowNum();
		for (int i = 0; i <= noofRows; i++) {
			XSSFRow row = sheets.getRow(i);
			if ((row.getCell(0).getStringCellValue()
					.equalsIgnoreCase("Additional supporting document"))
					&& (row.getCell(1).getStringCellValue()
							.equalsIgnoreCase("Mandatory")))

			{
				String doc_required = row.getCell(2).getStringCellValue();
				System.out.println("documentTocheck from excel '"
						+ doc_required);
				Documet_present = false;
				List<WebElement> a = driver.findElements(By
						.className("doc-title"));
				System.out.println(a.size());
				Iterator<WebElement> ab = a.iterator();
				while (ab.hasNext()) {
					String docvalue = ab.next().getText();
					System.out.println(docvalue);
					if (docvalue.trim().equalsIgnoreCase(doc_required)) {
						System.out.println(" Additional Documents are  "
								+ doc_required);
						Documet_present = true;
						break;
					}
				}
				if (!Documet_present) {
					throw new RuntimeException(
							" Additional documents are not found "
									+ doc_required);
				}
			}

		}
	}

	@When("^I Pass Frontline supporting documents$")
	public void I_pass_frontline_supporting_documents() throws Throwable {
		
		new CodingApplicationMasterView().passingTheFrontlineDocumentsAvailableForQualityCheck();
//		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//
//		System.out.println("I Pass Frontline supporting documents");
//		String dataSheetpath = TestData.TestDataPath;
//		boolean Documet_present = false;
//		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
//		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
//
//		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
//		int noofRows = sheets.getLastRowNum();
//		for (int i = 0; i <= noofRows; i++) {
//			XSSFRow row = sheets.getRow(i);
//			if ((row.getCell(0).getStringCellValue()
//					.equalsIgnoreCase("Frontline"))
//					&& (row.getCell(1).getStringCellValue()
//							.equalsIgnoreCase("Mandatory"))) {
//				System.out.println("INside if condition for doc image");
//				String doc_required = row.getCell(2).getStringCellValue();
//				System.out.println("document To check from excel"
//						+ doc_required);
//				Documet_present = false;
//				List<WebElement> a = driver.findElements(By
//						.className("doc-title"));
//				Iterator<WebElement> ab = a.iterator();
//				while (ab.hasNext()) {
//					WebElement document = ab.next();
//					String docvalue = document.getText();
//					if (docvalue.trim().equalsIgnoreCase(doc_required)) {
//						System.out.println(" Additional Documents are  "
//								+ doc_required);
//						Documet_present = true;
//						Thread.sleep(1500);
//						document.click();
//						Thread.sleep(3000);
//						driver.manage().window().maximize();
//						((JavascriptExecutor) driver)
//								.executeScript("document.getElementsByClassName('document-quality')[0].children[1].click()");
//						// ((JavascriptExecutor)
//						// driver).executeScript("document.getElementsByTagName('button')[11].click()");
//						break;
//					}
//				}
//				if (!Documet_present) {
//					throw new RuntimeException(
//							" Additional documents are not found "
//									+ doc_required);
//				}
//			}
//
//		}
	}

	@Then("^The image quality of the documents should be displayed PASS$")
	public void the_image_quality_frontline_supporting_documents_should_be_pass()
			throws Throwable {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		String dataSheetpath = TestData.TestDataPath;
		boolean Documet_present = false;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);

		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
		int noofRows = sheets.getLastRowNum();
		for (int i = 0; i <= noofRows; i++) {
			XSSFRow row = sheets.getRow(i);
			if ((row.getCell(0).getStringCellValue()
					.equalsIgnoreCase("Frontline"))
					&& (row.getCell(1).getStringCellValue()
							.equalsIgnoreCase("Mandatory")))

			{
				String doc_required = row.getCell(2).getStringCellValue();
				System.out.println("documentTocheck from excel" + doc_required);
				Documet_present = false;
				List<WebElement> a = driver.findElements(By
						.cssSelector(".master-app-row"));
				Iterator<WebElement> ab = a.iterator();
				while (ab.hasNext()) {
					WebElement documentrow = ab.next();
					String docvalue = documentrow.findElement(
							By.cssSelector(".doc-title")).getText();
					if (docvalue.trim().equalsIgnoreCase(doc_required)) {
						System.out.println(" Documents are  " + doc_required);
						Documet_present = true;
						documentrow.findElement(By
								.cssSelector(".status-icon-medium-approved"));
						break;
					}
				}
				if (!Documet_present) {
					throw new RuntimeException(" Documents are not found "
							+ doc_required);
				}
			}

		}
	}

	@When("^I fill in Coding section fields$")
	public void i_fill_in_coding_section_field() throws Throwable {

		
		new CodingApplicationMasterView().feedCodingValuesInTheApplication();
//		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//		Thread.sleep(5000);
//		String dataSheetpath = TestData.TestDataPath;
//		FileInputStream fileInputstream = new FileInputStream(dataSheetpath);
//		XSSFWorkbook workbook = new XSSFWorkbook(fileInputstream);
//		HashMap<String, String> sectionId = new HashMap<String, String>();
//		HashMap<String, String> sectionCode = new HashMap<String, String>();
//		XSSFSheet sheet = workbook.getSheet("Coding");
//		int noofRows = sheet.getLastRowNum();
//
//		XSSFRow row;
//
//		for (int i = 0; i <= noofRows; i++) {
//			row = sheet.getRow(i);
//			String field = row.getCell(0).getStringCellValue();
//			String type = row.getCell(1).getStringCellValue();
//			String value = row.getCell(2).getStringCellValue().trim();
//			String sectioncode = row.getCell(3).getStringCellValue();
//			String componentId = getComponentId(sectioncode, type, field);
//
//			System.out.println("componentId = " + componentId);
//			// String componentId= type+"-component_cod-"+field+"_wrapper";
//			componentId = StringUtils.replace(componentId, " ", "-")
//					.toLowerCase();
//			// System.out.println("Going to fill "+ componentId);
//			// System.out.println("Vlaue is '"+value+"'");
//
//			if (value != null && !(value.equalsIgnoreCase(""))) {
//				if (type.equalsIgnoreCase("select"))
//					fill_in_select_component(componentId, value);
//				else if (type.equalsIgnoreCase("text"))
//					fill_in_text_component(componentId, value);
//				else if (type.equalsIgnoreCase("radio-group"))
//					fill_in_radio_component(componentId, value);
//				else if (type.equalsIgnoreCase("switch"))
//					fill_in_switch_component(componentId, value);
//				else if (type.equalsIgnoreCase("textarea"))
//					fill_in_textarea_component(componentId, value);
//			}
//		}
	}

//	private void fill_in_radio_component(String componentId, String value) {
//
//		String radio_option = value;
//
//		List<WebElement> elements = driver.findElement(By.id(componentId))
//				.findElements(By.tagName("label"));
//
//		for (WebElement element : elements) {
//			System.out.println(element.getText());
//			if (radio_option.equalsIgnoreCase(element.getText())) {
//				element.click();
//			}
//
//		}
//	}
//
//	private void fill_in_switch_component(String componentId, String value) {
//		String Option = value;
//		if (Option.equalsIgnoreCase("Yes")) {
//			WebElement a = driver.findElement(By.id(componentId)).findElement(
//					By.tagName("label"));
//			a.click();
//		}
//
//	}
//
//	private void fill_in_text_component(String componentId, String value) {
//
//		WebElement a = driver.findElement(By.id(componentId)).findElement(
//				By.tagName("input"));
//		a.sendKeys(value);
//		if (componentId.contains("date")) {
//			System.out
//					.println(("document.getElementById('" + componentId
//							+ "').getElementsByTagName('input')[0].value='"
//							+ value + "'"));
//			((JavascriptExecutor) driver)
//					.executeScript("document.getElementById('" + componentId
//							+ "').getElementsByTagName('input')[0].value='"
//							+ value + "'");
//		}
//
//	}
//
//	private void fill_in_textarea_component(String componentId, String value) {
//		WebElement a = driver.findElement(By.id(componentId)).findElement(
//				By.tagName("textarea"));
//		a.sendKeys(value);
//
//	}
//
//	private void fill_in_select_component(String componentId, String value)
//			throws InterruptedException, AWTException {
//
//		WebElement a = driver.findElement(By.id(componentId)).findElement(
//				By.tagName("input"));
//		a.clear();
//		a.click();
//		a.sendKeys(value);
//		Thread.sleep(1000);
//		// Robot robot = new Robot();
//
//	}

//	private String getComponentId(String sectioncode, String componentType,
//			String componentname) {
//		String componentId = componentType + "-component_" + sectioncode + "-"
//				+ componentname + "_wrapper";
//		componentId = StringUtils.replace(componentId, " ", "-").toLowerCase();
//		return (componentId);
//	}

	@When("^I go to coding station$")
	public void i_go_to_coding_station() throws Throwable {

		Thread.sleep(5000);
		i_am_on_the_Coding_home_page();
	}

	@When("^I click submitted application in coding queue$")
	public void i_click_appl_in_coding_station() throws Throwable {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		boolean applicationPresent = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By
				.cssSelector(".appNumber"))));

		List<WebElement> applicationsList = driver.findElements(By
				.cssSelector(".appNumber"));
		for (WebElement element : applicationsList) {

			System.out.println(element.getText());

			if ((TestData.applicationId).equalsIgnoreCase(element.getText())) {

				element.click();
				applicationPresent = true;
				break;
			}
		}

		if (!applicationPresent) {
			throw new RuntimeException(TestData.applicationId
					+ " Application not found");
		}

		driver.findElement(By.cssSelector(".application-master"));
		driver.findElement(By.cssSelector(".app-master-header"));
		driver.findElement(By.cssSelector(".client-name"));

	}

	@When("^I go to documents tab of coding station$")
	public void i_go_to_documents_tab_of_coding() throws Throwable {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		i_tap_on_documents_tab_in_coding("Documents");
	}

	@Then("^I should be able to see the \"(.*?)\", \"(.*?)\" button$")
	public void i_should_be_able_to_for_notes(String ExpectedNotesBtn,
			String ExpectedPreviousBtn) throws Throwable {
		Thread.sleep(1000);
		String PreviuosBtnFromPge = driver.findElement(
				By.cssSelector(".modal---wrapper .previous-btn")).getText();
		System.out.println("web" + PreviuosBtnFromPge);
		assertTrue(ExpectedPreviousBtn.equalsIgnoreCase(PreviuosBtnFromPge));
		Thread.sleep(1000);
		driver.findElement(By.cssSelector(".content .ember-text-area"))
				.sendKeys("Notes");
		String NotesBtnFromPge = driver.findElement(
				By.cssSelector(".bottom .modal---button")).getText();
		assertTrue(NotesBtnFromPge.equalsIgnoreCase(ExpectedNotesBtn));
		driver.findElement(By.cssSelector(".bottom .modal---button")).click();

	}

	@When("^I Fail Frontline supporting documents$")
	public void I_fail_frontline_supporting_documents() throws Throwable {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		System.out.println("I Fail Frontline supporting documents");
		String dataSheetpath = TestData.TestDataPath;
		boolean Documet_present = false;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);

		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
		int noofRows = sheets.getLastRowNum();
		for (int i = 0; i <= noofRows; i++) {
			XSSFRow row = sheets.getRow(i);
			if ((row.getCell(0).getStringCellValue()
					.equalsIgnoreCase("Frontline"))
					&& (row.getCell(1).getStringCellValue()
							.equalsIgnoreCase("Mandatory"))) {
				System.out.println("INside if condition for doc image");
				String doc_required = row.getCell(2).getStringCellValue();
				System.out.println("document To check from excel"
						+ doc_required);
				Documet_present = false;
				List<WebElement> a = driver.findElements(By
						.className("doc-title"));
				Iterator<WebElement> ab = a.iterator();
				while (ab.hasNext()) {
					WebElement document = ab.next();
					String docvalue = document.getText();
					if (docvalue.trim().equalsIgnoreCase(doc_required)) {
						System.out.println(" Additional Documents are  "
								+ doc_required);
						Documet_present = true;
						Thread.sleep(1000);
						document.click();
						Thread.sleep(3000);
						// driver.manage().window().maximize();
						String document1 = (String) ((JavascriptExecutor) driver)
								.executeScript("document.getElementsByClassName('document-quality')[0].children[0].click()");
						System.out.println(document1);
						// assertTrue(document1.equalsIgnoreCase("document-submit"));
						// assertTrue(images.equalsIgnoreCase(document-submit));
						break;
					}
				}
				if (!Documet_present) {
					throw new RuntimeException(
							" Additional documents are not found "
									+ doc_required);
				}
			}

		}
	}

	@Then("^\"(.*?)\" button should not be enabled$")
	public void button_should_not_be_enabled(String Submit) throws Throwable {
		if (driver.findElement(By.className("document-submit")).isEnabled()) {
			System.out.println("Element is Enable");
		} else {
			System.out.println("Element is Disabled");
		}
	}

	@Then("^I should be able to \"(.*?)\" notes$")
	public void i_should_be_able_to_see_button(String Button) throws Throwable {
		Assert.assertFalse(driver.findElement(By.id("button-ok")).isEnabled());
		System.out.println("Add button is not enabled");
		driver.findElement(By.cssSelector(".content .ember-text-area")).sendKeys("To verify add button");
		Thread.sleep(4000);
		
		String WebButton = driver.findElement(By.cssSelector(".bottom .modal---button")).getText();
		assertTrue(Button.equalsIgnoreCase(WebButton));
		assertTrue(driver.findElement(By.id("button-ok")).isEnabled());
		System.out.println("Add button is enabled after entered the text");
		driver.findElement(By.cssSelector(".bottom .modal---button")).click();

	}

	@Then("^I should be able to see all the captured images of application$")
	public void i_should_be_able_to_see_all_captured_images_in_coding()
			throws Throwable {

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		String dataSheetpath = TestData.TestDataPath;
		boolean Documet_present = false;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);

		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
		int noofRows = sheets.getLastRowNum();
		for (int i = 0; i <= noofRows; i++) {
			XSSFRow row = sheets.getRow(i);
			if ((row.getCell(0).getStringCellValue()
					.equalsIgnoreCase("Frontline")))

			{
				String doc_required = row.getCell(2).getStringCellValue();
				System.out.println("documentTocheck from excel" + doc_required);
				Documet_present = false;
				List<WebElement> a = driver.findElements(By
						.cssSelector(".app-classification-row"));
				Iterator<WebElement> ab = a.iterator();
				while (ab.hasNext()) {
					WebElement El = ab.next();
					String docvalue = El.findElement(
							By.cssSelector(".doc-title")).getText();
					if (docvalue.trim().equalsIgnoreCase(doc_required)) {
						double no_of_images = row.getCell(4)
								.getNumericCellValue();
						int images1 = (int) no_of_images;
						String images = String.valueOf(images1);
						System.out.println("no of image from excel" + images);

						String ImagesinBrowser = El.findElement(
								By.cssSelector(".doc-count")).getText();
						ImagesinBrowser = ImagesinBrowser.substring(2, 3);
						System.out.println(" Images in the browser  are  "
								+ ImagesinBrowser);
						assertTrue(images.equalsIgnoreCase(ImagesinBrowser));
						Documet_present = true;
						break;
					}
				}
				if (!Documet_present) {
					throw new RuntimeException(
							"MandatoryDocuments are not found " + doc_required);
				}
			}

		}

		driver.findElement(By.xpath("//div[@id='primary-modals']/descendant::button/i[@class='icon-close']")).click();
	}

	@And("^I close the notes popup in coding station$")
	public void i_close_the_notes_popup_without_saving() throws Throwable {
		Thread.sleep(3000);

		driver.findElement(
				By.xpath("//div[@id='third-modals']/div/button[@id='modal-close']"))
				.click();

	}

	@After("@browser")
	public void afterBrowser(Scenario scenario) throws InterruptedException,
			IOException {

		String scenarioName = scenario.getName();

		if (scenario.isFailed()) {
			try {

				File scrFile = ((TakesScreenshot) driver)
						.getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File(TestData.ScreenshotPath
						+ scenarioName + ".png"));
				Thread.sleep(5000);
				addImageFilePath(TestData.ScreenshotPath + scenarioName
						+ ".png");

			} catch (WebDriverException somePlatformsDontSupportScreenshots) {
				System.err.println(somePlatformsDontSupportScreenshots
						.getMessage());

			}
		}

		// driver.quit();

	}

	
	
	
	/**MODULE: Coding  [RELEASE-2]
	 ** Verifying the Master Application Detail in coding
	 */
		@Then("^I should see the Master Application Detail in coding$")
		public void i_should_see_the_Master_Application_Detail_in_coding()
				throws Throwable {

			new CodingApplicationMasterView().checkApplicationDetailsInMasterView();
			
//			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
//			WebDriverWait wait = new WebDriverWait(driver, 25);
//			
//			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='modal-content']")));
//			String masterappview=driver.findElement(By.xpath("//div[@class='modal-content']")).getText();
//		    System.out.println("Master app view is displaying? :"+ masterappview);
//			assertTrue(driver.findElement(By.xpath("//div[@class='modal-content']")).getText()!=null);
//			
//			System.out.println("Master application view is displaying");
//			
//			//client name display check
//			String clientname=driver.findElement(By.xpath("//h2[@class='client-name']")).getText();
//			
//			assertTrue(driver.findElement(By.xpath("//h2[@class='client-name']")).getText()!=null);
//			System.out.println("Client name is displaying in master application view: " +clientname);
//			Thread.sleep(10000);
//			
//			//client id display check
//			String clientid=driver.findElement(By.xpath("//div[@class='name-block']")).getText();
//			assertTrue(driver.findElement(By.xpath("//div[@class='name-block']")).getText()!=null);
//			System.out.println("Client id is displaying in master application view:" +clientid);
//			Thread.sleep(10000);
//			
//		
//			//doc status app status
//			String app_status = driver.findElement(By.cssSelector(".application-status .top-status")).getText();
//			System.out.println(app_status);
//			assertTrue(app_status.equalsIgnoreCase("Coding"));
//			
//			String doc_status = driver.findElement(By.cssSelector(".document-status .top-status")).getText();
//			System.out.println(doc_status);
//			assertTrue(doc_status.equalsIgnoreCase("Complete"));
//			
//			//tap on info icon
//			WebDriverWait wait1 = new WebDriverWait(driver, 70);
//			Thread.sleep(3000);
//			WebElement element2 = wait1.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".app-info div")));
//			element2.click();
//			//logger.info("Info Icon is clicked");
//			
//			//info icon details
//			driver.findElement(By.cssSelector(".tooltipster-content"));
//			// driver.findElement(By.cssSelector(".tooltip-app-number"));
//			String actualappno = driver.findElement(By.xpath("//div[@class='tooltipster-content']/descendant::div[@class='tooltip-app-number']/span[2]")).getText(); // added by me
//			Thread.sleep(3000);
//			Assert.assertTrue(actualappno.equalsIgnoreCase(TestData.applicationId)); 
//			driver.findElement(By.cssSelector("body")).click();
//			
//			//Application and document tabs are displaying
//			assertTrue(driver.findElement(By.xpath("//a[contains(text(),'Applications')]")).getText().equalsIgnoreCase("Applications"));
//			assertTrue(driver.findElement(By.xpath("//a[contains(text(),'Documents')]")).getText().equalsIgnoreCase("Documents"));
//			System.out.println("Application and document tabs are displaying");
//			
//			//verifying the headers in application tab
//			
//			assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref.no')]")).getText().equalsIgnoreCase("Ref.no"));
//			assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Product')]")).getText().equalsIgnoreCase("Product"));
//			assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Sub product')]")).getText().equalsIgnoreCase("Sub product"));
//			assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref submitted Date')]")).getText().equalsIgnoreCase("Ref submitted Date"));
//			assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref Status')]")).getText().equalsIgnoreCase("Ref Status"));
			
		}	
		
		/**MODULE: Coding  [RELEASE-2]
		 **Author: Kasthuri (PSID-1542176)
		 ** Verifying the Master Application Detail for the application which is rejected at the coding end
		 */
			@Then("^I should see the Master Application Detail for rejected application in coding$")
			public void i_should_see_the_Master_Application_Detail_for_rejected_application_in_coding()
					throws Throwable {
				driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
				Thread.sleep(10000);
				String masterappview=driver.findElement(By.xpath("//div[@class='modal-content']")).getText();
			    System.out.println("Master app view is displaying? :"+ masterappview);
				assertTrue(driver.findElement(By.xpath("//div[@class='modal-content']")).getText()!=null);
				
				System.out.println("Master application view is displaying");
				
				//client name display check
				String clientname=driver.findElement(By.xpath("//h2[@class='client-name']")).getText();
				
				assertTrue(driver.findElement(By.xpath("//h2[@class='client-name']")).getText()!=null);
				System.out.println("Client name is displaying in master application view: " +clientname);
				Thread.sleep(10000);
				
				//client id display check
				String clientid=driver.findElement(By.xpath("//div[@class='name-block']")).getText();
				assertTrue(driver.findElement(By.xpath("//div[@class='name-block']")).getText()!=null);
				System.out.println("Client id is displaying in master application view:" +clientid);
				Thread.sleep(10000);
				
			
				//doc status app status
				String app_status = driver.findElement(By.cssSelector(".application-status .top-status")).getText();
				System.out.println(app_status);
				assertTrue(app_status.equalsIgnoreCase("Rejected"));
				
				String doc_status = driver.findElement(By.cssSelector(".document-status .top-status")).getText();
				System.out.println(doc_status);
				assertTrue(doc_status.equalsIgnoreCase("Rejected"));
				
				//tap on info icon
				WebDriverWait wait = new WebDriverWait(driver, 70);
				Thread.sleep(3000);
				WebElement element2 = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".app-info div")));
				element2.click();
				//logger.info("Info Icon is clicked");
				
				//info icon details
				driver.findElement(By.cssSelector(".tooltipster-content"));
				// driver.findElement(By.cssSelector(".tooltip-app-number"));
				String actualappno = driver.findElement(By.xpath("//div[@class='tooltipster-content']/descendant::div[@class='tooltip-app-number']/span[2]")).getText(); // added by me
				Assert.assertTrue(actualappno.equalsIgnoreCase(TestData.applicationId)); 
				driver.findElement(By.cssSelector("body")).click();
				
				//Application and document tabs are displaying
				assertTrue(driver.findElement(By.xpath("//a[contains(text(),'Applications')]")).getText().equalsIgnoreCase("Applications"));
				assertTrue(driver.findElement(By.xpath("//a[contains(text(),'Documents')]")).getText().equalsIgnoreCase("Documents"));
				System.out.println("Application and document tabs are displaying");
				
				//verifying the headers in application tab
				
				assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref.no')]")).getText().equalsIgnoreCase("Ref.no"));
				assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Product')]")).getText().equalsIgnoreCase("Product"));
				assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Sub product')]")).getText().equalsIgnoreCase("Sub product"));
				assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref submitted Date')]")).getText().equalsIgnoreCase("Ref submitted Date"));
				assertTrue(driver.findElement(By.xpath("//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref Status')]")).getText().equalsIgnoreCase("Ref Status"));
				
			
				
			}	

			/**MODULE: Coding  [RELEASE-2]
			 **Author: Kasthuri (PSID-1542176)
			 ** Verifying the Reply button is displaying after entered the notes in coding station
			 */
				@Then("^I tap on View Notes again and I should see the Reply button$")
				public void I_tap_on_Notes_again_and_I_should_see_the_Reply_button()
						throws Throwable {
					driver.findElement(By.cssSelector(".reply-btn")).click();
					Thread.sleep(5000);
					String replybtn = driver.findElement(By.xpath("//button[@id='button-ok']")).getText();
					System.out.println("Reply button present:" +replybtn);
					driver.findElement(By.xpath("//button[@id='button-ok']")).getText().equalsIgnoreCase("Reply");
                    driver.findElement(By.xpath("//div[@id='third-modals']/descendant::button[@id='modal-close']")).click();
					


				}

				
				/***
				 * CR3- document verification section button added in coding station
				 * 
				 */
				

				@When("^I click on \"(.*?)\" tab$")
				public void i_click_on_tab(String docVeri) throws Throwable {
				driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
					List<WebElement> Tabs1 = driver.findElements(By.cssSelector("button.view-document"));
					for ( WebElement Tab2 : Tabs1 ) {
						System.out.println(Tab2.getText());
						Thread.sleep(2000);
						if ((docVeri).equalsIgnoreCase(Tab2.getText()))
						{
							Thread.sleep(2000);
							Tab2.click();
							System.out.println("clicked on document verification button");
						}
					}

				
				}
				
				
				

				@Then("^I should see side by side view of application form and supporting document$")
				public void i_should_see_side_by_side_view_of_application_form_and_supporting_document() throws Throwable {
					Thread.sleep(5000);		
			   boolean sideBySideView= driver.findElement(By.xpath("//h2[contains(text(),'Supporting Document')]")).isDisplayed();
			   Assert.assertEquals(true, sideBySideView);
			   System.out.println("side by side view of application and supporting document");

				}

				@When("^I click on supporting document search tab and check for supporting document list$")
				public void i_click_on_supporting_document_search_tab_and_check_for_supporting_document_list() throws Throwable {
			 
					Thread.sleep(5000);
					driver.findElement(By.xpath("//input[@placeholder='Additional Proof One']")).click();
					System.out.println("clicked on search tab");
					List<WebElement> supDocList  = driver.findElements(By.cssSelector("li.ui-menu-item"));
					int doc = supDocList.size();
					System.out.println("total no. of documents is "+doc);
					Iterator<WebElement> itr1 = supDocList.iterator();
					
					//ul[@class='ui-autocomplete ui-front ui-menu ui-widget ui-widget-content']
					
					//span[@class='ember-view ui-combobox']
					
					while(itr1.hasNext()) 
					{
						Thread.sleep(5000);
						String availabledocs= itr1.next().findElement(By.tagName("a")).getText();
				        System.out.println("Available docs  -"+availabledocs);
				        
					
					}
				}

				
				
				@Then("^I should verify that documents added by the coding user are appearing in the support document search list$")
				public void i_should_verify_that_documents_added_by_the_coding_user_are_appearing_in_the_support_document_search_list() throws Throwable {
				     
					Thread.sleep(5000);
					String dataSheetpath = TestData.TestDataPath;
					boolean Documet_present = false;
					FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
					XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
					
					XSSFSheet sheets = workbooks.getSheet("Document Checklist");
					int noofRows= sheets.getLastRowNum();
					for(int i=0;i<=noofRows ;i++)
					{
						XSSFRow row = sheets.getRow(i);
						if ((row.getCell(0).getStringCellValue().equalsIgnoreCase("Additional supporting document")) && (row.getCell(1).getStringCellValue().equalsIgnoreCase("Mandatory")))
							
							{
							String doc_required=  row.getCell(2).getStringCellValue();
							System.out.println("documentTocheck from excel '" + doc_required );
							Documet_present = false;
							List<WebElement> addi = driver.findElements(By.cssSelector("li.ui-menu-item"));
			   		       Iterator<WebElement> ab= addi.iterator();
			   		       while(ab.hasNext()) 
					         {
						       String docvalue = ab.next().findElement(By.tagName("a")).getText();
						       System.out.println(docvalue);
					             if (docvalue.equalsIgnoreCase(doc_required))
						              {
						        	    System.out.println("document added by the coding user is  " + doc_required );
						        	    Documet_present=true;
						        	    break;
						    	       }
						      }
			     	          if (!Documet_present)
				   			         {
			     	        	   throw new RuntimeException(" documents is not found in search list - " +doc_required);
				   			         }
							}
						
				}
					
				    
				}
				

				 
				
				@When("^I click on X icon on the top$")
				public void i_click_on_X_icon_on_the_top() throws Throwable {
				    // Write code here that turns the phrase above into concrete actions
				//    throw new PendingException();
					
				Thread.sleep(5000);
				driver.findElement(By.xpath("//input[@placeholder='Additional Proof One']")).click();
				System.out.println("second time clicked on search tab");
				Thread.sleep(5000);
				driver.findElement(By.xpath("//div[@class='ember-view modal modal-document-verification scroll-closable modal-base modal_is-open modal_translucent modal_none modal_has-animation modal_scale-in modal_scale-out']/button[@id='modal-close']")).click();
				 System.out.println("clicked on close tab");
				}
	
 /** Module - Coding [Release -2] User can close the application without
	 * saving the coding fields by selecting the close button in the master view
	 * of the application
	 */
	@When("^I close the application without saving in coding station$")
	public void i_close_the_application_without_saving() throws Throwable {
		expwait = new WebDriverWait(driver, 5);
		WebElement closeButton = expwait
				.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
						.xpath("//div[@id='primary-modals']/div/button[@id='modal-close']"))));
		closeButton.click();
		WebElement dontSaveButton = expwait
				.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
						.xpath("//div[@class='saveNotes']/button[@class='modal---button-no']"))));
		dontSaveButton.click();
		Thread.sleep(10000);
		System.out.println("Returned to Search page");
	}

	/**
	 * Module - Coding [Release -2] User can close the application from coding
	 * station by saving the coding form fields in the master view of the
	 * application
	 */
	@Then("^I close the application from coding station by saving the coding fields$")
	public void i_close_the_application_from_coding_station_by_saving_the_coding_fields()
			throws Throwable {
		expwait = new WebDriverWait(driver, 5);
		WebElement closeButton = expwait
				.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
						.xpath("//div[@id='primary-modals']/div/button[@id='modal-close']"))));
		closeButton.click();
		driver.findElement(
				By.xpath("//textarea[@placeholder='Add a note here.']"))
				.sendKeys("Returning -" + " " + TestData.applicationId);
		WebElement saveButton = expwait
				.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
						.xpath("//div[@class='saveNotes']/button[@class='modal---button-yes']"))));
		saveButton.click();

	}

	/**
	 * Module - Coding Station [Release -2] 
	 * Checking with the pre-filled data in coding
	 * form in coding station
	 */
	@Then("^I should see all the prefilled data in the coding from coding station$")
	public void i_should_see_all_the_prefilled_data() throws Throwable {
	
		
		//TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Savings-and-Card-and-Loan.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("Coding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		int noofRows = (sheet.getLastRowNum());
		System.out.println(noofRows);
		for (int i = 1; i <= noofRows; i++) {
			row = sheet.getRow(i);
			String field=  row.getCell(0).getStringCellValue();
			String type=  row.getCell(1).getStringCellValue();
			String value=  row.getCell(2).getStringCellValue();
			String sectioncode= row.getCell(3).getStringCellValue();

		
			String componentId= getComponentId(sectioncode, type, field);
			
			if (value!=null && !(value.equalsIgnoreCase("")))
			{
			if (type.equalsIgnoreCase("select"))
			
				 verify_select_component_coding(componentId, value);
			 else if(type.equalsIgnoreCase("text"))
				 verify_text_component_coding(componentId, value); 
			}
			}
		
	}
	
	
	
	/**
	 * Module - Coding Station [Release -2] 
	 * Checking with the pre-filled data in coding under the condition -->the form is not saved<--
	 * form in coding station
	 */
	@Then("^I should not see all the prefilled data in the coding from coding station$")
	public void i_should_not_see_all_the_prefilled_data() throws Throwable {
	
		
		//TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Savings-and-Card-and-Loan.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("Coding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		int noofRows = (sheet.getLastRowNum());
		System.out.println(noofRows);
		for (int i = 1; i <= noofRows; i++) {
			row = sheet.getRow(i);
			String field=  row.getCell(0).getStringCellValue();
			String type=  row.getCell(1).getStringCellValue();
			String value=  row.getCell(2).getStringCellValue();
			String sectioncode= row.getCell(3).getStringCellValue();

		
			String componentId= getComponentId(sectioncode, type, field);
			System.out.println(componentId);
			if (type.equalsIgnoreCase("select"))
			
				 verify_select_component_coding_is_null(componentId, value);
			 else if(type.equalsIgnoreCase("text"))
				 verify_text_component_coding_is_null(componentId, value); 
			
			}
		
			

		
	}
	
	/**
	 * Module - Coding Station[Release -2] 
	 * Asserting the text fields in the coding form -Coding station
	 */
	private void verify_text_component_coding(String componentId, String value) throws InterruptedException 
	{
		

		String valueFrompage= (String) ((JavascriptExecutor) driver).executeScript("return document.getElementById('"+componentId+"').getElementsByTagName('input')[0].value");
		System.out.println("Value from xl for text:" +value);
		System.out.println("Value from the text:" +valueFrompage);
		//assertTrue(valueFrompage.equalsIgnoreCase(value));
		//Assert.assertTrue("Showing Null value", valueFrompage==null);
	}
	
	
	/**
	 * Module - Coding [Release -2] 
	 * Asserting the Select components fields with in the coding station
	 */
	private void verify_select_component_coding(String componentId, String value) throws InterruptedException 
	{
		
		//System.out.println("printing***********************************************************************************************************************************");
		System.out.println(componentId);
		String valueFrompage= (String) ((JavascriptExecutor) driver).executeScript("return document.getElementById('"+componentId+"').getElementsByTagName('input')[0].value");
		Thread.sleep(1000);
		//assertTrue(valueFrompage.equalsIgnoreCase(value));
		System.out.println("Value from xl for select:" +value);
		System.out.println("Value from the select:" +valueFrompage);
		//Assert.assertTrue("Showing Null value", valueFrompage==null);	

}
	
	/**
	 * Module - Coding Station[Release -2] 
	 * Asserting the text fields in the coding form -Coding station
	 */
	private void verify_text_component_coding_is_null(String componentId, String value) throws InterruptedException 
	{
		

		String valueFrompage= (String) ((JavascriptExecutor) driver).executeScript("return document.getElementById('"+componentId+"').getElementsByTagName('input')[0].value");
		System.out.println("Value from xl for text:" +value);
		System.out.println("Value from the text:" +valueFrompage + componentId);
		//assertTrue(valueFrompage.equalsIgnoreCase(value));
		if (valueFrompage.isEmpty())
		{
			System.out.println("Value from page is null");
		}
	}
	
	
	/**
	 * Module - Coding [Release -2] 
	 * Asserting the Select components fields with in the coding station
	 */
	private void verify_select_component_coding_is_null(String componentId, String value) throws InterruptedException 
	{
		
		//System.out.println("printing***********************************************************************************************************************************");
		String valueFrompage= (String) ((JavascriptExecutor) driver).executeScript("return document.getElementById('"+componentId+"').getElementsByTagName('input')[0].value");
		Thread.sleep(1000);
		//assertTrue(valueFrompage.equalsIgnoreCase(value));
		System.out.println("Value from xl for select:" +value);
		System.out.println("Value from the select:" +valueFrompage);
//		Assert.assertTrue("Showing Null value", valueFrompage==null);
		if (valueFrompage.isEmpty())
		{
			System.out.println("Value from page is null");
		}

}
//	/**
//	 * Module - Coding [Release -2] 
//	 * Quitting the browser in the coding station
//	 */
//	@Then("^I quit the browser$")
//	public void i_quit_the_browser() throws Throwable {
//	    driver.quit();
//	    
//	}
	
}
