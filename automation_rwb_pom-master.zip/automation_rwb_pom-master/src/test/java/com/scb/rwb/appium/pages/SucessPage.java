package com.scb.rwb.appium.pages;

public class SucessPage extends AppiumBasePage {

}
