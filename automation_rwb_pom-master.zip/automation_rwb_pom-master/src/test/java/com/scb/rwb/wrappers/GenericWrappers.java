package com.scb.rwb.wrappers;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.RollingFileAppender;
import org.jsoup.Connection.KeyVal;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Keyboard;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rwb.glue.TestData;
import com.scb.rwb.utility.ReadTestData;
import com.standardchartered.genie.FrameworkGlue;

import cucumber.api.Scenario;

public class GenericWrappers extends FrameworkGlue {
	Logger logger = Logger.getRootLogger();
	public static AppiumDriver wd;
	public static WebDriver driver;
	public static WebDriverWait wait;
	public static String screenShotPath;
	public static String timeStamp;
	public static String logBasePath = "/target/log/files/";
	public static String scenarioName;
	public static String path = "config.properties";

	/**
	 * This method will set the screenshot folder and start the logger.
	 * 
	 * @param scenario
	 */
	public void setLogpathForGenei(Scenario scenario) {
			scenarioName = scenario.getName();
			PropertyConfigurator.configure("Dependencies/log4j.properties");
			Date date = new Date();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
					"yyyy-MM-dd_HH_mm_ss");
			String finalDate = simpleDateFormat.format(date);
			timeStamp = finalDate;
			String currentDir = System.getProperty("user.dir");
			screenShotPath = currentDir
					+ "/target/log/screenshots/screenshots_" + finalDate + "/";

			System.out.println(screenShotPath);

			RollingFileAppender fileApp = new RollingFileAppender();
			fileApp.setName("RCWBAUTOMATION");
			String Rcwlogpath = currentDir + logBasePath + "files_"
					+ finalDate + "/RCW.log";
			System.out.println(Rcwlogpath);
			fileApp.setFile(Rcwlogpath);
			fileApp.activateOptions();
			PatternLayout p = new PatternLayout();
			p.setConversionPattern("%d{ISO8601} [%t] %-5p %c %x - %m%n");
			fileApp.setLayout(p);
			fileApp.setAppend(true);
			logger.addAppender(fileApp);
			logger.info("Path configuration completed");
	}

	/**
	 * This method will start the appium server
	 */
	public void startAppiumServer() {
		System.out.println("i am 2");
		DesiredCapabilities capabilities = new DesiredCapabilities();
//		capabilities.setCapability("java.net.useSystemProxies", true);
//		capabilities.setCapability("automationName", "XCUITest");
		capabilities.setCapability("appium-version", "1.0");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
		capabilities.setCapability("platformVersion", "9.2.1");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,
				"Rajesh iPad (9.2.1)");
		capabilities.setCapability("udid",
				"19d8ec467b8b83666940515b4a51311ff77f98a3");
//		capabilities.setCapability("app","/Users/Golf/Downloads/sakthy/RWB/Dependencies/CEMS-Dev.app");
//		capabilities.setCapability("app","/Users/Magpie/Downloads/RetailWB.app");

		capabilities.setCapability("autoAcceptAlerts", true);
		capabilities.setCapability("bundleId", "com.sc.mobile.rcworkbench");
//		capabilities.setCapability("newCommandTimeout", 60 * 15);
		try {
			wd = new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"),
					capabilities);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		wd.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
	}

	/**
	 * This method will capture the screen shot for the failed sceanrio and add
	 * the path to the genie report
	 * 
	 * @param scenario
	 * @author Vicky
	 * 
	 */
	public void captureScreenShotAndAddToGeneiReport(Scenario scenario) {

		String scenarioName = scenario.getName();

		if (scenario.isFailed()) {
			try {

				File scrFile = ((TakesScreenshot) wd)
						.getScreenshotAs(OutputType.FILE);
				String Filename = (screenShotPath + scenarioName + ".png")
						.replaceAll(" ", "_");
				System.out.println("Screen shot saved in location " + Filename);

				Filename = "../../screenshots/screenshots_"
						+ timeStamp + "/"
						+ scenarioName.replaceAll(" ", "_") + ".png";
				try {
					FileUtils.copyFile(scrFile, new File(Filename));
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out.println("Screeshot asserted in HTML " + Filename);
				sleep(2000);
				addImageFilePath(Filename);

			} catch (WebDriverException somePlatformsDontSupportScreenshots) {
				System.err.println(somePlatformsDontSupportScreenshots
						.getMessage());
			}

		}
	}

	/**
	 * This method will will close the appium and the browser
	 * 
	 * @author Vicky
	 */
	public void closeAppiumAndBrowser() {
		try {

			wd.closeApp();
			wd.quit();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method will sleep for particular given time
	 * 
	 * @param time
	 */
	public void sleep(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * This method will return the webelement based on the given string
	 * parameter
	 * 
	 * @param locators
	 * @return
	 */
	public WebElement getWebelElement(String locators) {
		WebElement ele = null;
		String[] loc = locators.split("`");
		switch (loc[0]) {
		case "ByName":
			ele = wd.findElement(By.name(loc[1]));
			break;
		case "FByName":
			ele = wd.findElementByName(loc[1]);
			break;
		case "FByClassName":
			ele = wd.findElementByClassName(loc[1]);
			break;
		case "FByXpath":
			ele = wd.findElementByXPath(loc[1]);
			break;

		default:
			break;
		}
		return ele;
	}

	/**
	 * This method will enter the given value using keyboard action
	 * 
	 * @param key
	 * @param value
	 */
	public void enterUsingKeyBoard(Keyboard key, String value) {
		key.pressKey(value);

	}

	/**
	 * This method will wait for the presence of the element to be located
	 * 
	 * @param locator
	 */
	public void waitForpresenceOfElementLocated(By locator) {
		wait = new WebDriverWait(wd, 100);
		wait.until(ExpectedConditions.presenceOfElementLocated(locator));

	}

	/**
	 * This method will wait for the invisibility of the Element located
	 * 
	 * @param locator
	 */
	public void waitForinvisiblityOfElementLocated(By locator) {
		wait = new WebDriverWait(wd, 100);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));

	}

	/**
	 * This method will wait for the visibility of the given cssSelector web
	 * Element
	 * 
	 * @param locator
	 */
	public void waitForvisiblityOfGivenCssselector(String locator) {
		wait = new WebDriverWait(wd, 100);
		wait.until(ExpectedConditions.visibilityOf(wd.findElement(By
				.cssSelector("." + locator))));

	}

	/**
	 * This method will wait for the visibility of the given WebElement
	 * 
	 * @param ele
	 */
	public void waitForvisiblityOfGivenElement(WebElement ele) {
		wait = new WebDriverWait(wd, 60);
		wait.until(ExpectedConditions.visibilityOf(ele));

	}

	/**
	 * This method will switch From Native to WebView
	 */
	public void switchFromNativeToWebView() {
		Set<String> AvailableContexts = wd.getContextHandles();
		for (String context : AvailableContexts) {
			System.out.println(context);
			if (context.contains("WEBVIEW"))
				wd.context(context);
		}
	}

	/**
	 * This method will do a java script executer click on the given product
	 * 
	 * @param productID
	 */
	/*public void jsClickOnAddProduct(String productID) {
		((JavascriptExecutor) wd)
				.executeScript("(document.getElementsByClassName('"
						+ productID
						+ "')[0].getElementsByClassName('bottom'))[0].getElementsByTagName('button')[0].click()");
	}*/

	/**
	 * This method will switch the control to the Native App
	 */
	public void switchToNativeApp() {
		wd.context("NATIVE_APP");
	}

	/**
	 * This method will return the webelemnt with locator ById
	 * 
	 * @param id
	 * @return
	 */
	public WebElement getWebElementById(String id) {
		return wd.findElement(By.id(id));
	}

	/**
	 * This method will return the webelemnt with locator ByXpath
	 * 
	 * @param id
	 * @return
	 */
	public WebElement getWebElementByXpath(String xpath) {
		return wd.findElement(By.xpath(xpath));
	}
	
	/*public void jsClickCartTogle(){
		((JavascriptExecutor) wd)
		.executeScript("document.getElementsByClassName('cart-toggle')[0].click()");
	}
	
	public void jsClickProductCheckout(){
		((JavascriptExecutor) wd)
		.executeScript("document.getElementById('product-checkout').click()");
	}
	
	public void jsClickTermsAndCondition(){
		((JavascriptExecutor) wd)
		.executeScript("document.getElementsByClassName('terms-and-conditions-menu---button-accept')[0].click()");
	}*/
	
	
	public void formFillSwitchElementToClick(WebElement ele,String data){
		if (!data.equalsIgnoreCase("")) {
			if (data.contains("Yes")) {
				sleep(500);
				ele.findElement(By.tagName("label")).click();
			}
		}
	}
	
	public void formFillSelectElementFromDropdown(WebElement ele,String data){
		if (!data.equalsIgnoreCase("")) {
//			sleep(500);
			ele.findElement(By.tagName("input")).clear();
		ele.findElement(By.tagName("input")).click();
//			sleep(5000);
			List<WebElement> eles = ele.findElements(By.tagName("a"));
			for (WebElement webElement : eles) {
//				System.out.println(webElement);
				System.out.println("The data : "+webElement.getText());
				if(webElement.getText().equals(data)){
					System.out.println("The data : "+webElement.getText());
					webElement.click();
					break;
				}
			}
//			ele.findElement(By.tagName("input")).sendKeys(data);
		}
		
	}
	
	public void formFillEnterText(WebElement ele, String data){
//		System.out.println("test: "+ data);
		if (!data.equalsIgnoreCase("")) {
			sleep(500);
			ele.findElement(By.tagName("input")).sendKeys(data);
		}
	}
	
	public void specificImplicitWaitInSeconds(long specify_in_seconds)
	{
		driver.manage().timeouts().implicitlyWait(specify_in_seconds, TimeUnit.SECONDS);
	}
	
	/**
	 * This method will wait for the given WebElement to be clickable
	 * 
	 * @param ele
	 */
	public void waitForElementToBeClickable(WebElement ele)
	{
		WebDriverWait wait = new WebDriverWait(driver, 25);
		wait.until(ExpectedConditions.elementToBeClickable(ele));
	}
	
	public void assertTextValueOfElementIsNotNull(WebElement ele)
	{
		Assert.assertTrue(ele.getText()!=null);
	}
	
	public void assertValueOfTheElementIsSame(WebElement ele,String value)
	{
		String actualValue=ele.getText();
		Assert.assertTrue(actualValue.equalsIgnoreCase(value));
	}
	
	public  void  assertElementIsDisplayed(WebElement ele)
	{
		boolean check;
		check=false;
		try {
			ele.isDisplayed();
			check= true;
		} catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			check=false; 
		}
		
		Assert.assertTrue(check);
		
		
	}
	
	public void maximizeTheBrowserWindow()
	{
		driver.manage().window().maximize();
	}
	
	public void browserWaitForVisibilityOfGivenElement(WebElement ele)
	{
		wait=new WebDriverWait(driver, 100);
		wait.until(ExpectedConditions.visibilityOf(ele));
	}
	
	public void assertElementIsEnabled(WebElement ele)
	{
		Assert.assertTrue(ele.isEnabled());
		
	} 
	
	
	/**
	 * Yogesh Agarwal(1557591)
	 * This Method Will Set The Data In The Property File For A Particular Variable
	 * 
	 * @param key, value
	 */
	public void setDataToPropertiesFile(String path, String key, String value){
		try{
		PropertiesConfiguration conf = new PropertiesConfiguration(path);
		conf.setProperty(key, value);
		conf.save();
		} catch (ConfigurationException e){
			System.out.println("Application Reference Number Not Stored...");
		}
	}
	
	/**
	 * Yogesh Agarwal(1557591)
	 * This Method Will Get The Data From The Property File For A Particular Variable
	 * 
	 * @param key, value
	 * @return 
	 */
	public String getDataFromPropertiesFile(String path, String key){
		String keyVal = null;
		try{
		PropertiesConfiguration conf = new PropertiesConfiguration(path);
		keyVal = (String) conf.getProperty(key);
		} catch (ConfigurationException e){
			System.out.println("Application Reference Number Not Stored...");
		}
		return keyVal;
	}
	
	/**
	 * This method will the launch the browser instance
	 * 
	 * @param BrowserName
	 * @author Vicky
	 */
	
	public void launchBrowser(String browsename)
	{
		if (browsename.equals("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver",
					"Dependencies//chromedriver");
			ChromeOptions options = new ChromeOptions();
			driver = new ChromeDriver(options);
			options.addArguments("--start-maximized");
		}
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		
		logger.info("Inside the Coding Station Home Screen");		
		
	}
	
	public void browsercaptureScreenShotAndAddToGeneiReport(Scenario scenario) {

		String scenarioName = scenario.getName();

		if (scenario.isFailed()) {
			try {

				File scrFile = ((TakesScreenshot) driver)
						.getScreenshotAs(OutputType.FILE);
				String Filename = (TestData.ScreenshotPath + scenarioName + ".png")
						.replaceAll(" ", "_");
				System.out.println("Screen shot saved in location " + Filename);

				Filename = "../../screenshots/screenshots_"
						+ TestData.TimeStamp + "/"
						+ scenarioName.replaceAll(" ", "_") + ".png";
				try {
					FileUtils.copyFile(scrFile, new File(Filename));
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out.println("Screeshot asserted in HTML " + Filename);
				sleep(2000);
				addImageFilePath(Filename);

			} catch (WebDriverException somePlatformsDontSupportScreenshots) {
				System.err.println(somePlatformsDontSupportScreenshots
						.getMessage());
			}

		}
	}
	
}
