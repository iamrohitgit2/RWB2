package com.scb.rwb.appium.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.utility.ReadTestData;


public class FFFatcaPage extends AppiumBasePage{


	
	/*@FindBy(id = "switch-component_fat-us-resident-flag_wrapper")
	WebElement swchUSResidentFlag;

	@FindBy(id = "switch-component_fat-us-citizen-flag_wrapper")
	WebElement sCitizenFlag;

	@FindBy(id = "switch-component_fat-pr-flag_wrapper")
	WebElement swchPRFlag;

	@FindBy(id = "switch-component_fat-confirmation_wrapper")
	WebElement swchConfirmation;*/
	
	FFClientKeyInformationPage ffCKI = new FFClientKeyInformationPage();
	
	@FindBy(xpath = "//div[contains(@id,'_fat-') and input[@type='text']]")
	List<WebElement> textFields;
	@FindBy(xpath = "//div[contains(@id,'_fat-') and input[@type='date']]")
	List<WebElement> dateFeilds;

	@FindBy(xpath = "//div[.//input[@class='ui-autocomplete-input']][contains(@id,'_fat-')]")
	List<WebElement> dropdownFeilds;

	@FindBy(xpath = "//div[input[@type='checkbox']][contains(@id,'_fat-')]")
	List<WebElement> switchFeilds;

	@FindBy(xpath = "//div[.//input[@type='radio']][contains(@id,'_fat-')]")
	List<WebElement> radioFeilds;

	@FindBy(css = "body")
	WebElement body;

	@FindBy(id = "next-button")
	WebElement btnNext;

	By tagNameInput = By.tagName("input");

	By tagNameLabel = By.tagName("label");
	
	Set<String> webele = new HashSet<String>();
	Set<String> csvkeys  = new HashSet<String>();
	HashMap<String, ArrayList<String>> addMap;
	
	public FFForInternalUsePage formFillForFatcaSection(int count) throws Exception {
		
		getNeedDataFromCSVMap(count);
		fillswitchFeilds();
		fillTextfields();
		filldatefields();
		filldropdownFeilds();
		
		verificationOfRequiedElemetsPresentInPage(webele, csvkeys);
		body.click();
		waitForvisiblityOfGivenElement(btnNext);
		btnNext.click();
		
		return new FFForInternalUsePage();

	}

	public  void fillTextfields() throws Exception {
		webele = formFillEnterText(textFields, addMap, webele);
		
	}

	public void filldatefields() throws Exception {
		webele = formFillEnterText(dateFeilds, addMap, webele);
		
	}

	public void fillswitchFeilds() throws Exception {
		webele = formFillSwitchElementToClick(switchFeilds, addMap, webele);
	}

	public void fillradioFeilds() {
		for (WebElement element : radioFeilds) {
			// if(Map.field contains element.getAttribute("id");
			// element.sendKeys( the value of the map);
		}
	}

	public void filldropdownFeilds() throws Exception {
		webele = formFillSelectElementFromDropdown(dropdownFeilds, addMap, webele);
	}
	
	
	public void getNeedDataFromCSVMap(int requiredCol){
		addMap = new HashMap<>();
		for (String data : ReadTestData.ffFatcaMap.keySet()) {
			if(!ReadTestData.ffFatcaMap.get(data).get(requiredCol).equals("N")){
				addMap.put(data, ReadTestData.ffFatcaMap.get(data));
			}
		}
		
		for (String dat : addMap.keySet()) {
			csvkeys.add(dat);
		}
	}
	
	/*public FFForInternalUsePage enterFatcaDetails(){
		formFillSwitchElementToClick(swchUSResidentFlag,
				ReadTestData.ffData.getUsResidentFlag());
		formFillSwitchElementToClick(sCitizenFlag,
				ReadTestData.ffData.getsCitizenFlag());
		formFillSwitchElementToClick(swchPRFlag,
				ReadTestData.ffData.getPrFlag());
		formFillSwitchElementToClick(swchConfirmation,
				ReadTestData.ffData.getConfirmation());
		
		
		ffCKI.body.click();
		ffCKI.btnNext.click();
		return new FFForInternalUsePage();
	}*/
	
}
