package com.scb.rwb.glue;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class userID {
	
	public void countrySelection(String country) throws InterruptedException, IOException
	{
		
		String dataSheetpath=TestData.TestDataPath;
			FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);	
			XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
		    XSSFSheet sheets = workbooks.getSheet("UserIDs");
			switch (country) 
			{
			
			case "HK" :
				System.out.println("Hongkong country");
				if(country.equalsIgnoreCase("HK"))
				{
				XSSFRow row= sheets.getRow(1);
				int userName =  (int) row.getCell(1).getNumericCellValue();
		       String passWord =row.getCell(2).getStringCellValue();
		       String countryType =row.getCell(3).getStringCellValue();
		       
				}
				break;
				
			case "SG" :
				System.out.println("Singapore country");
				if(country.equalsIgnoreCase("SG"))
				{
				XSSFRow row= sheets.getRow(2);
				int userName =  (int) row.getCell(1).getNumericCellValue();
		        String passWord =row.getCell(2).getStringCellValue();
		        String countryType =row.getCell(3).getStringCellValue();
			   }
				break;
			case "IN" :
				System.out.println("India country");
				if(country.equalsIgnoreCase("IN"))
				{
				XSSFRow row= sheets.getRow(2);
				int userName =  (int) row.getCell(1).getNumericCellValue();
		        String passWord =row.getCell(2).getStringCellValue();
		        String countryType =row.getCell(3).getStringCellValue();
			   }
				break;
				
			
		}
}
}
			
			//if(Timetype.equalsIgnoreCase("ShortTerm"))
//			{
//			     XSSFRow row= sheets.getRow(0);
//		         double field=  row.getCell(1).getNumericCellValue();
//		         Double d = new Double(field);
//					int timevalue = d.intValue();
//					
//					System.out.println(timevalue);
//					
//					Thread.sleep(timevalue);
//			}
//			else if(Timetype.equalsIgnoreCase("LongTerm"))
//			{
//				XSSFRow	row= sheets.getRow(1);
//				double field=  row.getCell(1).getNumericCellValue();
//				Double d = new Double(field);
//				int timevalue = d.intValue();
//				
//				System.out.println(timevalue);
//				
//				Thread.sleep(timevalue);
//			}
			
			
