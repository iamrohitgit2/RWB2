package com.scb.rwb.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.scb.rwb.testdata.FromFillTestData;
import com.scb.rwb.testdata.LoginTestData;

public class ReadTestData {

	public static String filePath = "./features/BD-features/TestData/csv/";
	public static FromFillTestData ffData;
	public static LoginTestData loginTD;
	public static Map<String, HashMap<String, ArrayList<String>>> allData;
	public static HashMap<String, ArrayList<String>> ffMap;
	public static HashMap<String, ArrayList<String>> ffCikMap;
	public static HashMap<String, ArrayList<String>> ffAMap;
	public static HashMap<String, ArrayList<String>> ffBSMap;
	public static HashMap<String, ArrayList<String>> ffCMap;
	public static HashMap<String, ArrayList<String>> ffCDDMap;
	public static HashMap<String, ArrayList<String>> ffEmpMap;
	public static HashMap<String, ArrayList<String>> ffFatcaMap;
	public static HashMap<String, ArrayList<String>> ffFiuMap;
	public static HashMap<String, ArrayList<String>> ffIncomeMap;
	public static HashMap<String, ArrayList<String>> ffPSMap;

	public static void readTestData() {

		allData = ReadCSVFile.getDataFromAllCsvFile(filePath);
		ffMap = allData.get("formfillTD_2.csv");
		ffData = new FromFillTestData(ffMap, 1);
		loginTD = new LoginTestData(allData.get("loginTD.csv"), 0);
		System.out.println("I am reading");
	}

	public static void getFormFillDataFromCsvFile(String filePath) {
		String line;
		HashMap<String, ArrayList<String>> testData = new HashMap<>();
		ffMap = new HashMap<>();
		ffCikMap = new HashMap<>();
		ffAMap = new HashMap<>();
		ffBSMap = new HashMap<>();
		ffCMap = new HashMap<>();
		ffCDDMap = new HashMap<>();
		ffEmpMap = new HashMap<>();
		ffFatcaMap = new HashMap<>();
		ffFiuMap = new HashMap<>();
		ffIncomeMap = new HashMap<>();
		ffPSMap = new HashMap<>();
		try {
			BufferedReader file = new BufferedReader(new FileReader(new File(
					filePath)));

			while ((line = file.readLine()) != null) {
				ArrayList<String> dataCik = new ArrayList<>();
				ArrayList<String> dataA = new ArrayList<>();
				ArrayList<String> dataBS = new ArrayList<>();
				ArrayList<String> dataC = new ArrayList<>();
				ArrayList<String> dataCDC = new ArrayList<>();
				ArrayList<String> dataEmp = new ArrayList<>();
				ArrayList<String> dataFatca = new ArrayList<>();
				ArrayList<String> dataFiu = new ArrayList<>();
				ArrayList<String> dataIncome = new ArrayList<>();
				ArrayList<String> dataPS = new ArrayList<>();
				String[] colData = line.split(",", -1);
				if (colData[0].contains("_cki-")) {
					addArrayDataToArryaList(colData, dataCik);
					ffCikMap.put(colData[0], dataCik);
				} else if (colData[0].contains("_a-")) {
					addArrayDataToArryaList(colData, dataA);
					ffAMap.put(colData[0], dataA);
				} else if (colData[0].contains("_bs-")) {
					addArrayDataToArryaList(colData, dataBS);
					ffBSMap.put(colData[0], dataBS);
				} else if (colData[0].contains("_c-")) {
					addArrayDataToArryaList(colData, dataC);
					ffCMap.put(colData[0], dataC);
				} else if (colData[0].contains("_cdd-")) {
					addArrayDataToArryaList(colData, dataCDC);
					ffCDDMap.put(colData[0], dataCDC);
				} else if (colData[0].contains("_e-")) {
					addArrayDataToArryaList(colData, dataEmp);
					ffEmpMap.put(colData[0], dataEmp);
				} else if (colData[0].contains("_fat-")) {
					addArrayDataToArryaList(colData, dataFatca);
					ffFatcaMap.put(colData[0], dataFatca);
				} else if (colData[0].contains("_fiu-")) {
					addArrayDataToArryaList(colData, dataFiu);
					ffFiuMap.put(colData[0], dataFiu);
				} else if (colData[0].contains("_i-")) {
					addArrayDataToArryaList(colData, dataIncome);
					ffIncomeMap.put(colData[0], dataIncome);
				} else if (colData[0].contains("_ps-")) {
					addArrayDataToArryaList(colData, dataPS);
					ffPSMap.put(colData[0], dataPS);
				}
			}
			/*System.out.println(ffCikMap);
			System.out.println(ffAMap);
			System.out.println(ffBSMap);
			System.out.println(ffCMap);
			System.out.println(ffCDDMap);
			System.out.println(ffEmpMap);
			System.out.println(ffFatcaMap);
			System.out.println(ffFiuMap);
			System.out.println(ffIncomeMap);
			System.out.println(ffPSMap);*/
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void addArrayDataToArryaList(String[] arrayData,
			ArrayList<String> arrayList) {
		for (int i = 1; i < arrayData.length; i++) {
//			System.out.println(arrayData[i]);
			arrayList.add(arrayData[i]);
		}
	}

}
