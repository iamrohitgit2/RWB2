package com.scb.rwb.appium.pages;

public class TermsAndConditionPage extends AppiumBasePage {


	/**
	 * This method will do a java executor click on terms and condition page
	 * 
	 * @return
	 */
	public TermsAndConditionPage clickTermsAndCondition() {
		sleep(10000);
		jsClickTermsAndCondition();
		return this;
	}

	/**
	 * This method will do JS click on Product check out and JS click on Terms
	 * and condition
	 * 
	 * @return
	 */
	public FFClientKeyInformationPage clickCheckOutProductAndAcceptTermsAndCondition() {
		sleep(10000);
		jsClickCartTogle();
		sleep(1000);
		jsClickProductCheckout();
		clickTermsAndCondition();
		return new FFClientKeyInformationPage();
	}
}
