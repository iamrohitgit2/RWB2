package com.scb.rwb.appium.pages;

import java.awt.print.PageFormat;

import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import com.scb.rwb.utility.ReadTestData;
import com.scb.rwb.wrappers.ApplicationWrappers;

public class AppiumBasePage extends ApplicationWrappers{
	
	public AppiumBasePage() {
	PageFactory.initElements(new AppiumFieldDecorator(wd), this);
	}
//	

}
