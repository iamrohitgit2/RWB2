package com.scb.rwb.appium.pages;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.python.antlr.PythonParser.break_stmt_return;

public class ApplicationQueuesPage extends AppiumBasePage {


	@FindBy(xpath = "//div[contains(text(),'INCOMPLETE')]")
	WebElement colIncomplete;

	@FindBy(xpath = "//div[contains(text(),'PENDING SUBMISSION')]")
	WebElement colPendingSubmission;

	@FindBy(xpath = "//div[contains(text(),'RETURNED')]")
	WebElement colReturned;

	@FindBy(xpath = "//div[contains(text(),'ERROR')]")
	WebElement colError;
	
	@FindBy(css=".app-queue-container")
	WebElement tblQueueContainer;
	
	@FindBy(css = ".active")
	WebElement lblActiveApplicationNumber;
	
	@FindBy(css = ".app-queue-table-row")
	WebElement tblApplicationQueue;
	
	@FindBy(id = "back-btn")
	WebElement btnBackToHome;

	public ApplicationQueuesPage verifyColumns() {
		sleep(5000);
		switchFromNativeToWebView();
		waitForvisiblityOfGivenElement(colIncomplete);
		assertTrue(colIncomplete.getText().equalsIgnoreCase("INCOMPLETE"));
		assertTrue(colPendingSubmission.getText().equalsIgnoreCase(
				"PENDING SUBMISSION"));
		assertTrue(colReturned.getText().equalsIgnoreCase("RETURNED"));
		assertTrue(colError.getText().equalsIgnoreCase("ERROR"));

		return new ApplicationQueuesPage();
	}
	
	/**
	 * This Method Will Check The Submitted Application In Queue
	 * 
	 * @return
	 */
	public ApplicationQueuesPage checkSubmittedApplicationInQueue(String queueName){
		switchFromNativeToWebView();
		tblQueueContainer.isDisplayed();
		String locator = "."+queueName.replace(" ", "-").toLowerCase()+"";
		waitForvisiblityOfGivenElement(wd.findElementByCssSelector(locator).findElement(By.cssSelector(".app-status-number")));
		wd.findElementByCssSelector(locator).findElement(By.cssSelector(".app-status-number")).click();
		boolean applicationPresent = false;
		assertTrue(lblActiveApplicationNumber.getText().equalsIgnoreCase(queueName));
		tblApplicationQueue.isDisplayed();
		List<WebElement> applicationList = wd.findElementsByCssSelector(".appNumber");
		sleep(2000);
		for(WebElement ele : applicationList){
		System.out.println(ele.getText());
			new ApplicationSubmitSucessfulPage();
			if(ApplicationSubmitSucessfulPage.appRefNo.equalsIgnoreCase(ele.getText())){
				applicationPresent = true;
				break;
			}
		}
		if(!applicationPresent){
			throw new RuntimeException(ApplicationSubmitSucessfulPage.appRefNo+" Not Found In Queue");
		}
		return new ApplicationQueuesPage();
	}
	
	/**
	 * This Method Will Navigate The User To HomeScreen(Dashboard)
	 * 
	 * @return
	 */
	public DashboardPage navigateToHomeScreen(){
		waitForvisiblityOfGivenElement(btnBackToHome);
		btnBackToHome.click();
		sleep(3000);
		return new DashboardPage();
	}

}
