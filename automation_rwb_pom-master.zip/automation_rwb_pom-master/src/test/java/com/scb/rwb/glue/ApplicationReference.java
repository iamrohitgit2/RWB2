package com.scb.rwb.glue;

import io.appium.java_client.AppiumDriver;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.scb.rwb.appium.pages.ApplicationSubmitSucessfulPage;
import com.scb.rwb.wrappers.ApplicationWrappers;

import cucumber.api.Scenario;
import cucumber.api.java.en.Then;



public class ApplicationReference extends ApplicationWrappers{
	
	Logger logger= Logger.getLogger("Application submitted for coding");
	
	
	@Then("^Application reference number should be displayed$")
	public void application_reference_number_should_be_displayed() throws Throwable {		
		new ApplicationSubmitSucessfulPage().verifyApplicationRefNumber();
	}

}
