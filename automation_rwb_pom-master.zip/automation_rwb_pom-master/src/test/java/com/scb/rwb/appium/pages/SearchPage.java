package com.scb.rwb.appium.pages;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By.ByCssSelector;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class SearchPage extends AppiumBasePage {

	
	@FindBy(css = ".modal-search---input-field")
	WebElement txtSearch;
	
	@FindBy(css = ".search-app-number a")
	WebElement srchAppNumber;

	/**
	 * This Method Will Search The Submitted Application Using Application ID.
	 * 
	 * @return
	 */
	public SearchPage searchSubmittedApplication(){
		new ApplicationSubmitSucessfulPage();
		sleep(3000);
		txtSearch.sendKeys(ApplicationSubmitSucessfulPage.appRefNo);
		return new SearchPage();
	}
	
	/**
	 * This Method Will Verify The Submitted Application Status
	 * 
	 * @return
	 */
	public SearchPage verifyApplicationStatus(String status){
		sleep(10000);
		boolean appPresent = false;
		String expextedStatus = ".status-icon-medium-"+status.replaceAll(" ", "-").toLowerCase();
		List<WebElement> elements = wd.findElementsByCssSelector(".search-result-table-row");
		
		  Iterator<WebElement> itr1 = elements.iterator();
		  itr1.next();
		  
			
		  while(itr1.hasNext()) 
		  {
			  WebElement appRow = itr1.next();
			  String appID = srchAppNumber.getText();
			  if(appID.equalsIgnoreCase(ApplicationSubmitSucessfulPage.appRefNo)){
				appPresent = true;
				appRow.findElement(By.cssSelector(expextedStatus));
				break;
			  }
		  }
		  
		  if(!appPresent){
			throw new RuntimeException(ApplicationSubmitSucessfulPage.appRefNo+" Is Not Present");  
		  }
		return new SearchPage();
	}
}
