package com.scb.rwb.appium.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;

public class DocumentChekListPage extends AppiumBasePage {


	@FindBy(css = ".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component .wb-upload")
	List<WebElement> imgCamera;

	@FindBy(name = "PhotoCapture")
	WebElement btnPhotoCapture;

	@FindBy(name = "Use Photo")
	WebElement btnUsePhoto;

	@FindBy(name = "done16px")
	WebElement btnDone;

	By imgCam = By.cssSelector(".ikon-camera");

	/**
	 * This Method Will Capture The All The Mandatory Document Using Camera.
	 * 
	 * @return
	 */
	public DocumentChekListPage captureMandatoryDocument() {
		boolean proof_present = false;
		for (WebElement ele : imgCamera) {
			if (ele.getText().equalsIgnoreCase("ID")
					|| ele.getText().equalsIgnoreCase("Employment Proof")
					|| ele.getText().equalsIgnoreCase("Income Proof")
					|| ele.getText().equalsIgnoreCase("Residence Proof")) {
				proof_present = true;
				ele.findElement(imgCam).click();
				switchToNativeApp();
				btnPhotoCapture.click();
				btnUsePhoto.click();
				btnDone.click();
				switchFromNativeToWebView();
			}
		}
		if (!proof_present)
			throw new RuntimeException(" Documents not found");

		return this;
	}

	/**
	 * This Method Will Click Next Button
	 * 
	 * @return
	 */
	public AOFPage clickNextButton() {
		sleep(2000);
		new FFClientKeyInformationPage().btnNext.click();
		return new AOFPage();
	}
}
