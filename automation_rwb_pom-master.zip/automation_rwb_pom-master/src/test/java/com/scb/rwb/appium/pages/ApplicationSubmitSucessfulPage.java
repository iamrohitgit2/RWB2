package com.scb.rwb.appium.pages;

import static org.junit.Assert.assertTrue;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;

public class ApplicationSubmitSucessfulPage extends AppiumBasePage {
	
	@FindBy(className= "component---info---title")
	WebElement lblTitle;
	
	@FindBy(className= "component---info---text")
	WebElement lblText;
	
	@FindBy(css= ".application-number")
	WebElement lblApplicationNo;
	
	@FindBy(id ="back-to-home")
	WebElement btnBackToHome;
	
	String path = "config.properties";
	public static String appRefNo;
	
	/**
	 * This Method Will Verify Whether The Application Is Submitted Successfully
	 * 
	 * @return
	 */
	public ApplicationSubmitSucessfulPage verifyStatusOfApplication(){
		sleep(30000);
		switchFromNativeToWebView();
		assertTrue(lblTitle.getText().equalsIgnoreCase("Application submitted successfully"));
		assertTrue(lblText.getText().contains("Once your application is reviewed, you'll receive a notification with your PDF application form."));
		return this;
	}
	
	/**
	 * This Method Will Store The Application Number To A Variable
	 * 
	 * @return
	 */
	public ApplicationSubmitSucessfulPage verifyApplicationRefNumber(){
		System.out.println(lblApplicationNo.getText());
		appRefNo = lblApplicationNo.getText().substring(16);
		setDataToPropertiesFile(path, "appRefrenceNumber", appRefNo);
		return this;
	}
	
	/**
	 * This Method Will Navigate The User To HomeScreen
	 * 
	 * @return
	 */
	public DashboardPage navigatetoHomePage(){
		btnBackToHome.click();
		return new DashboardPage();
	}
}
