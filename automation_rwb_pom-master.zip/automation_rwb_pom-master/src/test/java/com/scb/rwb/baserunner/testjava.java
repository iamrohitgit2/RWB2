package com.scb.rwb.baserunner;

import gherkin.deps.net.iharder.Base64.OutputStream;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.gargoylesoftware.htmlunit.javascript.host.file.File;
import com.scb.rwb.appium.pages.CopyOfFFClientKeyInformationPage;
import com.scb.rwb.utility.ReadTestData;

import org.apache.commons.configuration.PropertiesConfiguration;

public class testjava {
	
	public static void main(String[] args) throws Exception {  
		
	}
	

}
