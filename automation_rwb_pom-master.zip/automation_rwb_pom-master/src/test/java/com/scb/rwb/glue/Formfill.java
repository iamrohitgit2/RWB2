package com.scb.rwb.glue;

import io.appium.java_client.AppiumDriver;
import static org.junit.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.scb.rwb.wrappers.ApplicationWrappers;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Formfill extends ApplicationWrappers {
	
//	AppiumDriver wd = Driver.wd;
	


	private Map<String, String> fieldset;
	public Map<String, String> sectionCode;
	public Map<String, String> sectionId;
	public FileInputStream fileInputstream = null;
	public FileOutputStream fileOutputstream = null;
	private XSSFWorkbook workbook = null;
	private XSSFSheet sheet = null;
	private XSSFRow row = null;
	private XSSFCell cell = null;
	WebDriverWait wait = new WebDriverWait(wd, 30);
	
	@Given("^I have the following form data:$")
	public void i_have_the_following_form_data(Map<String, String> fieldset) throws Throwable {
		this.fieldset= fieldset;	
	}
	

	@Then("^Application Form should be displayed$")
	public void application_Form_should_be_displayed() throws Throwable {
    System.out.println("Application form should be implemented");
    Thread.sleep(20000);
	}
	
	@When("^I fill in form details$")
	public void i_fill_in_form_details() throws Throwable {
		System.out.println("Inside loop for form details");
		String dataSheetpath = TestData.TestDataPath;
		Thread.sleep(30000);
		System.out.println("passed 80 seconds ....");
//		Wait<WebDriver>fwait=new FluentWait<WebDriver>(wd)
//				.withTimeout(50, TimeUnit.SECONDS)
//				.pollingEvery(5, TimeUnit.SECONDS);
//		WebElement FF_element=fwait.until(new Function<WebDriver, WebElement>() {
//
//			
//			public WebElement apply(WebDriver driver) {
//				wd.findElement(By.name("PRODUCT OFFERING")).click();
//				return wd.findElement(By.name("PRODUCT OFFERING"));
//			}
//		});
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
		
		XSSFSheet sheets = workbooks.getSheet("section Details");
		int noofRows= (sheets.getLastRowNum()-1);
		
		for(int i=0;i<=noofRows ;i++)
		{
			row= sheets.getRow(i);
			String field=  row.getCell(0).getStringCellValue();
			System.out.println("fill "+field);
			i_fill_in_details(field);
			//Thread.sleep(3000);
			
		}
		
	}
	
	@Given("^I fill in \"([^\"]*)\" details$")
	public void i_fill_in_details(String section) throws Throwable {
	
		String dataSheetpath = TestData.TestDataPath;
	    fileInputstream = new FileInputStream(dataSheetpath);
		workbook = new XSSFWorkbook(fileInputstream);
		sectionId = new HashMap<String, String>();
		sectionCode = new HashMap<String, String>();
		sheet = workbook.getSheet("section Details");
		int noofRows= sheet.getLastRowNum();
		
		for(int i=0;i<=noofRows ;i++)
		{
			row= sheet.getRow(i);
			String field=  row.getCell(0).getStringCellValue();
			String value=  row.getCell(1).getStringCellValue();
			sectionId.put(field, value);
		}
		
		Thread.sleep(20000);
		wait.until(ExpectedConditions.visibilityOf(wd.findElement(By.cssSelector(".commitment-forms .sc-form div#"+sectionId.get(section)+" .sc-component"))));

		
		sheet = workbook.getSheet(section);
		noofRows= sheet.getLastRowNum();
		for(int i=0;i<=noofRows ;i++)
		{	
		row= sheet.getRow(i);
		String field=  row.getCell(0).getStringCellValue();
		String type=  row.getCell(1).getStringCellValue();
		String value=  row.getCell(2).getStringCellValue();
		String sectioncode= row.getCell(3).getStringCellValue();

		String componentId= getComponentId(sectioncode, type, field);
		
		System.out.println("componentId = "+componentId);

		if (value!=null && !(value.equalsIgnoreCase("")))
		{
		if (type.equalsIgnoreCase("select"))
			 fill_in_select_component(componentId, value);
		 else if(type.equalsIgnoreCase("text"))
			 fill_in_text_component(componentId, value);
		 else if(type.equalsIgnoreCase("radio-group"))
			 fill_in_radio_component(componentId, value);
		 else if(type.equalsIgnoreCase("switch"))
			 fill_in_switch_component(componentId, value); 
//		 else if(type.equalsIgnoreCase("textarea"))
//			 fill_in_textarea_component(componentId, value);
//	
		}
		}
		
		wd.findElementByCssSelector("body").click();
	
		Thread.sleep(1000);	
		
		//wd.findElement(By.xpath("//button[contains(@Text,'01 "+section.toUpperCase()+"')]")).click();
		List<WebElement> buttons = wd.findElementsByTagName("button");
		
		for (WebElement button : buttons)
		{	
			System.out.println(button.getText());
			if (button.getText().contains(section.toUpperCase()))
			{	
				button.click();
				break;
				}
			
		}
		Thread.sleep(1000);
		wd.findElementByCssSelector("#next-button").click();
		}
	
	@Then("^I should see all the prefilled data$")
	public void i_should_see_all_the_prefilled_data() throws Throwable {
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//TestData.TestDataPath= "features//"+TestData.countryCode+"-features//TestData//Savings-and-Card.xlsx";
		String dataSheetpath = TestData.TestDataPath;
		Set<String> AvailableContexts = wd.getContextHandles();
		for (String context : AvailableContexts)
		{
			if(context.contains("WEBVIEW"))
				wd.context(context);
		}
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
		
		XSSFSheet sheets = workbooks.getSheet("section Details");
		int noofRows= (sheets.getLastRowNum()-1);
		System.out.println(noofRows);
		for(int i=0;i<=noofRows ;i++)
		{
			row= sheets.getRow(i);
			String section=  row.getCell(0).getStringCellValue();
			System.out.println("Verify "+section);
			i_verify_details(section);
			
		}
	}
	

	@Given("^I verify \"([^\"]*)\" details$")
	public void i_verify_details(String section) throws Throwable {
	    
		//System.out.println(wd.getPageSource());
		
	
		String dataSheetpath = TestData.TestDataPath;
	    fileInputstream = new FileInputStream(dataSheetpath);
		workbook = new XSSFWorkbook(fileInputstream);
		sectionId = new HashMap<String, String>();
		sectionCode = new HashMap<String, String>();
		sheet = workbook.getSheet("section Details");
		int noofRows= sheet.getLastRowNum();
		
		for(int i=0;i<=noofRows ;i++)
		{
			row= sheet.getRow(i);
			String field=  row.getCell(0).getStringCellValue();
			String value=  row.getCell(1).getStringCellValue();
			sectionId.put(field, value);
		}
		
		
		
		sheet = workbook.getSheet(section);
		noofRows= sheet.getLastRowNum();
		for(int i=0;i<=noofRows ;i++)
		{	
		row= sheet.getRow(i);
		String field=  row.getCell(0).getStringCellValue();
		String type=  row.getCell(1).getStringCellValue();
		String value=  row.getCell(2).getStringCellValue();
		String sectioncode= row.getCell(3).getStringCellValue();

	
		String componentId= getComponentId(sectioncode, type, field);
		System.out.println(componentId);
		if (value!=null && !(value.equalsIgnoreCase("")))
		{
		if (type.equalsIgnoreCase("select"))
			 verify_select_component(componentId, value);
		 else if(type.equalsIgnoreCase("text"))
			 verify_text_component(componentId, value);
		}
		}
		
		wd.findElementByCssSelector("body").click();
	
		Thread.sleep(1000);
		
		//wd.findElement(By.xpath("//button[contains(@text,'"+section.toUpperCase()+"')]")).click();
		List<WebElement> buttons = wd.findElementsByTagName("button");
		
		for (WebElement button : buttons)
		{	
			System.out.println(button.getText());
			if (button.getText().contains(section.toUpperCase()))
			{	
				button.click();
				break;
				}
			
		}
		
		Thread.sleep(1000);
		wd.findElementByCssSelector("#next-button").click();
		}
	
	private void verify_text_component(String componentId, String value) {
		
		//System.out.println(wd.findElementById(componentId).getText());
		String valueFrompage= (String) ((JavascriptExecutor) wd).executeScript("return document.getElementById('"+componentId+"').getElementsByTagName('input')[0].value");
		//System.out.println("value from excel: "+value);
		//System.out.println("value from page: "+valueFrompage);
		assertTrue(valueFrompage.equalsIgnoreCase(value));
	}


	private void verify_select_component(String componentId, String value) {
		
		//System.out.println("printing***********************************************************************************************************************************");
		String valueFrompage= (String) ((JavascriptExecutor) wd).executeScript("return document.getElementById('"+componentId+"').getElementsByTagName('input')[0].value");
		assertTrue(valueFrompage.equalsIgnoreCase(value));
		
	}


	public void fill_in_radio_component(String componentId, String value) {
		
		String radio_option = value; 
		
		List <WebElement> elements= wd.findElementById(componentId).findElements(By.tagName("label"));

		for (WebElement element: elements){
			System.out.println(element.getText());
			if (radio_option.equalsIgnoreCase(element.getText())){
				element.click();
				}
				
			}
	}

	public void fill_in_switch_component(String componentId, String value) {
		String Option= value;
		if (Option.equalsIgnoreCase("Yes"))
		{
			WebElement a = wd.findElementById(componentId).findElement(By.tagName("label"));
			a.click();
		}
		
	}

	public void fill_in_text_component(String componentId, String value) {
		
		if ((componentId.contains("date")) || (componentId.contains("employment-pass-expiry-date")) || (componentId.contains("date-of-birth-ddmmyyyy-1")) || (componentId.contains("Visa-Expiry-Date-1")) || (componentId.contains("joining-date")) || (componentId.contains("emirates-expiry")) || (componentId.contains("visa-expiry")) || (componentId.contains("dob")) || (componentId.contains("resident-since"))|| (componentId.contains("driving-license-expiry")))
		{	WebElement a = wd.findElementById(componentId).findElement(By.tagName("input"));
			a.sendKeys(value);
			//System.out.println(("document.getElementById('"+componentId+"').getElementsByTagName('input')[0].value='"+value+"'"));	
			((JavascriptExecutor) wd).executeScript("document.getElementById('"+componentId+"').getElementsByTagName('input')[0].value='"+value+"'");
		}
		else
		{
		WebElement a = wd.findElementById(componentId).findElement(By.tagName("input"));
		a.clear();
		a.sendKeys(value);
		}
	}
	
	/***
	 * 
	 * @param componentId
	 * @param value
	 * @throws InterruptedException
	 */
//    private void fill_in_textarea_component(String componentId, String value) {
//		
//		if ((componentId.contains("account-name")) || (componentId.contains("dob")) || (componentId.contains("resident-since"))|| (componentId.contains("driving-license-expiry")))
//		{	WebElement a = wd.findElementById(componentId).findElement(By.tagName("input"));
//			a.sendKeys(value);
//			//System.out.println(("document.getElementById('"+componentId+"').getElementsByTagName('input')[0].value='"+value+"'"));	
//			((JavascriptExecutor) wd).executeScript("document.getElementById('"+componentId+"').getElementsByTagName('textarea')[0].value='"+value+"'");
//		}
//		else
//		{
//		WebElement a = wd.findElementById(componentId).findElement(By.tagName("textarea"));
//		a.clear();
//		a.sendKeys(value);
//		}
//	}
//	
	
	public void fill_in_select_component(String componentId, String value) throws InterruptedException {
		
		WebElement a = wd.findElementById(componentId).findElement(By.tagName("input"));
		a.clear();
		a.sendKeys(value);
		Thread.sleep(1000);
		
	}

	
	public String getComponentId(String sectioncode, String componentType, String componentname){
		String componentId= componentType+"-component_"+sectioncode+"-"+componentname+"_wrapper";
		componentId = StringUtils.replace(componentId, " ", "-").toLowerCase();
		return (componentId);
	}
	
	@When("^I goto offline mode$")
	public void i_goto_offline_mode() throws Throwable {
	
	   wd.runAppInBackground(30);
	   Thread.sleep(5000);

	
		((JavascriptExecutor)wd).executeScript("mobile: tap", new HashMap<String, Double>() {{ put("tapCount", (double) 1); put("touchCount", (double) 1); put("duration", 0.5); put("x", (double) 129); put("y", (double) 386); }});
		((JavascriptExecutor)wd).executeScript("mobile: tap", new HashMap<String, Double>() {{ put("tapCount", (double) 1); put("touchCount", (double) 1); put("duration", 0.5); put("x", (double) 143); put("y", (double) 171); }});
		
		String sw = wd.findElementByClassName("UIASwitch").getAttribute("value");
		if (sw.equalsIgnoreCase("1") )
		{
		((JavascriptExecutor)wd).executeScript("mobile: tap", new HashMap<String, Double>() {{ put("tapCount", (double) 1); put("touchCount", (double) 1); put("duration", 0.5); put("x", (double) 954); put("y", (double) 125); }});
		}
		wd.launchApp();
	
	}
	private String capitalizeFirstLetter_of_String(String s) {
			String[] words = s.split("\\s");
			String finalString="";
			for (String word: words) {           
				String capitalizedWord=capitalizeFirstLetter_of_Word(word);    
			    finalString=(finalString+" "+capitalizedWord);
		}
		    return finalString.trim();
	}
		
		
	private String capitalizeFirstLetter_of_Word(String word){	
			return word.substring(0, 1).toUpperCase() + word.substring(1);
	}

	private String get_element_name(String id) {
			String elementName = StringUtils.substringBetween(id, "component_", "_wrapper");
			String[] form_name = StringUtils.split(elementName, "-");
			elementName= StringUtils.substringAfter(elementName ,form_name[0]+"-");
			elementName= StringUtils.replace(elementName, "-", " ");
			
			return elementName;	
	}

	private String get_element_type(String id) {
			String elementType = StringUtils.substringBefore(id, "-component");
			return elementType;		
	}
		
	
	
	@When("^I capture documents$")
	public void i_capture_documents() throws Throwable {
		
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		wd.findElementByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component");
		
		List<WebElement> elementsList = wd.findElementsByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component");
	
		for (WebElement doc : elementsList)
		{
			String id = doc.getAttribute("id");
			System.out.println(id);
			
		}
		Thread.sleep(3000);
		List <WebElement> camera = wd.findElementsByCssSelector(".commitment-forms .sc-form div#step_step-document-checklist_wrapper .sc-component .wb-upload");
		System.out.println(camera.size());
		for (WebElement cam : camera)
		{
			
			cam.findElement(By.cssSelector(".ikon-camera")).click();
			wd.context("NATIVE_APP");
			//Thread.sleep(3000);
			wd.findElement(By.name("PhotoCapture")).click();
			wd.findElement(By.name("Use Photo")).click();
			wd.findElement(By.name("done16px")).click();
			
			//Thread.sleep(3000);
			Set<String> AvailableContexts = wd.getContextHandles();
			for (String context : AvailableContexts)
			{
				if(context.contains("WEBVIEW"))
					wd.context(context);
			}
		}
		
		
		List<WebElement> buttons = wd.findElementsByTagName("button");
		
		for (WebElement button : buttons)
		{
			
			System.out.println(button.getText());
			if (button.getText().contains("DOCUMENT"))
			{	
				button.click();
				break;
			}
			
		}

		
	}
	
	@When("^I submit application$")
	public void i_submit_application() throws Throwable {
		
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		wd.findElementByCssSelector("#next-button").click();
	
	}
	
	@When("^I save the form$")
	public void i_save_the_form() throws Throwable {
		
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		TestData.applicationId= (String) ((JavascriptExecutor) wd).executeScript("return window.Workbench.__container__.cache['controller:product-offering/commitment/checkout'].appNumber");	
		System.out.println("INcomplete application Id "+ TestData.applicationId );
		((JavascriptExecutor) wd).executeScript("document.getElementsByClassName('commitment---button-close')[0].click()");	
		Thread.sleep(4000);
		//System.out.println(wd.getPageSource());
		((JavascriptExecutor) wd).executeScript("document.getElementsByClassName('modal---button-yes')[0].click()");
	
	}

	@When("^I submit the form$")
	public void i_submit_the_form() throws Throwable {
		System.out.println("Going to click Submit Button");
		Thread.sleep(10000);
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		wd.context("NATIVE_APP");	
		wd.findElementByName("Submit").click();
		Thread.sleep(20000);
		
	}

	
	 /** Module - Coding [Release -2] 
			 * Scenario-1.Return and re-take 
			 * 
			 * User can re-take the application by clicking the retake button from the iPAD
			 * from Application diary
			 * 
			 * Author -Vignesh Ramamurthy 
			 */
			@Then("^I change the field values$")
			public void i_change_the_field_values() throws Throwable 
			{
			TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Savings-and-Card-and-Loan.xlsx";				
				
			i_fill_in_details("Client Key Information");
			
				
			}

	
	public Boolean is_element_visible(WebElement input) {
		
		if(input.isDisplayed())
			return true;
		else
			return false;	
	}

}
