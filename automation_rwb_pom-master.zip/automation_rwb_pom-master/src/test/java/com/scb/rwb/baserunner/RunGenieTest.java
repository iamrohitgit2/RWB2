package com.scb.rwb.baserunner;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecuteResultHandler;
import org.apache.commons.exec.DefaultExecutor;
import org.junit.*;
import org.junit.runner.RunWith;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.standardchartered.genie.junit.GenieJUnit;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(GenieJUnit.class)
// The "ignored.feature" is not used during the test run, it is just there to
// enable Genie to accept the specified Cucumber.Options features below...
// Important: The preExec option enables macro support.
// Important: The postExec option generates the HTML logs.
// @GenieJUnit.Options(commandLine = {"ignored.feature", "--preExec" ,
// "toolbox tool macros" , "--postExec","toolbox tool lrg"})
// Important: Add the correct glue package else it won't find test steps.
@CucumberOptions(features = { "features/BD-features/1-Product_Offering.feature" },
// FIXME: edit the line below to point to your glue code!
glue = { "com.scb.rwb.glue" }, tags = { }, monochrome = true)
public class RunGenieTest {
	public static ExtentReports extent;
	public static ExtentTest test;
	public static String Testcase_Name;
	public static String Testcase_Description;

	// @BeforeClass

	public static void startResult() {
		System.out.println("I am before calss");
		extent = new ExtentReports("EReports/result.html", false);
		extent.loadConfig(new File("extent-config.xml"));
		extent.addSystemInfo("Host Name", "Vicky")
				.addSystemInfo("Environment", "Macintosh")
				.addSystemInfo("User name", "Vignesh Ramamurthy");

	}

	// public static void startServer() {
	//
	// CommandLine command = new CommandLine(
	// "/Applications/Appium.app/Contents/Resources/node/bin/node");
	// command.addArgument(
	// "/Applications/Appium.app/Contents/Resources/node_modules/appium/bin/appium.js",
	// false);
	// command.addArgument("--session-override");
	// command.addArgument("--address", false);
	// command.addArgument("127.0.0.1");
	// command.addArgument("--port", false);
	// command.addArgument("4000");
	// command.addArgument("--backend-retries", false);
	// command.addArgument("0");
	// command.addArgument("--log-level", false);
	// command.addArgument("warn:error");
	//
	// DefaultExecuteResultHandler resultHandler = new
	// DefaultExecuteResultHandler();
	// DefaultExecutor executor = new DefaultExecutor();
	// executor.setExitValue(1);
	// try {
	// executor.execute(command, resultHandler);
	// Thread.sleep(10000);
	// System.out.println("Appium server started.");
	// } catch (IOException e) {
	// e.printStackTrace();
	// } catch (InterruptedException e) {
	// e.printStackTrace();
	// }
	// }

	// @AfterClass
	public static void stopServer() {
		System.out
				.println("Executing After classssss----------------------------------");
		String[] command = { "/usr/bin/killall", "-KILL", "node" };
		try {
			Runtime.getRuntime().exec(command);
			System.out.println("Appium server stopped.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
