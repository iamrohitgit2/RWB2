package com.scb.rwb.browser.pages;

import static org.junit.Assert.assertTrue;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rwb.glue.TestData;

public class CodingApplicationMasterView extends BrowserBasePage
{
	@FindBy(xpath="//div[@class='modal-content']")
	WebElement xpathOFMasterAppViewModal;
	
	@FindBy(xpath="//h2[@class='client-name']")
	WebElement xpathOfClientName;
	
	@FindBy(xpath="//div[@class='name-block']")
	WebElement xpathOfClientId;
	
	@FindBy(css=".application-status .top-status")
	WebElement cssOfApplicationStatus;
	
	@FindBy(css=".document-status .top-status")
	WebElement cssOfDcoumentStatus;
	
	@FindBy(css=".app-info div")
	WebElement cssOfAppInfo;
	
	@FindBy(css=".tooltipster-content")
	WebElement cssOfAppInfocontainer;
	
	@FindBy(xpath="//div[@class='tooltipster-content']/descendant::div[@class='tooltip-app-number']/span[2]")
	WebElement xpathOfApplicationNumber;
	
	@FindBy(css="body")
	WebElement cssOfBody;
	
	@FindBy(xpath="//a[contains(text(),'Applications')]")
	WebElement xpathOfApplication;
	
	@FindBy(xpath="//a[contains(text(),'Documents')]")
	WebElement xpathOfDocument;
	
	@FindBy(xpath="//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref.no')]")
	WebElement xpathOfRefNo;
	
	@FindBy(xpath="//div[@class='app-queue-table-row app-product']/div[contains(text(),'Product')]")
	WebElement xpathOfProduct;
	
	@FindBy(xpath="//div[@class='app-queue-table-row app-product']/div[contains(text(),'Sub product')]")
	WebElement xpathOfSubProduct;
	

	@FindBy(xpath="//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref submitted Date')]")
	WebElement xpathOfSubmittedDate;
	
	@FindBy(xpath="//div[@class='app-queue-table-row app-product']/div[contains(text(),'Ref Status')]")
	WebElement xpathOfRefStatus;
	
	@FindBy(css="li.ember-view")
	List<WebElement> cssOfTabs;
	
	@FindBy(className="doc-title")
	List<WebElement> frontlineDocumentTitle;
	
	@FindBy(css=".document-submit")
	WebElement cssOfSubmitButton;
	
	@FindBy(css=".tabs .active")
	static WebElement cssOfStatusTab;
	
	
	
	
	public CodingApplicationMasterView checkApplicationDetailsInMasterView()
	{
		specificImplicitWaitInSeconds(60);
		waitForElementToBeClickable(xpathOFMasterAppViewModal);
		
		assertTrue(xpathOFMasterAppViewModal.getText()!=null);
		String masterappview=xpathOFMasterAppViewModal.getText();
		System.out.println("Master app view is displaying :"+ masterappview);
		sleep(2000);
		
		String clientname=xpathOfClientName.getText();
		assertTextValueOfElementIsNotNull(xpathOfClientName);
		System.out.println("Client name is displaying in master application view: "+clientname);
		sleep(2000);
		
		assertTextValueOfElementIsNotNull(xpathOfClientId);
		String clientid=xpathOfClientId.getText();
		System.out.println("Client id is displaying in master application view:" +clientid);
		sleep(2000);
		
		String app_status=cssOfApplicationStatus.getText();
		assertValueOfTheElementIsSame(cssOfApplicationStatus, "Coding");
		System.out.println(app_status);
		sleep(2000);
		
		String doc_status = cssOfDcoumentStatus.getText();
		assertValueOfTheElementIsSame(cssOfDcoumentStatus, "Complete");
		System.out.println(doc_status);
		sleep(2000);
		
		waitForElementToBeClickable(cssOfAppInfo);
		cssOfAppInfo.click();
		sleep(500);
		
		assertElementIsDisplayed(cssOfAppInfo);
		sleep(500);
		
		assertValueOfTheElementIsSame(xpathOfApplicationNumber,TestData.applicationId);
		cssOfBody.click();
		
		assertValueOfTheElementIsSame(xpathOfApplication, "Applications");
		assertValueOfTheElementIsSame(xpathOfDocument, "Documents");
		System.out.println("Application and document tabs are displaying");
		
		assertValueOfTheElementIsSame(xpathOfRefNo, "Ref.no");
		assertValueOfTheElementIsSame(xpathOfProduct, "Product");
		assertValueOfTheElementIsSame(xpathOfSubProduct, "Sub product");
		assertValueOfTheElementIsSame(xpathOfSubmittedDate, "Ref submitted Date");
		assertValueOfTheElementIsSame(xpathOfRefStatus, "Ref Status");
		return this;
	}
	
	
	public CodingApplicationMasterView switchToRespectiveTab(String tabName)
	{
		specificImplicitWaitInSeconds(20);
		sleep(3000);
		for (WebElement Tab : cssOfTabs) {
			System.out.println(Tab.getText());
			sleep(500);
			if ((tabName).equalsIgnoreCase(Tab.getText())) {
				sleep(500);
				Tab.click();
			}
		}
		return this;
	
	}
	
	public CodingApplicationMasterView passingTheFrontlineDocumentsAvailableForQualityCheck()throws Throwable
	{
		specificImplicitWaitInSeconds(10);
		System.out.println("I Pass Frontline supporting documents");
		String dataSheetpath = TestData.TestDataPath;
		boolean Documet_present = false;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);

		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
		int noofRows = sheets.getLastRowNum();
		for (int i = 0; i <= noofRows; i++) {
			XSSFRow row = sheets.getRow(i);
			if ((row.getCell(0).getStringCellValue()
					.equalsIgnoreCase("Frontline"))
					&& (row.getCell(1).getStringCellValue()
							.equalsIgnoreCase("Mandatory"))) {
				System.out.println("INside if condition for doc image");
				String doc_required = row.getCell(2).getStringCellValue();
				System.out.println("document To check from excel"
						+ doc_required);
				Documet_present = false;
				

				Iterator<WebElement> ab = frontlineDocumentTitle.iterator();
				while (ab.hasNext()) {
					WebElement document = ab.next();
					String docvalue = document.getText();
					if (docvalue.trim().equalsIgnoreCase(doc_required)) {
						System.out.println(" Additional Documents are  "
								+ doc_required);
						Documet_present = true;
						Thread.sleep(1500);
						document.click();
						Thread.sleep(3000);
						maximizeTheBrowserWindow();
						passingTheFrontlineDocumentsAvailableForQualityCheck();	
						break;
					}
				}
				if (!Documet_present) {
					throw new RuntimeException(
							" Additional documents are not found "
									+ doc_required);
				}
			}

		}
		return this;
		
	}
	
	public CodingApplicationMasterView feedCodingValuesInTheApplication() throws Throwable
	{
		specificImplicitWaitInSeconds(5);
		sleep(5000);
		String dataSheetpath = TestData.TestDataPath;
		FileInputStream fileInputstream = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbook = new XSSFWorkbook(fileInputstream);
		HashMap<String, String> sectionId = new HashMap<String, String>();
		HashMap<String, String> sectionCode = new HashMap<String, String>();
		XSSFSheet sheet = workbook.getSheet("Coding");
		int noofRows = sheet.getLastRowNum();

		XSSFRow row;

		for (int i = 0; i <= noofRows; i++) {
			row = sheet.getRow(i);
			String field = row.getCell(0).getStringCellValue();
			String type = row.getCell(1).getStringCellValue();
			String value = row.getCell(2).getStringCellValue().trim();
			String sectioncode = row.getCell(3).getStringCellValue();
			String componentId = getComponentId(sectioncode, type, field);

			System.out.println("componentId = " + componentId);
			componentId = StringUtils.replace(componentId, " ", "-")
					.toLowerCase();
		

			if (value != null && !(value.equalsIgnoreCase(""))) {
				if (type.equalsIgnoreCase("select"))
					
					fill_in_select_component(componentId, value);
				else if (type.equalsIgnoreCase("text"))
					fill_in_text_component(componentId, value);
				else if (type.equalsIgnoreCase("radio-group"))
					fill_in_radio_component(componentId, value);
				else if (type.equalsIgnoreCase("switch"))
					fill_in_switch_component(componentId, value);
				else if (type.equalsIgnoreCase("textarea"))
					fill_in_textarea_component(componentId, value);
			}
		}
		return this;
		
	}

	public CodingApplicationMasterView submitTheApplicationfromCoding()
	{
		assertElementIsDisplayed(cssOfSubmitButton);
		cssOfSubmitButton.click();
		return this;
		
	}
	
	public CodingApplicationMasterView verifyWhethertheApplicationIsSubmittedSuccessfully()throws Throwable
	{
		sleep(1000);
		specificImplicitWaitInSeconds(10);
		assertTextValueOfElementIsNotNull(CodingApplicationQueuesPage.appQueueContainer);
		assertTextValueOfElementIsNotNull(cssOfStatusTab);
		sleep(1000);
		
		String dataSheetpath = TestData.TestDataPath;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
		XSSFSheet sheets = workbooks.getSheet("AppSubmittedFromCoding");
		XSSFRow row = sheets.createRow(0);
		XSSFCell cell = row.createCell(0);
		cell.setCellValue(TestData.applicationId);
		FileOutputStream fileOut = new FileOutputStream(dataSheetpath);
		workbooks.write(fileOut);
		fileOut.close();
		
		if (TestData.configureApplicationSubmittedFromCodingPath)
		{
		RollingFileAppender fileApp = new RollingFileAppender();
		fileApp.setName("Applications for Coding");
		String currentDir = System.getProperty("user.dir");
		String ApplicationSubmittedFromCodingPath=currentDir+TestData.logbasePath+"files_"+TestData.TimeStamp+"/ApplicationSubmittedFromCoding.log";
		
		System.out.println(ApplicationSubmittedFromCodingPath);
		fileApp.setFile(ApplicationSubmittedFromCodingPath);
		fileApp.activateOptions();	
		PatternLayout p = new PatternLayout();
		p.setConversionPattern("%d{ISO8601} [%t] %-5p %c %x - %m%n");
		fileApp.setLayout(p);
		fileApp.setAppend(true);
		
		TestData.configureApplicationSubmittedFromCodingPath =false;
		
		}
		return this;
	}

}


