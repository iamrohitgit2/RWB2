package com.scb.rwb.appium.pages;


public class OZFormPage extends AppiumBasePage{


}
