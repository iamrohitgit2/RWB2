package com.scb.rwb.browser.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.glue.Login;

public class CodingApplicationQueuesPage extends BrowserBasePage
{
	
	@FindBy(css=".app-queue-container")
	static WebElement appQueueContainer;
	
	@FindBy(css="#app-queue")
	WebElement appQue;
	
	
	
	

	
	public CodingApplicationQueuesPage lauchCodingStation()
	{
		
		String URL="https://sit.staff.global.standardchartered.com/origination/#/?COUNTRYCODE="
				+ Login.countryCode
				+ "&INSTANCECODE=CB_"
				+ Login.countryCode
				+ "&PWID=" + Login.CodingUsername + "&SSO=fake_coding";	
		driver.get(URL);
		appQueueContainer.isDisplayed();
		appQue.isDisplayed();
		return this;
	}
	
	
	
	

}
