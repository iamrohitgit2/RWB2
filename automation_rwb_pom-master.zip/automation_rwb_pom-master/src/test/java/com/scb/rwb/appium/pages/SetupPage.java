package com.scb.rwb.appium.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Keyboard;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.glue.Login;
import com.scb.rwb.glue.TestData;
import com.scb.rwb.utility.ReadTestData;
import com.scb.rwb.wrappers.ApplicationWrappers;
import com.scb.rwb.wrappers.GenericWrappers;

public class SetupPage extends AppiumBasePage {




	
	@FindBy(name="Passcode Button")
	WebElement btnPasscode;
//	String btnPasscode = "Passcode Button";
	
	@FindBy(name="Passcode Button")
	List<WebElement> collPasscode;
	
	@FindBy(className= "UIAButton")
	WebElement txtPasscodeBox;
//	String txtPasscodeBox = "UIAButton";
	
	@FindBy(name = "NEXT")
	WebElement btnNext;
//	String btnNext = "NEXT";
	
	@FindBy(className="UIATextField")
	WebElement txtUserName;
//	String txtUserName = "UIATextField";
	
	@FindBy(className="UIASecureTextField")
	WebElement txtPassword;
//	String txtPassword = "UIASecureTextField";
	
	@FindBy(className="UIATextField")
	List<WebElement> droDwnCountry;
//	String droDwnCountry = "UIATextField";
	
	@FindBy(className="UIAPickerWheel")
	WebElement valCountry;
//	String valCountry = "UIAPickerWheel";
	
	@FindBy(className="UIAWindow")
	static WebElement winSetupWindow;
//	String winSetupWindow = "UIAWindow";
	
//	@FindBy(xpath="//XCUIElementTypeOther[2]/XCUIElementTypeButton[2]")
	@FindBy(xpath="//UIAApplication[1]/UIAWindow[1]/UIAButton[4]")
	WebElement btnNext2;
//	String btnNext2 = "//XCUIElementTypeOther[2]/XCUIElementTypeButton[2]";
	
//	@FindBy(xpath="//XCUIElementTypeOther[3]/XCUIElementTypeTextField")
	@FindBy(xpath="//UIAApplication[1]/UIAWindow[1]/UIATextField[3]")
	WebElement txtPassCodeName;
//	String txtPassCodeName = "//XCUIElementTypeOther[3]/XCUIElementTypeTextField";

	
	/**
	 * This method will do registration setup for the RM
	 * 
	 * @return
	 */
	public DashboardPage enterRMRegistration() {
//		waitForvisiblityOfGivenElement(btnNext);
		if (!collPasscode.isEmpty()) {
//			clickUsingFindByClassName(txtPasscodeBox);
			txtPasscodeBox.clear();
			enterUsingKeyBoard(wd.getKeyboard(), "12121");
			sleep(7000);
		} else 
//			clickUsingFindByName(btnNext);
			
		{
			btnNext.click();
			txtUserName.sendKeys(ReadTestData.loginTD.getUsername1());
			txtPassword.sendKeys(ReadTestData.loginTD.getPassword());
			droDwnCountry.get(1).click();
			sleep(2000);
			valCountry.sendKeys(ReadTestData.loginTD.getCountryName());
			sleep(2000);
			winSetupWindow.click();
			sleep(2000);
			btnNext2.click();
			sleep(15000);
			txtPassCodeName.sendKeys("SAMPLE");
			btnPasscode.click();
			enterUsingKeyBoard(wd.getKeyboard(), "12121");
			btnPasscode.click();
			enterUsingKeyBoard(wd.getKeyboard(), "12121");
			sleep(150000);
			
			/*enterUsingFindByClassName(txtUserName, Login.Username1);
			enterUsingFindByClassName(txtPassword, Login.password);
			getListOfWebelElementUsingFindByClassName(droDwnCountry).get(1)
					.click();
			sleep(2000);
			enterUsingFindByClassName(valCountry, Login.Countryname);
			sleep(2000);
			clickUsingFindByClassName(winSetupWindow);
			sleep(2000);
			clickUsingByXpath(btnNext2);
			enterUsingByXpath(txtPassCodeName, "SAMPLE");
			clickUsingByName(btnPasscode);
			enterUsingKeyBoard(wd.getKeyboard(), "12121");
			clickUsingByName(btnPasscode);
			enterUsingKeyBoard(wd.getKeyboard(), "12121");*/
		}

		return new DashboardPage();
	}
}
