package com.scb.rwb.appium.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.utility.ReadTestData;

public class FFEmploymentPage extends AppiumBasePage {


	/*@FindBy(xpath = "//div[@id='select-component_e-employment-type_wrapper']/div/div/div/span/ul/li/a")
	List<WebElement> lstEmploymentType;
	
	@FindBy(xpath = "//div[@id='select-component_e-employment-type_wrapper']/div/div/span[3]")
	WebElement clickArrow;
	
	@FindBy(id = "select-component_e-employment-type_wrapper")
	WebElement slctEmploymentType;

	@FindBy(id = "select-component_e-employment-status_wrapper")
	WebElement slctEmploymentStatus;

	@FindBy(id = "text-component_e-company_wrapper")
	WebElement txtCompany;

	@FindBy(id = "text-component_e-business-type_wrapper")
	WebElement txtBusinessType;

	@FindBy(id = "text-component_e-business-setup-date_wrapper")
	WebElement txtBusinessSetupDate;

	@FindBy(id = "select-component_e-business-ownership_wrapper")
	WebElement slctBusinessOwnership;

	@FindBy(id = "select-component_e-office-premise-status_wrapper")
	WebElement slctOfficePremiseStatus;

	@FindBy(id = "text-component_e-prev-business-name_wrapper")
	WebElement txtPrevBusinessName;

	@FindBy(id = "text-component_e-total-length-curr-biz-years_wrapper")
	WebElement txtTotalLengthCurrBizYears;

	@FindBy(id = "select-component_e-total-length-curr-biz-months_wrapper")
	WebElement slctTotalLengthCurrBizMonths;

	@FindBy(id = "text-component_e-total-biz-exp-years_wrapper")
	WebElement txtTotalBizExpYears;

	@FindBy(id = "select-component_e-total-biz-exp-months_wrapper")
	WebElement slctTotalBizExpMonths;

	@FindBy(id = "select-component_e-profession_wrapper")
	WebElement slctProfession;

	@FindBy(id = "text-component_e-designation_wrapper")
	WebElement txtDesignation;

	@FindBy(id = "select-component_e-employer-code_wrapper")
	WebElement slctEmployerCode;

	@FindBy(id = "text-component_e-employee-staff-id_wrapper")
	WebElement txtEmployeeStaffId;

	@FindBy(id = "text-component_e-total-curr-emp-years_wrapper")
	WebElement txtTotalCurrEmpYears;

	@FindBy(id = "select-component_e-total-curr-emp-months_wrapper")
	WebElement slctTotalCurrEmpMonths;

	@FindBy(id = "text-component_e-total-length-of-employment-years_wrapper")
	WebElement txtTotalLengthOfEmploymentYears;

	@FindBy(id = "select-component_e-total-length-of-employment-months_wrapper")
	WebElement slctTotalLengthOfEmploymentMonths;

	@FindBy(id = "text-component_e-name-of-prev-employer_wrapper")
	WebElement txtNameOfPrevEmployer;

	@FindBy(id = "text-component_e-total-prev-emp-years_wrapper")
	WebElement txtTotalPrevEmpYears;

	@FindBy(id = "select-component_e-total-prev-emp-months_wrapper")
	WebElement slctTotalPrevEmpMonths;*/

	FFClientKeyInformationPage ffCKI = new FFClientKeyInformationPage();
	
	
	@FindBy(xpath = "//div[contains(@id,'_e-') and input[@type='text']]")
	List<WebElement> textFields;
	@FindBy(xpath = "//div[contains(@id,'_e-') and input[@type='date']]")
	List<WebElement> dateFeilds;

	@FindBy(xpath = "//div[.//input[@class='ui-autocomplete-input']][contains(@id,'_e-')]")
	List<WebElement> dropdownFeilds;

	@FindBy(xpath = "//div[input[@type='checkbox']][contains(@id,'_e-')]")
	List<WebElement> switchFeilds;

	@FindBy(xpath = "//div[.//input[@type='radio']][contains(@id,'_e-')]")
	List<WebElement> radioFeilds;

	@FindBy(css = "body")
	WebElement body;

	@FindBy(id = "next-button")
	WebElement btnNext;

	By tagNameInput = By.tagName("input");

	By tagNameLabel = By.tagName("label");
	
	Set<String> webele = new HashSet<String>();
	Set<String> csvkeys  = new HashSet<String>();
	HashMap<String, ArrayList<String>> addMap;
	
	public FFBankingServicesPage formFillForEmploymentSection(int count) throws Exception {
		
		getNeedDataFromCSVMap(count);
		filldropdownFeilds();
		fillTextfields();
		filldatefields();
		fillswitchFeilds();
		verificationOfRequiedElemetsPresentInPage(webele, csvkeys);
		body.click();
		waitForvisiblityOfGivenElement(btnNext);
		btnNext.click();
		
		return new FFBankingServicesPage();

	}

	public  void fillTextfields() throws Exception {
		webele = formFillEnterText(textFields, addMap, webele);
		
	}

	public void filldatefields() throws Exception {
		webele = formFillEnterText(dateFeilds, addMap, webele);
		
	}

	public void fillswitchFeilds() throws Exception {
		webele = formFillSwitchElementToClick(switchFeilds, addMap, webele);
	}

	public void fillradioFeilds() {
		for (WebElement element : radioFeilds) {
			// if(Map.field contains element.getAttribute("id");
			// element.sendKeys( the value of the map);
		}
	}

	public void filldropdownFeilds() throws Exception {
		webele = formFillSelectElementFromDropdown(dropdownFeilds, addMap, webele);
	}

	
	
	public void getNeedDataFromCSVMap(int requiredCol){
		addMap = new HashMap<>();
		for (String data : ReadTestData.ffEmpMap.keySet()) {
			if(!ReadTestData.ffEmpMap.get(data).get(requiredCol).equals("N")){
				addMap.put(data, ReadTestData.ffEmpMap.get(data));
			}
		}
		
		for (String dat : addMap.keySet()) {
			csvkeys.add(dat);
		}
	}
	
	/**
	 * This Method Will Fill Form For Employment Details Section
	 * 
	 */
	/*public FFBankingServicesPage enterEmploymentDetails() {
		
//		clickArrow.click();
		slctEmploymentType.findElement(By.tagName("input")).click();
		System.out.println("Arrow Clicked *******");
		System.out.println(lstEmploymentType.size());
		System.out.println("Sleeping");
		sleep(3000);
		Iterator<WebElement> itr = lstEmploymentType.iterator();
		while(itr.hasNext()){
			WebElement ele = itr.next();
			System.out.println("The Elements Are:: "+ele.getText());
			ele.click();
			break;
		}
//		;= lstEmploymentType.iterator();
		
		formFillSelectElementFromDropdown(
				slctEmploymentType,
				ReadTestData.ffData.getEmploymentType());
		formFillSelectElementFromDropdown(
				slctEmploymentStatus,
				ReadTestData.ffData.getEmploymentStatus());
		formFillEnterText(txtCompany,
				ReadTestData.ffData.getCompany());
		formFillEnterText(txtBusinessType,
				ReadTestData.ffData.getBusinessType());
		formFillEnterText(txtBusinessSetupDate,
				ReadTestData.ffData.getBusinessSetupDate());
		formFillEnterText(txtPrevBusinessName,
				ReadTestData.ffData.getPrevBusinessName());
		formFillEnterText(txtTotalBizExpYears,
				ReadTestData.ffData.getTotalBizExpYears());
		formFillSelectElementFromDropdown(
				slctTotalBizExpMonths,
				ReadTestData.ffData.getTotalBizExpMonths());
		formFillSelectElementFromDropdown(slctProfession,
				ReadTestData.ffData.getProfession());
		formFillEnterText(txtDesignation,
				ReadTestData.ffData.getDesignation());
		// employerCode.sendKeys(ReadTestData.ffData.getEmployerCode());
		formFillEnterText(txtEmployeeStaffId,
				ReadTestData.ffData.getEmployeeStaffId());
		formFillEnterText(txtTotalCurrEmpYears,
				ReadTestData.ffData.getTotalCurrEmpYears());
		formFillSelectElementFromDropdown(
				slctTotalCurrEmpMonths,
				ReadTestData.ffData.getTotalCurrEmpMonths());
		formFillEnterText(txtTotalLengthOfEmploymentYears,
				ReadTestData.ffData.getTotalLengthOfEmploymentYears());
		formFillSelectElementFromDropdown(
				slctTotalLengthOfEmploymentMonths,
				ReadTestData.ffData.getTotalLengthOfEmploymentMonths());
		formFillEnterText(txtNameOfPrevEmployer,
				ReadTestData.ffData.getNameOfPrevEmployer());
		formFillEnterText(txtTotalPrevEmpYears,
				ReadTestData.ffData.getTotalPrevEmpYears());
		formFillSelectElementFromDropdown(
				slctTotalPrevEmpMonths,
				ReadTestData.ffData.getTotalPrevEmpMonths());

		ffCKI.body.click();
		ffCKI.btnNext.click();

		return new FFBankingServicesPage();
	}*/

}
