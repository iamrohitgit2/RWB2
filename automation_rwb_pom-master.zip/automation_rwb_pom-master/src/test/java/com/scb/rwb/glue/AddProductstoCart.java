package com.scb.rwb.glue;

import io.appium.java_client.AppiumDriver;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rwb.appium.pages.ProductOfferingPage;
import com.scb.rwb.utility.ExcelRead;
import com.scb.rwb.utility.ReadTestData;
import com.scb.rwb.wrappers.ApplicationWrappers;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class AddProductstoCart extends ApplicationWrappers {

	// AppiumDriver wd = Driver.wd;
	public static Logger logger = Logger.getLogger("AddProductstoCart");

	@Given("^I have a card product and a savings product and loan product in the cart$")
	public void i_have_a_card_product_and_a_savings_product_and_loan_product_in_the_cart()
			throws Throwable {
		TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
				+ "-features//TestData//Savings-and-Card-and-Loan.xlsx";
		i_add_products_to_the_cart();
	}

	@Given("^I have a card product and a savings product in the cart$")
	public void i_have_a_card_product_and_a_savings_product_in_the_cart()
			throws Throwable {
		TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
				+ "-features//TestData//Savings-and-Card.xlsx";
		i_add_products_to_the_cart();
	}

	@Given("^I have a card product and a current product in the cart$")
	public void i_have_a_card_product_and_a_current_product_in_the_cart()
			throws Throwable {
		TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
				+ "-features//TestData//Current-and-Card.xlsx";
		i_add_products_to_the_cart();
	}

	// Added CA, SA, CC & PL Products

	@Given("^I have a card product and a current product and loan product in the cart$")
	public void i_have_a_card_product_and_a_current_product_and_loan_product_in_the_cart()
			throws Throwable {
		new ProductOfferingPage().addCurrentProdCardProdLoanProdToCart();
		
		TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
				+ "-features//TestData//Current-and-Card-and-Loan.xlsx";
		
//		i_add_products_to_the_cart();
	}

	@Given("^I have a card product and loan product in the cart$")
	public void i_have_a_card_product_and_loan_product_in_the_cart()
			throws Throwable {
		TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
				+ "-features//TestData//Card-and-Loan.xlsx";
		i_add_products_to_the_cart();
	}

	@Given("^I have a card product in the cart$")
	public void i_have_a_card_product_in_the_cart() throws Throwable {
		TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
				+ "-features//TestData//Card.xlsx";
		i_add_products_to_the_cart();
	}

	@Given("^I have a savings product in the cart$")
	public void i_have_a_savings_product_in_the_cart() throws Throwable {
		TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
				+ "-features//TestData//Savings.xlsx";
		i_add_products_to_the_cart();
	}

	@Given("^I have a current product in the cart$")
	public void i_have_a_current_product_in_the_cart() throws Throwable {
		TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
				+ "-features//TestData//Current.xlsx";
		i_add_products_to_the_cart();
	}

	@Given("^I have a loan product in the cart$")
	public void i_have_a_loan_product_in_the_cart() throws Throwable {
		TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
				+ "-features//TestData//Loan.xlsx";
		i_add_products_to_the_cart();
	}

	@When("^I add products to the cart$")
	public void i_add_products_to_the_cart() throws Throwable {

		String dataSheetpath = TestData.TestDataPath;
		FileInputStream fileInputstream = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbook = new XSSFWorkbook(fileInputstream);
		HashMap<String, String> sectionId = new HashMap<String, String>();

		XSSFSheet sheet = workbook.getSheet("Subprdt selector");
		int noofRows = sheet.getLastRowNum();

		for (int i = 0; i <= noofRows; i++) {
			XSSFRow row = sheet.getRow(i);
			String field = row.getCell(0).getStringCellValue();
			logger.info("Product to add from excel " + field);
			i_add_product_to_the_cart(field);
		}

	}

	@Given("^I add \"([^\"]*)\" product to the cart$")
	public void i_add_product_to_the_cart(String product) throws Throwable {
		new ProductOfferingPage().addTheGivenProductToTheCart(product);

		// wd.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		// WebDriverWait wait = new WebDriverWait(wd, 50);
		// wait.until(ExpectedConditions.visibilityOf(wd.findElement(By.cssSelector("."+productID))));

		// ((JavascriptExecutor)
		// wd).executeScript("(document.getElementsByClassName('"+productID+"')[0].getElementsByClassName('bottom'))[0].getElementsByTagName('button')[0].click()");

	}

	@When("^I add \"(.*?)\" \"(.*?)\" product to the cart$")
	public void i_add_product_to_the_cart(String productName, String product)
			throws Throwable {
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		Set<String> AvailableContexts = wd.getContextHandles();
		for (String context : AvailableContexts) {
			// System.out.println("contect is "+context);
			if (context.contains("WEBVIEW"))
				wd.context(context);
		}

		// System.out.println(wd.getContext());

		String productID = getId(productName);

		((JavascriptExecutor) wd)
				.executeScript("(document.getElementsByClassName('"
						+ productID
						+ "')[0].getElementsByClassName('bottom'))[0].getElementsByTagName('button')[0].click()");

		if (product.contains("Card"))
			TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
					+ "-features//TestData//Card.xlsx";

		if (product.contains("Savings"))
			TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
					+ "-features//TestData//Savingss.xlsx";

		if (product.contains("Current"))
			TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
					+ "-features//TestData//Current.xlsx";

		if (product.contains("Loan"))
			TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
					+ "-features//TestData//Loan.xlsx";

	}

	@Given("^I checkout the product$")
	public void i_checkout_the_product() throws Throwable {

		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		((JavascriptExecutor) wd)
				.executeScript("document.getElementsByClassName('cart-toggle')[0].click()");
		Thread.sleep(1000);
		((JavascriptExecutor) wd)
				.executeScript("document.getElementById('product-checkout').click()");
	}

	/**
	 * MODULE: Ipad [RELEASE-2] Adding 3 products for HK market to the cart
	 * (CA+SA+CC)
	 */
	@Given("^I have a card product and a savings product and current product in the cart$")
	public void i_have_a_card_product_and_a_savings_product_and_current_product_in_the_cart()
			throws Throwable {
		TestData.TestDataPath = "features//" + ReadTestData.loginTD.getCountryCode()
				+ "-features//TestData//Current-and-Card-and-Savings.xlsx";
		i_add_products_to_the_cart();

	}
	
	

}
