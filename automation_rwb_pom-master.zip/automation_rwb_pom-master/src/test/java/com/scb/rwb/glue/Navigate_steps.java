package com.scb.rwb.glue;

import io.appium.java_client.AppiumDriver;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Keyboard;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.scb.rwb.appium.pages.DashboardPage;
import com.scb.rwb.appium.pages.ProductOfferingPage;
import com.scb.rwb.utility.ReadTestData;
import com.scb.rwb.wrappers.ApplicationWrappers;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Navigate_steps  {
	
	AppiumDriver wd = ApplicationWrappers.wd;
	
	
	@Given("^I am on the Home screen$")
	public void i_am_on_the_home_screen() throws Throwable {
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		if(!wd.findElementsByName("Passcode Button").isEmpty()) 
		{	
			wd.findElementByClassName("UIAButton").click();
			Keyboard a = wd.getKeyboard();
			a.pressKey("12121");
		}		
		
		else
		{
					
			wd.findElementByName("NEXT").click();	 
			wd.findElementByClassName("UIATextField").sendKeys(ReadTestData.loginTD.getUsername1());
			
			wd.findElementByClassName("UIASecureTextField").sendKeys(ReadTestData.loginTD.getPassword());

			WebElement q = (WebElement) wd.findElementsByClassName("UIATextField").get(1);
			q.click();
			Thread.sleep(2000);
			wd.findElementByClassName("UIAPickerWheel").sendKeys(ReadTestData.loginTD.getCountryName()); //added for country selection 
			wd.findElementByClassName("UIAWindow").click();
			Thread.sleep(3000);
			wd.findElementByXPath("//XCUIElementTypeOther[2]/XCUIElementTypeButton[2]").click();
			Thread.sleep(10000);
			wd.findElement(By.xpath("//XCUIElementTypeOther[3]/XCUIElementTypeTextField")).sendKeys("Automation");
			Thread.sleep(1000);
			wd.findElement(By.name("Passcode Button")).click();//added for tap on passcode button 
			//wd.findElement(By.xpath("//UIATextField[contains(@value,'Enter your Name')]")).sendKeys("Automation");
			//wd.findElementByClassName("UIAButton").click();
			Keyboard a = wd.getKeyboard();
			a.pressKey("12121");
			wd.findElement(By.name("Passcode Button")).click();
			//wd.findElementByClassName("UIAButton").click();
			a.pressKey("12121");
			Thread.sleep(30000);
			
		}
	}
	@Given("^I am on the Home screen for RMTwo$")
	public void i_am_on_the_home_screen_for_RMTwo() throws Throwable {
	    
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		if(!wd.findElementsByName("Passcode Button").isEmpty()) 
		{	
			wd.findElementByClassName("UIAButton").click();
			Keyboard a = wd.getKeyboard();
			a.pressKey("12121");
		}		
		
		
		
		else
		{
					
			wd.findElementByName("NEXT").click();
			wd.findElementByClassName("UIATextField").sendKeys(ReadTestData.loginTD.getUsername2());
			
			wd.findElementByClassName("UIASecureTextField").sendKeys(ReadTestData.loginTD.getPassword());

			//wd.findElementsByClassName("UIATextField").clear();
			
			WebElement q = (WebElement) wd.findElementsByClassName("UIATextField").get(1);
			q.click();
			Thread.sleep(2000);
			wd.findElementByClassName("UIAPickerWheel").sendKeys(ReadTestData.loginTD.getCountryName()); //added for country selection 
			wd.findElementByClassName("UIAWindow").click();
			Thread.sleep(5000);
			wd.findElement(By.xpath("//UIAApplication[1]/UIAWindow[1]/UIAButton[4]")).click();  //-added for next button
			Thread.sleep(5000);
			//WebElement t = (WebElement) wd.findElementsByName("NEXT").get(2);
			//t.click();
			//Thread.sleep(20000);
			wd.findElement(By.xpath("//UIAApplication[1]/UIAWindow[1]/UIATextField[3]")).sendKeys("Automation"); //added for setup text entering
			Thread.sleep(5000);
			wd.findElement(By.name("Passcode Button")).click();//added for tap on passcode button 
			//wd.findElement(By.xpath("//UIATextField[contains(@value,'Enter your Name')]")).sendKeys("Automation");
			//wd.findElementByClassName("UIAButton").click();
			Keyboard a = wd.getKeyboard();
			a.pressKey("12121");
			wd.findElement(By.name("Passcode Button")).click();
			//wd.findElementByClassName("UIAButton").click();
			a.pressKey("12121");
			Thread.sleep(60000);
		}
	}
		
	@When("^I navigate back to home screen from Product offering$")
	public void i_navigate_back_to_home_screen_from_Product_offering() throws Throwable {
		
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Set<String> AvailableContexts = wd.getContextHandles();
		for (String context : AvailableContexts)
		{
			if(context.contains("WEBVIEW"))
				wd.context(context);
		}
	
		wd.findElement(By.id("back-btn")).click();
	}
		
	
	@When("^I go to Product offering$")
	public void i_go_to_Product_offering() throws Throwable {
		new DashboardPage().navigateToProductOffering();
	}
	
	
	@Given("^I am in the Country$")
	public void i_am_in_the_Country() throws Throwable
	{
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		if(!wd.findElementsByName("Passcode Button").isEmpty())
		{
		
	      ((JavascriptExecutor)wd).executeScript("mobile: tap", new HashMap<String, Double>() {{ put("tapCount", (double) 1); put("touchCount",(double)  3); put("duration", 0.5); put("x", (double) 250); put("y", (double) 206); }});
	      ((JavascriptExecutor)wd).executeScript("mobile: tap", new HashMap<String, Double>() {{ put("tapCount", (double) 1); put("touchCount", (double) 1); put("duration", 0.5); put("x",  (double) 622); put("y", (double) 191); }});
	      ((JavascriptExecutor)wd).executeScript("mobile: tap", new HashMap<String, Double>() {{ put("tapCount", (double) 1); put("touchCount", (double) 1); put("duration", 0.5); put("x",  (double) 469); put("y", (double) 423); }});
	      Thread.sleep(10000);
		}
}
	
	@Given("^I am on the application home screen$")
	public void i_am_on_the_application_home_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		i_am_on_the_home_screen();
		//Thread.sleep(1000);
		WebDriverWait wait = new WebDriverWait(wd, 100);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.name("MY CLIENTS")));
		Thread.sleep(5000);
		
		
//		wait.until(ExpectedConditions.visibilityOf(wd.findElementByName("cloud white58x48")));	
		
	   
	}

	@Given("^I am on the My Clients screen$")
	public void I_am_on_the_My_Clients_screen() throws Throwable {
		i_am_on_the_home_screen();
		//Thread.sleep(1000);
		WebDriverWait wait = new WebDriverWait(wd, 100);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.name("MY CLIENTS")));		
		Thread.sleep(100000);
		wd.findElement(By.name("MY CLIENTS")).click();
		
		
		
	}
	
	/***
	 * Module - Login [Release -2] 
	 * Checking if the RM is able to login with invalid credentials
	 */
	
	@Given("^I am on the Home screen and entered invalid rmid and password$")
	public void i_am_on_the_home_screen_and_entered_invalid_rmid_and_password() throws Throwable {
	    
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		if(!wd.findElementsByName("Passcode Button").isEmpty()) 
		{	
			wd.findElementByClassName("UIAButton").click();
			Keyboard a = wd.getKeyboard();
			a.pressKey("12121");
		}		
		
		else
		{
					
			wd.findElementByName("NEXT").click();	 
			wd.findElementByClassName("UIATextField").sendKeys(ReadTestData.loginTD.getUsername1());
			wd.findElementByClassName("UIASecureTextField").sendKeys(ReadTestData.loginTD.getPassword());

			//wd.findElementsByClassName("UIATextField").clear();
			
			WebElement q = (WebElement) wd.findElementsByClassName("UIATextField").get(1);
			q.click();
			Thread.sleep(2000);
			wd.findElementByClassName("UIAPickerWheel").sendKeys(ReadTestData.loginTD.getCountryName()); //added for country selection 
			wd.findElementByClassName("UIAWindow").click();
			Thread.sleep(3000);
			wd.findElement(By.xpath("//UIAApplication[1]/UIAWindow[1]/UIAButton[4]")).click();  //-added for next button
			Thread.sleep(10000);
		 }
		}
	
	/***
	 * Module - Login [Release -2] 
	 * Checking if the RM is getting the error message if logged in with invalid credential
	 */
	
	@Then ("^I should see the error message$")
	public void i_should_see_the_error_message() throws Throwable {
	 wd.findElementByXPath("");
	}
	
	/***
	 * Module - Login [Release -2] 
	 * Checking whether the RM is able to login if entered invalid passcode
	 */
	
	 @Given("^I am on the Home screen and entered invalid passcode$")
		public void i_am_on_the_home_screen_and_entered_invalid_passcode() throws Throwable {
		    
			wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			if(!wd.findElementsByName("Passcode Button").isEmpty()) 
			{	
				wd.findElementByClassName("UIAButton").click();
				Keyboard a = wd.getKeyboard();
				a.pressKey("12121");
			}		
			
			else
			{
						
				wd.findElementByName("NEXT").click();	 
				wd.findElementByClassName("UIATextField").sendKeys(ReadTestData.loginTD.getUsername1());
				wd.findElementByClassName("UIASecureTextField").sendKeys(ReadTestData.loginTD.getPassword());

				//wd.findElementsByClassName("UIATextField").clear();
				
				WebElement q = (WebElement) wd.findElementsByClassName("UIATextField").get(1);
				q.click();
				Thread.sleep(2000);
				wd.findElementByClassName("UIAPickerWheel").sendKeys(ReadTestData.loginTD.getCountryName()); //added for country selection 
				wd.findElementByClassName("UIAWindow").click();
				Thread.sleep(3000);
				wd.findElement(By.xpath("//UIAApplication[1]/UIAWindow[1]/UIAButton[4]")).click();  //-added for next button
				Thread.sleep(10000);
				//WebElement t = (WebElement) wd.findElementsByName("NEXT").get(2);
				//t.click();
				//Thread.sleep(20000);
				wd.findElement(By.xpath("//UIAApplication[1]/UIAWindow[1]/UIATextField[3]")).sendKeys("Automation"); //added for setup text entering
				Thread.sleep(1000);
				wd.findElement(By.name("Passcode Button")).click();//added for tap on passcode button 
				//wd.findElement(By.xpath("//UIATextField[contains(@value,'Enter your Name')]")).sendKeys("Automation");
				//wd.findElementByClassName("UIAButton").click();
				Keyboard a = wd.getKeyboard();
				a.pressKey("12121");
				wd.findElement(By.name("Passcode Button")).click();
				//wd.findElementByClassName("UIAButton").click();
				a.pressKey("12345");
				Thread.sleep(30000);
			}
}


	 /***
		 * Module - Login [Release -2] 
		 * Checking if the RM is getting the error message if logged in with invalid credential
		 */
		@Then ("^I  should see the error message as Passcode did not match$")
		public void i_should_see_the_error_message_as_passcode_did_not_match() throws Throwable {
		 wd.findElementByXPath("");
		}
		
		@When("^I navigate to Application search$")
		public void i_navigate_to_Application_search() throws Throwable {
			new ProductOfferingPage().navigateToApplicationSearch();
		}
}

