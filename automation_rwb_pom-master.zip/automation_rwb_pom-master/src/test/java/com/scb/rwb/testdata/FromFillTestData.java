package com.scb.rwb.testdata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FromFillTestData {
	Map<String, ArrayList<String>> fields;
	int i;
	public FromFillTestData(Map<String, ArrayList<String>> fields,int count) {
		this.fields=fields;

		i = count;
//		setTitle(fields.containsKey("Us Resident Flag")?fields.get("Us Resident Flag"):title);

	}

	private String title;
	private String firstName;
	private String middleName;
	private String lastName;
	private String fullName;
	private String aliasName;
	private String idNo;
	private String idIssueDate;
	private String otherIdDetails;
	private String gender;
	private String maritalStatus;
	private String dateOfBirth;
	private String countryOfBirth;
	private String districtOfBirth;
	private String nationality;
	private String otherNation;
	private String passportNo;
	private String passportIssuanceDate;
	private String passportCountry;
	private String passportExpiryDate;
	private String drivingLicenseNo;
	private String drivingLicenseExpiryDate;
	private String drivingLicenseIssueDate;
	private String drivingLicenseIssueCountry;
	private String qualification;
	private String mothersMaidenName;
	private String fatherName;
	private String taxIdNo;
	private String residenceCountry;
	private String residentialStatus;
	private String noOfDependants;
	private String noOfCarOwned;
	private String staffCategory;
	private String spouseFullName;
	private String spouseProfession;
	private String spouseOrganisation;
	private String spouseOfficeLine1;
	private String spouseOfficeLine2;
	private String spouseOfficeLine3;
	private String spouseContactNo;
	private String spouseEmail;
	private String spouseFavColour;
	private String spouseFavCity;

	private String resAddressLine1;
	private String resAddressLine2;
	private String resAddressLine3;
	private String resAddressLine4;
	private String resPostalCode;
	private String resCity;
	private String resCountry;
	private String residenceType;
	private String rentPerAnnum;
	private String timeAtAddressYrs;
	private String perSameAsResidentialAddress;
	private String perAddressLine1;
	private String perAddressLine2;
	private String perAddressLine3;
	private String perAddressLine4;
	private String perPostalCode;
	private String perCity;
	private String perCountry;
	private String offAddressLine1;
	private String offAddressLine2;
	private String offAddressLine3;
	private String offAddressLine4;
	private String offPostalCode;
	private String offCity;
	private String offCountry;
	private String mailingAddress;
	private String othAddressLine1;
	private String othAddressLine2;
	private String othAddressLine3;
	private String othAddressLine4;
	private String othPostalCode;
	private String othCity;
	private String othCountry;
	private String proofAddressDoc;

	private String home;
	private String work;
	private String mobile;
	private String fax;
	private String email;
	private String otherContact;

	private String monSalaryIncome;
	private String monAllowances;
	private String monTotalIncome;
	private String sourceOfOtherIncome;
	private String spouseMonthlyIncome;
	private String othIncomeAvgTurnover;
	private String monthlyRentalIncome;
	private String monBizIncome;
	private String monRentUtility;
	private String monFoodExp;
	private String monEduExp;
	private String monLoanRepay;
	private String monOthExp;
	private String monTotalExp;


	private String employmentType;
	private String employmentStatus;
	private String company;
	private String businessType;
	private String businessSetupDate;
	private String businessOwnership;
	private String officePremiseStatus;
	private String prevBusinessName;
	private String totalLengthCurrBizYears;
	private String totalLengthCurrBizMonths;
	private String totalBizExpYears;
	private String totalBizExpMonths;
	private String profession;
	private String designation;
	private String employerCode;
	private String employeeStaffId;
	private String totalCurrEmpYears;
	private String totalCurrEmpMonths;
	private String totalLengthOfEmploymentYears;
	private String totalLengthOfEmploymentMonths;
	private String nameOfPrevEmployer;
	private String totalPrevEmpYears;
	private String totalPrevEmpMonths;

	
	private String	chequeBookRequiredCa;
	private String	chequeBookTypeCa;
	private String	requiredAtmDebitCard;
	private String	accountLinksToDebitCardAtm;
	private String	internetBanking;
	private String	smsAlerts;
	private String	eStatementCasa;
	private String	EeStatementTypeCasa;
	private String	statementHardcopyCasa;
	private String	statementFrequencyCasa;
	private String	eStatementCreditCard;
	private String	eStatementTypeCreditCard;
	private String	statementHardcopyCreditCard;
	private String	statementFrequencyCreditCard;
	
	
	
	private String	noNominee;
	private String	nomName1;
	private String	percent1;
	private String	nomName2;
	private String	percent2;
	private String	nomName3;
	private String	percent3;
	private String	bankName1;
	private String	branch1;
	private String	typeAccount1;
	private String	accountCardno1;
	private String	creditLoan1;
	private String	outstandingAmt1;
	private String	instalamt1;
	private String	cardMemberSince1;
	private String	bankName2;
	private String	branch2;
	private String	typeAccount2;
	private String	accountCardno2;
	private String	creditLoan2;
	private String	outstandingAmt2;
	private String	instalAmt2;
	private String	cardMemberSince2;
	private String	bankName3;
	private String	branch3;
	private String	typeAccount3;
	private String	accountCardno3;
	private String	creditLoan3;
	private String	outsSandingamt3;
	private String	instalAmt3;
	private String	cardMemberSince3;
	private String	loanRelatedcCient;
	private String	accountNo;
	private String	creditcardEmbossedName;
	private String	cardDeliveryAddType;
	private String	cardCollectionBranch;
	private String	loanAmount;
	private String	termMonths;
	private String	currency;
	private String	preferredBranch;
	private String	loanDisbaAcountno;
	private String	interestrateodFacility;
	private String	directorotherBanks;
	
	
	private String	aoForBusinessPuspose;
	private String	purposeAccOpen;
	private String	purposeOthersSpecify;
	private String	depositAmountUsd;
	private String	modeOfInitialFundsDeposit;
	private String	derWealthFromSanctionedCountries;
	private String	savingsNetWorthUsd;
	private String	sourceOfWealth;
	private String	SsourceFundSpecify;
	
	
	private String usResidentFlag;
	private String sCitizenFlag;
	private String prFlag;
	private String confirmation;
	
	
	private String	nbArmCode;
	private String	institutionClassification;
	private String	relationshipNo;
	private String	locationDhaka;
	private String	acqChannelCode;
	private String	preApprOffer;
	private String	preApprOfferDetails;
	private String	preApprOfferIdNo;
	private String	dseCode;
	private String	segment;
	private String	subSegment;
	private String	plSegment;
	private String	area;
	private String	armCode;
	private String	campaignCode;
	private String	deviationLevel;
	private String	loanNo;
	private String	masterNo;
	private String	payrollIndicator;
	private String	spotApproval;
	private String	topUp;
	private String	cibReportFetching;
	private String	forwardedBy;
	private String	referralCode;
	private String	salesStaffDesignation;
	private String	referenceNoCampaign;

	public String getTitle() {
		return fields.containsKey("Title")?fields.get("Title").get(i):title;
	}
	public String getFirstName() {
		return	fields.containsKey("First name")?fields.get("First name").get(i):firstName;
	}
	public String getMiddleName() {
		return	fields.containsKey("Middle name")?fields.get("Middle name").get(i):middleName;
	}
	public String getLastName() {
		return	fields.containsKey("Last name")?fields.get("Last name").get(i):lastName;
	}
	public String getFullName() {
		return	fields.containsKey("Full name")?fields.get("Full name").get(i):fullName;
	}
	public String getAliasName() {
		return	fields.containsKey("Alias name")?fields.get("Alias name").get(i):aliasName;
	}
	public String getIdNo() {
		return	fields.containsKey("Id no")?fields.get("Id no").get(i):idNo;
	}
	public String getIdIssueDate() {
		return	fields.containsKey("Id issue date")?fields.get("Id issue date").get(i):idIssueDate;
	}
	public String getOtherIdDetails() {
		return	fields.containsKey("Other id details")?fields.get("Other id details").get(i):otherIdDetails;
	}
	public String getGender() {
		return	fields.containsKey("Gender")?fields.get("Gender").get(i):gender;
	}
	public String getMaritalStatus() {
		return	fields.containsKey("Marital status")?fields.get("Marital status").get(i):maritalStatus;
	}
	public String getDateOfBirth() {
		return	fields.containsKey("Date of birth ddmmyyyy")?fields.get("Date of birth ddmmyyyy").get(i):dateOfBirth;
	}
	public String getCountryOfBirth() {
		return	fields.containsKey("Country of birth")?fields.get("Country of birth").get(i):countryOfBirth;
	}
	public String getDistrictOfBirth() {
		return	fields.containsKey("District of birth")?fields.get("District of birth").get(i):districtOfBirth;
	}
	public String getNationality() {
		return	fields.containsKey("Nationality")?fields.get("Nationality").get(i):nationality;
	}
	public String getOtherNation() {
		return	fields.containsKey("Other nation")?fields.get("Other nation").get(i):otherNation;
	}
	public String getPassportNo() {
		return	fields.containsKey("Passport no")?fields.get("Passport no").get(i):passportNo;
	}
	public String getPassportIssuanceDate() {
		return	fields.containsKey("Passport issuance date")?fields.get("Passport issuance date").get(i):passportIssuanceDate;
	}
	public String getPassportCountry() {
		return	fields.containsKey("Passport country")?fields.get("Passport country").get(i):passportCountry;
	}
	public String getPassportExpiryDate() {
		return	fields.containsKey("Passport expiry date")?fields.get("Passport expiry date").get(i):passportExpiryDate;
	}
	public String getDrivingLicenseNo() {
		return	fields.containsKey("Driving license no")?fields.get("Driving license no").get(i):drivingLicenseNo;
	}
	public String getDrivingLicenseExpiryDate() {
		return	fields.containsKey("Driving license expiry date")?fields.get("Driving license expiry date").get(i):drivingLicenseExpiryDate;
	}
	public String getDrivingLicenseIssueDate() {
		return	fields.containsKey("Driving license issue date")?fields.get("Driving license issue date").get(i):drivingLicenseIssueDate;
	}
	public String getDrivingLicenseIssueCountry() {
		return	fields.containsKey("Driving license issue country")?fields.get("Driving license issue country").get(i):drivingLicenseIssueCountry;
	}
	public String getQualification() {
		return	fields.containsKey("Qualification")?fields.get("Qualification").get(i):qualification;
	}
	public String getMothersMaidenName() {
		return	fields.containsKey("Mother's maiden name")?fields.get("Mother's maiden name").get(i):mothersMaidenName;
	}
	public String getFatherName() {
		return	fields.containsKey("Father name")?fields.get("Father name").get(i):fatherName;
	}
	public String getTaxIdNo() {
		return	fields.containsKey("Tax id no")?fields.get("Tax id no").get(i):taxIdNo;
	}
	public String getResidenceCountry() {
		return	fields.containsKey("Residence country")?fields.get("Residence country").get(i):residenceCountry;
	}
	public String getResidentialStatus() {
		return fields.containsKey("Residential status")?fields.get("Residential status").get(i):residentialStatus;
	}
	public String getNoOfDependants() {
		return fields.containsKey("No of dependants")?fields.get("No of dependants").get(i):noOfDependants;
	}
	public String getNoOfCarOwned() {
		return fields.containsKey("No of car owned")?fields.get("No of car owned").get(i):noOfCarOwned;
	}
	public String getStaffCategory() {
		return fields.containsKey("Staff category")?fields.get("Staff category").get(i):staffCategory;
	}
	public String getSpouseFullName() {
		return fields.containsKey("Spouse full name")?fields.get("Spouse full name").get(i):spouseFullName;
	}
	public String getSpouseProfession() {
		return fields.containsKey("Spouse profession")?fields.get("Spouse profession").get(i):spouseProfession;
	}
	public String getSpouseOrganisation() {
		return fields.containsKey("Spouse organisation")?fields.get("Spouse organisation").get(i):spouseOrganisation;
	}
	public String getSpouseOfficeLine1() {
		return fields.containsKey("Spouse office line1")?fields.get("Spouse office line1").get(i):spouseOfficeLine1;
	}
	public String getSpouseOfficeLine2() {
		return fields.containsKey("Spouse office line2")?fields.get("Spouse office line2").get(i):spouseOfficeLine2;
	}
	public String getSpouseOfficeLine3() {
		return fields.containsKey("Spouse office line3")?fields.get("Spouse office line3").get(i):spouseOfficeLine3;
	}
	public String getSpouseContactNo() {
		return fields.containsKey("Spouse contact no")?fields.get("Spouse contact no").get(i):spouseContactNo;
	}
	public String getSpouseEmail() {
		return fields.containsKey("Spouse email")?fields.get("Spouse email").get(i):spouseEmail;
	}
	public String getSpouseFavColour() {
		return fields.containsKey("Spouse fav colour")?fields.get("Spouse fav colour").get(i):spouseFavColour;
	}
	public String getSpouseFavCity() {
		return fields.containsKey("Spouse fav city")?fields.get("Spouse fav city").get(i):spouseFavCity;
	}
	
	
	public String getResAddressLine1() {
		return fields.containsKey("Res address line 1")?fields.get("Res address line 1").get(i):resAddressLine1;
	}
	public String getResAddressLine2() {
		return fields.containsKey("Res address line 2")?fields.get("Res address line 2").get(i):resAddressLine2;
	}
	public String getResAddressLine3() {
		return fields.containsKey("Res address line 3")?fields.get("Res address line 3").get(i):resAddressLine3;
	}
	public String getResAddressLine4() {
		return fields.containsKey("Res address line 4")?fields.get("Res address line 4").get(i):resAddressLine4;
	}
	public String getResPostalCode() {
		return fields.containsKey("Res postal code")?fields.get("Res postal code").get(i):resPostalCode;
	}
	public String getResCity() {
		return fields.containsKey("Res city")?fields.get("Res city").get(i):resCity;
	}
	public String getResCountry() {
		return fields.containsKey("Res country")?fields.get("Res country").get(i):resCountry;
	}
	public String getResidenceType() {
		return fields.containsKey("Residence type")?fields.get("Residence type").get(i):residenceType;
	}
	public String getRentPerAnnum() {
		return fields.containsKey("Rent per annum ")?fields.get("Rent per annum ").get(i):rentPerAnnum;
	}
	public String getTimeAtAddressYrs() {
		return fields.containsKey("Time at address yrs")?fields.get("Time at address yrs").get(i):timeAtAddressYrs;
	}
	public String getPerSameAsResidentialAddress() {
		return fields.containsKey("Per same as residential address")?fields.get("Per same as residential address").get(i):perSameAsResidentialAddress;
	}
	public String getPerAddressLine1() {
		return fields.containsKey("Per address line 1")?fields.get("Per address line 1").get(i):perAddressLine1;
	}
	public String getPerAddressLine2() {
		return fields.containsKey("Per address line 2")?fields.get("Per address line 2").get(i):perAddressLine2;
	}
	public String getPerAddressLine3() {
		return fields.containsKey("Per address line 3")?fields.get("Per address line 3").get(i):perAddressLine3;
	}
	public String getPerAddressLine4() {
		return fields.containsKey("Per address line 4")?fields.get("Per address line 4").get(i):perAddressLine4;
	}
	public String getPerPostalCode() {
		return fields.containsKey("Per postal code")?fields.get("Per postal code").get(i):perPostalCode;
	}
	public String getPerCity() {
		return fields.containsKey("Per city")?fields.get("Per city").get(i):perCity;
	}
	public String getPerCountry() {
		return fields.containsKey("Per country")?fields.get("Per country").get(i):perCountry;
	}
	public String getOffAddressLine1() {
		return fields.containsKey("Off address line 1")?fields.get("Off address line 1").get(i):offAddressLine1;
	}
	public String getOffAddressLine2() {
		return fields.containsKey("Off address line 2")?fields.get("Off address line 2").get(i):offAddressLine2;
	}
	public String getOffAddressLine3() {
		return fields.containsKey("Off address line 3")?fields.get("Off address line 3").get(i):offAddressLine3;
	}
	public String getOffAddressLine4() {
		return fields.containsKey("Off address line 4")?fields.get("Off address line 4").get(i):offAddressLine4;
	}
	public String getOffPostalCode() {
		return fields.containsKey("Off postal code")?fields.get("Off postal code").get(i):offPostalCode;
	}
	public String getOffCity() {
		return fields.containsKey("Off city")?fields.get("Off city").get(i):offCity;
	}
	public String getOffCountry() {
		return fields.containsKey("Off country")?fields.get("Off country").get(i):offCountry;
	}
	public String getMailingAddress() {
		return fields.containsKey("Mailing address")?fields.get("Mailing address").get(i):mailingAddress;
	}
	public String getOthAddressLine1() {
		return fields.containsKey("Oth address line 1")?fields.get("Oth address line 1").get(i):othAddressLine1;
	}
	public String getOthAddressLine2() {
		return fields.containsKey("Oth address line 2")?fields.get("Oth address line 2").get(i):othAddressLine2;
	}
	public String getOthAddressLine3() {
		return fields.containsKey("Oth address line 3")?fields.get("Oth address line 3").get(i):othAddressLine3;
	}
	public String getOthAddressLine4() {
		return fields.containsKey("Oth address line 4")?fields.get("Oth address line 4").get(i):othAddressLine4;
	}
	public String getOthPostalCode() {
		return fields.containsKey("Oth postal code")?fields.get("Oth postal code").get(i):othPostalCode;
	}
	public String getOthCity() {
		return fields.containsKey("Oth city")?fields.get("Oth city").get(i):othCity;
	}
	public String getOthCountry() {
		return fields.containsKey("Oth country")?fields.get("Oth country").get(i):othCountry;
	}
	public String getProofAddressDoc() {
		return fields.containsKey("proof address doc")?fields.get("proof address doc").get(i):proofAddressDoc;
	}
	
	
	public String getHome() {
		return fields.containsKey("Home")?fields.get("Home").get(i):home;
	}
	public String getWork() {
		return fields.containsKey("Work")?fields.get("Work").get(i):work;
	}
	public String getMobile() {
		return fields.containsKey("Mobile")?fields.get("Mobile").get(i):mobile;
	}
	public String getFax() {
		return fields.containsKey("Fax")?fields.get("Fax").get(i):fax;
	}
	public String getEmail() {
		return fields.containsKey("Email")?fields.get("Email").get(i):email;
	}
	public String getOtherContact() {
		return fields.containsKey("Other contact")?fields.get("Other contact").get(i):otherContact;
	}
	
	
	public String getMonSalaryIncome() {
		return fields.containsKey("Monthly salary income lcy")?fields.get("Monthly salary income lcy").get(i):monSalaryIncome;
	}
	public String getMonAllowances() {
		return fields.containsKey("Monthly allowances lcy")?fields.get("Monthly allowances lcy").get(i):monAllowances;
	}
	public String getMonTotalIncome() {
		return fields.containsKey("Monthly total income lcy")?fields.get("Monthly total income lcy").get(i):monTotalIncome;
	}
	public String getSourceOfOtherIncome() {
		return fields.containsKey("Source of other income")?fields.get("Source of other income").get(i):sourceOfOtherIncome;
	}
	public String getSpouseMonthlyIncome() {
		return fields.containsKey("Spouses monthly income lcy")?fields.get("Spouses monthly income lcy").get(i):spouseMonthlyIncome;
	}
	public String getOthIncomeAvgTurnover() {
		return fields.containsKey("Other income avg turnover for self employed lcy")?fields.get("Other income avg turnover for self employed lcy").get(i):othIncomeAvgTurnover;
	}
	public String getMonthlyRentalIncome() {
		return fields.containsKey("Monthly rental income lcy")?fields.get("Monthly rental income lcy").get(i):monthlyRentalIncome;
	}
	public String getMonBizIncome() {
		return fields.containsKey("Monthly biz income lcy")?fields.get("Monthly biz income lcy").get(i):monBizIncome;
	}
	public String getMonRentUtility() {
		return fields.containsKey("Monthly rent utility exp lcy")?fields.get("Monthly rent utility exp lcy").get(i):monRentUtility;
	}
	public String getMonFoodExp() {
		return fields.containsKey("Monthly food exp lcy")?fields.get("Monthly food exp lcy").get(i):monFoodExp;
	}
	public String getMonEduExp() {
		return fields.containsKey("Monthly edu exp lcy")?fields.get("Monthly edu exp lcy").get(i):monEduExp;
	}
	public String getMonLoanRepay() {
		return fields.containsKey("Monthly loan repay lcy")?fields.get("Monthly loan repay lcy").get(i):monLoanRepay;
	}
	public String getMonOthExp() {
		return fields.containsKey("Monthly oth exp lcy")?fields.get("Monthly oth exp lcy").get(i):monOthExp;
	}
	public String getMonTotalExp() {
		return fields.containsKey("Monthly total exp lcy")?fields.get("Monthly total exp lcy").get(i):monTotalExp;
	}
	
	
	public String getEmploymentType() {
		return fields.containsKey("Employment type")?fields.get("Employment type").get(i):employmentType;
	}
	public String getEmploymentStatus() {
		return fields.containsKey("Employment status")?fields.get("Employment status").get(i):employmentStatus;
	}
	public String getCompany() {
		return fields.containsKey("Company")?fields.get("Company").get(i):company;
	}
	public String getBusinessType() {
		return fields.containsKey("Business type")?fields.get("Business type").get(i):businessType;
	}
	public String getBusinessSetupDate() {
		return fields.containsKey("Business setup date")?fields.get("Business setup date").get(i):businessSetupDate;
	}
	public String getBusinessOwnership() {
		return fields.containsKey("Business ownership")?fields.get("Business ownership").get(i):businessOwnership;
	}
	public String getOfficePremiseStatus() {
		return fields.containsKey("Office premise status")?fields.get("Office premise status").get(i):officePremiseStatus;
	}
	public String getPrevBusinessName() {
		return fields.containsKey("Prev business name")?fields.get("Prev business name").get(i):prevBusinessName;
	}
	public String getTotalLengthCurrBizYears() {
		return fields.containsKey("Total length curr biz years")?fields.get("Total length curr biz years").get(i):totalLengthCurrBizYears;
	}
	public String getTotalLengthCurrBizMonths() {
		return fields.containsKey("Total length curr biz months")?fields.get("Total length curr biz months").get(i):totalLengthCurrBizMonths;
	}
	public String getTotalBizExpYears() {
		return fields.containsKey("Total biz exp years")?fields.get("Total biz exp years").get(i):totalBizExpYears;
	}
	public String getTotalBizExpMonths() {
		return fields.containsKey("Total biz exp months")?fields.get("Total biz exp months").get(i):totalBizExpMonths;
	}
	public String getProfession() {
		return fields.containsKey("Profession")?fields.get("Profession").get(i):profession;
	}
	public String getDesignation() {
		return fields.containsKey("Designation")?fields.get("Designation").get(i):designation;
	}
	public String getEmployerCode() {
		return fields.containsKey("Employer code")?fields.get("Employer code").get(i):employerCode;
	}
	public String getEmployeeStaffId() {
		return fields.containsKey("Employee staff id")?fields.get("Employee staff id").get(i):employeeStaffId;
	}
	public String getTotalCurrEmpYears() {
		return fields.containsKey("Total curr emp years")?fields.get("Total curr emp years").get(i):totalCurrEmpYears;
	}
	public String getTotalCurrEmpMonths() {
		return fields.containsKey("Total curr emp months")?fields.get("Total curr emp months").get(i):totalCurrEmpMonths;
	}
	public String getTotalLengthOfEmploymentYears() {
		return fields.containsKey("Total length of employment years")?fields.get("Total length of employment years").get(i):totalLengthOfEmploymentYears;
	}
	public String getTotalLengthOfEmploymentMonths() {
		return fields.containsKey("Total length of employment months")?fields.get("Total length of employment months").get(i):totalLengthOfEmploymentMonths;
	}
	public String getNameOfPrevEmployer() {
		return fields.containsKey("Name of prev employer")?fields.get("Name of prev employer").get(i):nameOfPrevEmployer;
	}
	public String getTotalPrevEmpYears() {
		return fields.containsKey("Total prev emp years")?fields.get("Total prev emp years").get(i):totalPrevEmpYears;
	}
	public String getTotalPrevEmpMonths() {
		return fields.containsKey("Total prev emp months")?fields.get("Total prev emp months").get(i):totalPrevEmpMonths;
	}
	
	
	public String getChequeBookRequiredCa() {
		return fields.containsKey("Cheque book required ca")?fields.get("Cheque book required ca").get(i):chequeBookRequiredCa;
	}
	public String getChequeBookTypeCa() {
		return fields.containsKey("Cheque book type ca")?fields.get("Cheque book type ca").get(i):chequeBookTypeCa;
	}
	public String getRequiredAtmDebitCard() {
		return fields.containsKey("Required atm debit card")?fields.get("Required atm debit card").get(i):requiredAtmDebitCard;
	}
	public String getAccountLinksToDebitCardAtm() {
		return fields.containsKey("Account links to debit card atm")?fields.get("Account links to debit card atm").get(i):accountLinksToDebitCardAtm;
	}
	public String getInternetBanking() {
		return fields.containsKey("Internet banking")?fields.get("Internet banking").get(i):internetBanking;
	}
	public String getSmsAlerts() {
		return fields.containsKey("Sms alerts")?fields.get("Sms alerts").get(i):smsAlerts;
	}
	public String geteStatementCasa() {
		return fields.containsKey("E statement casa")?fields.get("E statement casa").get(i):eStatementCasa;
	}
	public String getEeStatementTypeCasa() {
		return fields.containsKey("E statement type casa")?fields.get("E statement type casa").get(i):EeStatementTypeCasa;
	}
	public String getStatementHardcopyCasa() {
		return fields.containsKey("Statement hardcopy casa")?fields.get("Statement hardcopy casa").get(i):statementHardcopyCasa;
	}
	public String getStatementFrequencyCasa() {
		return fields.containsKey("Statement frequency casa")?fields.get("Statement frequency casa").get(i):statementFrequencyCasa;
	}
	public String geteStatementCreditCard() {
		return fields.containsKey("E statement credit card")?fields.get("E statement credit card").get(i):eStatementCreditCard;
	}
	public String geteStatementTypeCreditCard() {
		return fields.containsKey("E statement type credit card")?fields.get("E statement type credit card").get(i):eStatementTypeCreditCard;
	}
	public String getStatementHardcopyCreditCard() {
		return fields.containsKey("Statement hardcopy credit card")?fields.get("Statement hardcopy credit card").get(i):statementHardcopyCreditCard;
	}
	public String getStatementFrequencyCreditCard() {
		return fields.containsKey("Statement frequency credit card")?fields.get("Statement frequency credit card").get(i):statementFrequencyCreditCard;
	}
	
	
	public String getNoNominee() {
		return fields.containsKey("No Nominee")?fields.get("No Nominee").get(i):noNominee;
	}
	public String getNomName1() {
		return fields.containsKey("nom name 1")?fields.get("nom name 1").get(i):nomName1;
	}
	public String getPercent1() {
		return fields.containsKey("percent 1")?fields.get("percent 1").get(i):percent1;
	}
	public String getNomName2() {
		return fields.containsKey("nom name 2")?fields.get("nom name 2").get(i):nomName2;
	}
	public String getPercent2() {
		return fields.containsKey("percent 2")?fields.get("percent 2").get(i):percent2;
	}
	public String getNomName3() {
		return fields.containsKey("nom name 3")?fields.get("nom name 3").get(i):nomName3;
	}
	public String getPercent3() {
		return fields.containsKey("percent 3")?fields.get("percent 3").get(i):percent3;
	}
	public String getBankName1() {
		return fields.containsKey("Bank name 1")?fields.get("Bank name 1").get(i):bankName1;
	}
	public String getBranch1() {
		return fields.containsKey("Branch 1")?fields.get("Branch 1").get(i):branch1;
	}
	public String getTypeAccount1() {
		return fields.containsKey("Type account 1")?fields.get("Type account 1").get(i):typeAccount1	;
	}
	public String getAccountCardno1() {
		return fields.containsKey("Account card no 1")?fields.get("Account card no 1").get(i):accountCardno1;
	}
	public String getCreditLoan1() {
		return fields.containsKey("Credit loan 1")?fields.get("Credit loan 1").get(i):creditLoan1;
	}
	public String getOutstandingAmt1() {
		return fields.containsKey("Outstanding amt 1")?fields.get("Outstanding amt 1").get(i):outstandingAmt1;
	}
	public String getInstalamt1() {
		return fields.containsKey("Instal amt 1")?fields.get("Instal amt 1").get(i):instalamt1;
	}
	public String getCardMemberSince1() {
		return fields.containsKey("Card member since 1")?fields.get("Card member since 1").get(i):cardMemberSince1;
	}
	public String getBankName2() {
		return fields.containsKey("Bank name 2")?fields.get("Bank name 2").get(i):bankName2;
	}
	public String getBranch2() {
		return fields.containsKey("Branch 2")?fields.get("Branch 2").get(i):branch2;
	}
	public String getTypeAccount2() {
		return fields.containsKey("Type account 2")?fields.get("Type account 2").get(i):typeAccount2;
	}
	public String getAccountCardno2() {
		return fields.containsKey("Account card no 2")?fields.get("Account card no 2").get(i):accountCardno2;
	}
	public String getCreditLoan2() {
		return fields.containsKey("Credit loan 2")?fields.get("Credit loan 2").get(i):creditLoan2;
	}
	public String getOutstandingAmt2() {
		return fields.containsKey("Outstanding amt 2")?fields.get("Outstanding amt 2").get(i):outstandingAmt2;
	}
	public String getInstalAmt2() {
		return fields.containsKey("Instal amt 2")?fields.get("Instal amt 2").get(i):instalAmt2;
	}
	public String getCardMemberSince2() {
		return fields.containsKey("Card member since 2")?fields.get("Card member since 2").get(i):cardMemberSince2;
	}
	public String getBankName3() {
		return fields.containsKey("Bank name 3")?fields.get("Bank name 3").get(i):bankName3;
	}
	public String getBranch3() {
		return fields.containsKey("Branch 3")?fields.get("Branch 3").get(i):branch3;
	}
	public String getTypeAccount3() {
		return fields.containsKey("Type account 3")?fields.get("Type account 3").get(i):typeAccount3;
	}
	public String getAccountCardno3() {
		return fields.containsKey("Account card no 3")?fields.get("Account card no 3").get(i):accountCardno3;
	}
	public String getCreditLoan3() {
		return fields.containsKey("Credit loan 3")?fields.get("Credit loan 3").get(i):creditLoan3;
	}
	public String getOutsSandingamt3() {
		return fields.containsKey("Outstanding amt 3")?fields.get("Outstanding amt 3").get(i):outsSandingamt3;
	}
	public String getInstalAmt3() {
		return fields.containsKey("Instal amt 3")?fields.get("Instal amt 3").get(i):instalAmt3;
	}
	public String getCardMemberSince3() {
		return fields.containsKey("Card member since 3")?fields.get("Card member since 3").get(i):cardMemberSince3;
	}
	public String getLoanRelatedcCient() {
		return fields.containsKey("Loan related client")?fields.get("Loan related client").get(i):loanRelatedcCient;
	}
	public String getAccountNo() {
		return fields.containsKey("Account no")?fields.get("Account no").get(i):accountNo;
	}
	public String getCreditcardEmbossedName() {
		return fields.containsKey("Credit card embossed name")?fields.get("Credit card embossed name").get(i):creditcardEmbossedName;
	}
	public String getCardDeliveryAddType() {
		return fields.containsKey("Card delivery add type")?fields.get("Card delivery add type").get(i):cardDeliveryAddType;
	}
	public String getCardCollectionBranch() {
		return fields.containsKey("Card collection branch")?fields.get("Card collection branch").get(i):cardCollectionBranch;
	}
	public String getLoanAmount() {
		return fields.containsKey("Loan amount")?fields.get("Loan amount").get(i):loanAmount;
	}
	public String getTermMonths() {
		return fields.containsKey("Term months")?fields.get("Term months").get(i):termMonths;
	}
	public String getCurrency() {
		return fields.containsKey("Currency")?fields.get("Currency").get(i):currency;
	}
	public String getPreferredBranch() {
		return fields.containsKey("Preferred branch")?fields.get("Preferred branch").get(i):preferredBranch;
	}
	public String getLoanDisbaAcountno() {
		return fields.containsKey("Loan disb account no")?fields.get("Loan disb account no").get(i):loanDisbaAcountno;
	}
	public String getInterestrateodFacility() {
		return fields.containsKey("Interest rate od facility")?fields.get("Interest rate od facility").get(i):interestrateodFacility;
	}
	public String getDirectorotherBanks() {
		return fields.containsKey("Director other banks")?fields.get("Director other banks").get(i):directorotherBanks;
	}
	
	
	public String getAoForBusinessPuspose() {
		return fields.containsKey("Ao for business puspose")?fields.get("Ao for business puspose").get(i):aoForBusinessPuspose;
	}
	public String getPurposeAccOpen() {
		return fields.containsKey("Purpose acc open")?fields.get("Purpose acc open").get(i):purposeAccOpen;
	}
	public String getPurposeOthersSpecify() {
		return fields.containsKey("Purpose others specify")?fields.get("Purpose others specify").get(i):purposeOthersSpecify;
	}
	public String getDepositAmountUsd() {
		return fields.containsKey("Deposit amount usd")?fields.get("Deposit amount usd").get(i):depositAmountUsd;
	}
	public String getModeOfInitialFundsDeposit() {
		return fields.containsKey("Mode of initial funds deposit")?fields.get("Mode of initial funds deposit").get(i):modeOfInitialFundsDeposit;
	}
	public String getDerWealthFromSanctionedCountries() {
		return fields.containsKey("Der wealth from sanctioned countries")?fields.get("Der wealth from sanctioned countries").get(i):derWealthFromSanctionedCountries;
	}
	public String getSavingsNetWorthUsd() {
		return fields.containsKey("Savings net worth usd")?fields.get("Savings net worth usd").get(i):savingsNetWorthUsd;
	}
	public String getSourceOfWealth() {
		return fields.containsKey("Source of wealth")?fields.get("Source of wealth").get(i):sourceOfWealth;
	}
	public String getSsourceFundSpecify() {
		return fields.containsKey("Source fund specify")?fields.get("Source fund specify").get(i):SsourceFundSpecify;
	}
	
	
	public String getUsResidentFlag() {
		return fields.containsKey("Us Resident Flag")?fields.get("Us Resident Flag").get(i):usResidentFlag;
	}
	public String getsCitizenFlag() {
		return fields.containsKey("Us Citizen Flag")?fields.get("Us Citizen Flag").get(i):sCitizenFlag;
	}
	public String getPrFlag() {
		return fields.containsKey("Pr Flag")?fields.get("Pr Flag").get(i):prFlag;
	}
	public String getConfirmation() {
		return fields.containsKey("Confirmation")?fields.get("Confirmation").get(i):confirmation;
	}
	
	
	public String getNbArmCode() {
		return fields.containsKey("Nb arm code")?fields.get("Nb arm code").get(i):nbArmCode;
	}
	public String getInstitutionClassification() {
		return fields.containsKey("Institution classification")?fields.get("Institution classification").get(i):institutionClassification;
	}
	public String getRelationshipNo() {
		return fields.containsKey("Relationship no")?fields.get("Relationship no").get(i):relationshipNo;
	}
	public String getLocationDhaka() {
		return fields.containsKey("Location dhaka")?fields.get("Location dhaka").get(i):locationDhaka;
	}
	public String getAcqChannelCode() {
		return fields.containsKey("Acq channel code")?fields.get("Acq channel code").get(i):acqChannelCode;
	}
	public String getPreApprOffer() {
		return fields.containsKey("Pre appr offer")?fields.get("Pre appr offer").get(i):preApprOffer;
	}
	public String getPreApprOfferDetails() {
		return fields.containsKey("Pre appr offer details")?fields.get("Pre appr offer details").get(i):preApprOfferDetails;
	}
	public String getPreApprOfferIdNo() {
		return fields.containsKey("Pre appr offer id no")?fields.get("Pre appr offer id no").get(i):preApprOfferIdNo;
	}
	public String getDseCode() {
		return fields.containsKey("dse code")?fields.get("dse code").get(i):dseCode;
	}
	public String getSegment() {
		return fields.containsKey("Segment")?fields.get("Segment").get(i):segment;
	}
	public String getSubSegment() {
		return fields.containsKey("Sub segment")?fields.get("Sub segment").get(i):subSegment;
	}
	public String getPlSegment() {
		return fields.containsKey("Pl segment")?fields.get("Pl segment").get(i):plSegment;
	}
	public String getArea() {
		return fields.containsKey("Area")?fields.get("Area").get(i):area;
	}
	public String getArmCode() {
		return fields.containsKey("Arm code")?fields.get("Arm code").get(i):armCode;
	}
	public String getCampaignCode() {
		return fields.containsKey("Campaign code")?fields.get("Campaign code").get(i):campaignCode;
	}
	public String getDeviationLevel() {
		return fields.containsKey("Deviation level")?fields.get("Deviation level").get(i):deviationLevel;
	}
	public String getLoanNo() {
		return fields.containsKey("Loan no")?fields.get("Loan no").get(i):loanNo;
	}
	public String getMasterNo() {
		return fields.containsKey("Master no")?fields.get("Master no").get(i):masterNo;
	}
	public String getPayrollIndicator() {
		return fields.containsKey("Payroll indicator")?fields.get("Payroll indicator").get(i):payrollIndicator;
	}
	public String getSpotApproval() {
		return fields.containsKey("Spot approval")?fields.get("Spot approval").get(i):spotApproval;
	}
	public String getTopUp() {
		return fields.containsKey("Top up")?fields.get("Top up").get(i):topUp;
	}
	public String getCibReportFetching() {
		return fields.containsKey("Cib report fetching")?fields.get("Cib report fetching").get(i):cibReportFetching;
	}
	public String getForwardedBy() {
		return fields.containsKey("Forwarded by")?fields.get("Forwarded by").get(i):forwardedBy;
	}
	public String getReferralCode() {
		return fields.containsKey("Referral code")?fields.get("Referral code").get(i):referralCode;
	}
	public String getSalesStaffDesignation() {
		return fields.containsKey("Sales staff designation")?fields.get("Sales staff designation").get(i):salesStaffDesignation;
	}
	public String getReferenceNoCampaign() {
		return fields.containsKey("Reference no campaign")?fields.get("Reference no campaign").get(i):referenceNoCampaign;
	}
	


}
