package com.scb.rwb.appium.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.antlr.PythonParser.return_stmt_return;

import com.scb.rwb.glue.TestData;
import com.scb.rwb.wrappers.ApplicationWrappers;

public class DashboardPage extends AppiumBasePage {


	// @FindBy(name ="MY CLIENTS")
	// WebElement diaryMyClient;
	String ds = "";
	By diaryMyClient = By.name("MY CLIENTS");

	@FindBy(xpath = "//XCUIElementTypeStaticText[@value='PRODUCT OFFERING']")
	WebElement mnuDiaryProductOffering;

	@FindBy(name = "PRODUCT OFFERING")
	WebElement nameDiaryProductOffering;
	
	@FindBy(name = "APPLICATION")
	WebElement lnkApplication;
	
	@FindBy(name = "cloud white58x48")
	WebElement btnSync;
	
	@FindBy(name = "cloud grey58x48")
	WebElement btnSyncApplication;
	
	@FindBy(name = "OK,Move.")
	WebElement btnOkMove;
	
	@FindBy(name = "Select applications below to move to server")
	WebElement lblSelectApplicationsBelowToMoveToServer;
	
	@FindBy(name = "Moving Applications to server. Please wait")
	WebElement msgMovingApplication;
	
	@FindBy(name = "There are no applications to move")
	WebElement msgNoApplicationsToMove;
	
	@FindBy(name = "icon close")
	WebElement btnClose;
	
	@FindBy(name = "PRODUCT OFFERING")
	WebElement btnProductOffering;
	
	@FindBy(className = "UIAWindow")
	WebElement wndUIAWindow;

	// @AndroidFindBy(accessibility = "Left Menu Button")
	// MobileElement menuLeftMenu;
	String menuLeftMenu = "Left Menu Button";

	// @AndroidFindBy(accessibility = "Product Offering")
	// MobileElement subMenuProductOffering;
	String subMenuProductOffering = "Product Offering";
	
	

	/**
	 * This Method Will Wait For The Presence Of The Given Element To Be Located
	 * 
	 * @return
	 */
	public DashboardPage waitForGivenLocatorToBeLocated() {
		waitForpresenceOfElementLocated(diaryMyClient);
		return this;
	}

	
	
	/**
	 * This Method Will Navigate The User To Application Queues Page
	 * 
	 * @return
	 */
	public ApplicationQueuesPage clickApplication(){
		switchToNativeApp();
		sleep(40000);
		lnkApplication.click();
		System.out.println("Link App");
		System.out.println("Waiting For 10 Seconds...");
		sleep(10000);
		return new ApplicationQueuesPage();
	}
	
	/**
	 * This Method Will Navigate The User To Sync Feature
	 * 
	 * @return
	 */
	public DashboardPage navigateToSyncFeature(){
		switchToNativeApp();
		waitForvisiblityOfGivenElement(btnSync);
		btnSync.click();
		return new DashboardPage();
	}
	
	/**
	 * This Method Will Verify The Created Application Number
	 * 
	 * @return
	 */
	public DashboardPage verifyCreatedApplicationNumber(){
		Assert.assertTrue(lblSelectApplicationsBelowToMoveToServer.isDisplayed());
		return new DashboardPage();
	}
	
	/**
	 * This Method Will Sync The Application Created
	 * 
	 * @return
	 */
	public DashboardPage syncApplication(){
		
		waitForvisiblityOfGivenElement(btnSyncApplication);
		btnSyncApplication.click();
		waitForvisiblityOfGivenElement(btnOkMove);
		btnOkMove.click();
		return new DashboardPage();
		
	}
	
	/**
	 * This Method Will Verify That The Application Synced Successfully
	 * 
	 * @return
	 */
	public DashboardPage verifyApplicationSyncedSuccessfully(){
		waitForvisiblityOfGivenElement(msgMovingApplication);
		msgMovingApplication.isDisplayed();
		sleep(60000);
		waitForvisiblityOfGivenElement(msgNoApplicationsToMove);
		msgNoApplicationsToMove.isDisplayed();
		waitForvisiblityOfGivenElement(btnClose);
		btnClose.click();
		return new DashboardPage();
	}
	
	/**
	 * This method will select the Product Offering from the left Menu
	 * 
	 * @return
	 */
	public ProductOfferingPage selectProductOfferingPage() {
		sleep(35000);
		waitForvisiblityOfGivenElement(wd.findElementByAccessibilityId(menuLeftMenu));
		sleep(5000);
		wd.findElementByAccessibilityId(menuLeftMenu).click();
		sleep(5000);
		wd.findElementByAccessibilityId(subMenuProductOffering).click();
		return new ProductOfferingPage();
	}
	
	/**
	 * This Method Will Navigate The User To Product Offering Page
	 * 
	 * @return
	 */
	public ProductOfferingPage navigateToProductOffering(){
		waitForvisiblityOfGivenElement(btnSync);
		waitForvisiblityOfGivenElement(btnProductOffering);
		btnProductOffering.click();
		waitForvisiblityOfGivenElement(btnProductOffering);
		wndUIAWindow.click();
		return new ProductOfferingPage();
	}

}
