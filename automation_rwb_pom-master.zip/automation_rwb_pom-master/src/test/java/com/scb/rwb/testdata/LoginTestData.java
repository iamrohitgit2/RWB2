package com.scb.rwb.testdata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginTestData {
	Map<String, ArrayList<String>> fields;
	int i;
	public LoginTestData(HashMap<String, ArrayList<String>> fields,int count) {
		this.fields=fields;

		i = count;
//		setTitle(fields.containsKey("Us Resident Flag")?fields.get("Us Resident Flag"):title);

	}

	private String username1;
	private String codingUsername;
	private String password;
	private String countryCode;
	private String username2;
	private String countryName;
	

	
	public String getUsername1() {
		return	fields.containsKey("Username1")?fields.get("Username1").get(i):username1;
	}
	
	public String getCodingUsername() {
		return	fields.containsKey("Coding Username")?fields.get("Coding username").get(i):codingUsername;
	}
	
	public String getPassword() {
		return fields.containsKey("Password")?fields.get("Password").get(i):password;
	}
	
	public String getCountryCode(){
		return fields.containsKey("Country Code")?fields.get("Country Code").get(i):countryCode;
	}
	
	public String getUsername2(){
		return fields.containsKey("Username2")?fields.get("Username2").get(i):username2;
	}
	
	public String getCountryName() {
		return fields.containsKey("Country Name")?fields.get("Country Name").get(i):countryName;
	}

}
