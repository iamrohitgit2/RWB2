package com.scb.rwb.glue;

import io.appium.java_client.AppiumDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import com.scb.rwb.appium.pages.AOFPage;
import com.scb.rwb.wrappers.ApplicationWrappers;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OzForm extends ApplicationWrappers{

	@Then("^OZ form should be displayed$")
	public void oz_form_should_be_displayed() throws Throwable {
		new AOFPage().ozFormShouldBeDisplayed();
	}

	@When("^I submit OZ form$")
	public void i_submit_OZ_form() throws Throwable {
		new AOFPage().submitOZForm();
	}
}
