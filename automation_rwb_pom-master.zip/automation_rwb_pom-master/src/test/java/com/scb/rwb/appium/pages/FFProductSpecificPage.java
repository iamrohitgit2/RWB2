package com.scb.rwb.appium.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.utility.ReadTestData;

public class FFProductSpecificPage extends AppiumBasePage {


	@FindBy(id = "select-component_ps-no-nominee_wrapper")
	WebElement slctNoOfNominee;

	@FindBy(id = "text-component_ps-nom-name-1_wrapper")
	WebElement txtNomineeName1;

	@FindBy(id = "text-component_ps-percent-1_wrapper")
	WebElement txtPercent1;

	@FindBy(id = "text-component_ps-nom-name-2_wrapper")
	WebElement txtNomineeName2;

	@FindBy(id = "text-component_ps-percent-2_wrapper")
	WebElement txtPercent2;

	@FindBy(id = "text-component_ps-nom-name-3_wrapper")
	WebElement txtNomineeName3;

	@FindBy(id = "text-component_ps-percent-3_wrapper")
	WebElement txtPercent3;

	@FindBy(id = "text-component_ps-bank-name-1_wrapper")
	WebElement txtBankName1;

	@FindBy(id = "text-component_ps-branch-1_wrapper")
	WebElement txtBranch1;

	@FindBy(id = "text-component_ps-type-account-1_wrapper")
	WebElement txtTypeAccount1;

	@FindBy(id = "text-component_ps-account-card-no-1_wrapper")
	WebElement txtAccountCardno1;

	@FindBy(id = "text-component_ps-credit-loan-1_wrapper")
	WebElement txtCreditLoan1;

	@FindBy(id = "text-component_ps-outstanding-amt-1_wrapper")
	WebElement txtOutstandingAmt1;

	@FindBy(id = "text-component_ps-instal-amt-1_wrapper")
	WebElement txtInstalAmt1;

	@FindBy(id = "text-component_ps-card-member-since-1_wrapper")
	WebElement txtCardMemberSince1;

	@FindBy(id = "text-component_ps-bank-name-2_wrapper")
	WebElement txtBankName2;

	@FindBy(id = "text-component_ps-branch-2_wrapper")
	WebElement txtBranch2;

	@FindBy(id = "text-component_ps-type-account-2_wrapper")
	WebElement txtTypeAccount2;

	@FindBy(id = "text-component_ps-account-card-no-2_wrapper")
	WebElement txtAccountCardno2;

	@FindBy(id = "text-component_ps-credit-loan-2_wrapper")
	WebElement txtCreditLoan2;

	@FindBy(id = "text-component_ps-outstanding-amt-2_wrapper")
	WebElement txtOutstandingAmt2;

	@FindBy(id = "text-component_ps-instal-amt-2_wrapper")
	WebElement txtInstalAmt2;

	@FindBy(id = "text-component_ps-card-member-since-2_wrapper")
	WebElement txtCardMemberSince2;

	@FindBy(id = "text-component_ps-bank-name-3_wrapper")
	WebElement txtBankName3;

	@FindBy(id = "text-component_ps-branch-3_wrapper")
	WebElement txtBranch3;

	@FindBy(id = "text-component_ps-type-account-3_wrapper")
	WebElement txtTypeAccount3;

	@FindBy(id = "text-component_ps-account-card-no-3_wrapper")
	WebElement txtAccountCardno3;

	@FindBy(id = "text-component_ps-credit-loan-3_wrapper")
	WebElement txtCreditLoan3;

	@FindBy(id = "text-component_ps-outstanding-amt-3_wrapper")
	WebElement txtOutsSandingAmt3;

	@FindBy(id = "text-component_ps-instal-amt-3_wrapper")
	WebElement txtInstalAmt3;

	@FindBy(id = "text-component_ps-card-member-since-3_wrapper")
	WebElement txtCardMemberSince3;

	@FindBy(id = "select-component_ps-loan-related-client_wrapper")
	WebElement slctLoanRelatedcCient;

	@FindBy(id = "text-component_ps-account-no_wrapper")
	WebElement txtAccountNo;

	@FindBy(id = "text-component_ps-credit-card-embossed-name_wrapper")
	WebElement txtCreditcardEmbossedName;

	@FindBy(id = "select-component_ps-card-delivery-add-type_wrapper")
	WebElement slctCardDeliveryAddType;

	@FindBy(id = "select-component_ps-card-collection-branch_wrapper")
	WebElement slctCardCollectionBranch;

	@FindBy(id = "text-component_ps-loan-amount_wrapper")
	WebElement txtLoanAmount;

	@FindBy(id = "text-component_ps-term-months_wrapper")
	WebElement txtTermMonths;

	@FindBy(id = "select-component_ps-currency_wrapper")
	WebElement slctCurrency;

	@FindBy(id = "select-component_ps-preferred-branch_wrapper")
	WebElement slctPreferredBranch;

	@FindBy(id = "text-component_ps-loan-disb-account-no_wrapper")
	WebElement txtLoanDisbaAcountno;

	@FindBy(id = "text-component_ps-interest-rate-od-facility_wrapper")
	WebElement txtInterestrateodFacility;

	@FindBy(id = "select-component_ps-director-other-banks_wrapper")
	WebElement slctDirectorotherBanks;

	FFClientKeyInformationPage ffCKI = new FFClientKeyInformationPage();
	
	
	@FindBy(xpath = "//div[contains(@id,'_ps-') and input[@type='text']]")
	List<WebElement> textFields;
	@FindBy(xpath = "//div[contains(@id,'_ps-') and input[@type='date']]")
	List<WebElement> dateFeilds;

	@FindBy(xpath = "//div[.//input[@class='ui-autocomplete-input']][contains(@id,'_ps-')]")
	List<WebElement> dropdownFeilds;

	@FindBy(xpath = "//div[input[@type='checkbox']][contains(@id,'_ps-')]")
	List<WebElement> switchFeilds;

	@FindBy(xpath = "//div[.//input[@type='radio']][contains(@id,'_ps-')]")
	List<WebElement> radioFeilds;

	@FindBy(css = "body")
	WebElement body;

	@FindBy(id = "next-button")
	WebElement btnNext;

	By tagNameInput = By.tagName("input");

	By tagNameLabel = By.tagName("label");
	
	Set<String> webele = new HashSet<String>();
	Set<String> csvkeys  = new HashSet<String>();
	HashMap<String, ArrayList<String>> addMap;

	public FFCustomerDueDiligencePage formFillForProductSpecificSection(int count) throws Exception {
		
		getNeedDataFromCSVMap(count);
		fillTextfields();
		filldatefields();
		filldropdownFeilds();
		fillswitchFeilds();
		verificationOfRequiedElemetsPresentInPage(webele, csvkeys);
		body.click();
		waitForvisiblityOfGivenElement(btnNext);
		btnNext.click();

		return new FFCustomerDueDiligencePage();
	}

	public  void fillTextfields() throws Exception {
		webele = formFillEnterText(textFields, addMap, webele);
		
	}

	public void filldatefields() throws Exception {
		webele = formFillEnterText(dateFeilds, addMap, webele);
		
	}

	public void fillswitchFeilds() throws Exception {
		webele = formFillSwitchElementToClick(switchFeilds, addMap, webele);
	}

	public void fillradioFeilds() {
		for (WebElement element : radioFeilds) {
			// if(Map.field contains element.getAttribute("id");
			// element.sendKeys( the value of the map);
		}
	}

	public void filldropdownFeilds() throws Exception {
		webele = formFillSelectElementFromDropdown(dropdownFeilds, addMap, webele);
	}
	
	
	public void getNeedDataFromCSVMap(int requiredCol){
		addMap = new HashMap<>();
		for (String data : ReadTestData.ffPSMap.keySet()) {
			if(!ReadTestData.ffPSMap.get(data).get(requiredCol).equals("N")){
				addMap.put(data, ReadTestData.ffPSMap.get(data));
			}
		}
		
		for (String dat : addMap.keySet()) {
			csvkeys.add(dat);
		}
	}
	
	/**
	 * This Method Will Enter The Data For Customer Due Diligence Section
	 * 
	 * @return
	 */

	/*public FFCustomerDueDiligencePage enterProductSpecifiDetails() {

		formFillSelectElementFromDropdown(slctNoOfNominee,
				ReadTestData.ffData.getNoNominee());
		formFillEnterText(txtNomineeName1,
				ReadTestData.ffData.getNomName1());
		formFillEnterText(txtPercent1,
				ReadTestData.ffData.getPercent1());
		formFillEnterText(txtNomineeName2,
				ReadTestData.ffData.getNomName2());
		formFillEnterText(txtPercent2,
				ReadTestData.ffData.getPercent2());
		formFillEnterText(txtNomineeName3,
				ReadTestData.ffData.getNomName3());
		formFillEnterText(txtPercent3,
				ReadTestData.ffData.getPercent3());
		formFillEnterText(txtBankName1,
				ReadTestData.ffData.getBankName1());
		formFillEnterText(txtBranch1,
				ReadTestData.ffData.getBranch1());
		formFillEnterText(txtTypeAccount1,
				ReadTestData.ffData.getTypeAccount1());
		formFillEnterText(txtAccountCardno1,
				ReadTestData.ffData.getAccountCardno1());
		formFillEnterText(txtCreditLoan1,
				ReadTestData.ffData.getCreditLoan1());
		formFillEnterText(txtOutstandingAmt1,
				ReadTestData.ffData.getOutstandingAmt1());
		formFillEnterText(txtInstalAmt1,
				ReadTestData.ffData.getInstalamt1());
		formFillEnterText(txtCardMemberSince1,
				ReadTestData.ffData.getCardMemberSince1());

		formFillEnterText(txtBankName2,
				ReadTestData.ffData.getBankName2());
		formFillEnterText(txtBranch2,
				ReadTestData.ffData.getBranch2());
		formFillEnterText(txtTypeAccount2,
				ReadTestData.ffData.getTypeAccount2());
		formFillEnterText(txtAccountCardno2,
				ReadTestData.ffData.getAccountCardno2());
		formFillEnterText(txtCreditLoan2,
				ReadTestData.ffData.getCreditLoan2());
		formFillEnterText(txtOutstandingAmt2,
				ReadTestData.ffData.getOutstandingAmt2());
		formFillEnterText(txtInstalAmt2,
				ReadTestData.ffData.getInstalAmt2());
		formFillEnterText(txtCardMemberSince2,
				ReadTestData.ffData.getCardMemberSince2());

		formFillEnterText(txtBankName3,
				ReadTestData.ffData.getBankName3());
		formFillEnterText(txtBranch3,
				ReadTestData.ffData.getBranch3());
		formFillEnterText(txtTypeAccount3,
				ReadTestData.ffData.getTypeAccount3());
		formFillEnterText(txtAccountCardno3,
				ReadTestData.ffData.getAccountCardno3());
		formFillEnterText(txtCreditLoan3,
				ReadTestData.ffData.getCreditLoan3());
		formFillEnterText(txtOutsSandingAmt3,
				ReadTestData.ffData.getOutsSandingamt3());
		formFillEnterText(txtInstalAmt3,
				ReadTestData.ffData.getInstalAmt3());
		formFillEnterText(txtCardMemberSince3,
				ReadTestData.ffData.getCardMemberSince3());
		formFillSelectElementFromDropdown(
				slctLoanRelatedcCient,
				ReadTestData.ffData.getLoanRelatedcCient());
		System.out.println("********"+ReadTestData.ffData.getAccountNo());
		formFillEnterText(txtAccountNo,
				"56789021321");
		formFillEnterText(txtCreditcardEmbossedName,
				ReadTestData.ffData.getCreditcardEmbossedName());
		formFillSelectElementFromDropdown(
				slctCardDeliveryAddType,
				ReadTestData.ffData.getCardDeliveryAddType());
		formFillSelectElementFromDropdown(
				slctCardCollectionBranch,
				ReadTestData.ffData.getCardCollectionBranch());
		formFillEnterText(txtLoanAmount,
				ReadTestData.ffData.getLoanAmount());
		formFillEnterText(txtTermMonths,
				ReadTestData.ffData.getTermMonths());
		formFillSelectElementFromDropdown(slctCurrency,
				ReadTestData.ffData.getCurrency());
		formFillSelectElementFromDropdown(
				slctPreferredBranch,
				ReadTestData.ffData.getPreferredBranch());
		formFillEnterText(txtLoanDisbaAcountno,
				ReadTestData.ffData.getLoanDisbaAcountno());
		formFillEnterText(txtInterestrateodFacility,
				ReadTestData.ffData.getInterestrateodFacility());
		formFillSelectElementFromDropdown(
				slctDirectorotherBanks,
				ReadTestData.ffData.getDirectorotherBanks());

		ffCKI.body.click();
		waitForvisiblityOfGivenElement(ffCKI.btnNext);
		ffCKI.btnNext.click();
		return new FFCustomerDueDiligencePage();
	}*/
}
