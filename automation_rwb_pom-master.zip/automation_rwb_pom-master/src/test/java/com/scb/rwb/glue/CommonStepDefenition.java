package com.scb.rwb.glue;

import java.io.FileInputStream;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.scb.rwb.appium.pages.SetupPage;
import com.scb.rwb.testdata.LoginTestData;
import com.scb.rwb.utility.ReadTestData;
import com.scb.rwb.wrappers.ApplicationWrappers;
import com.scb.rwb.wrappers.GenericWrappers;

import cucumber.api.java.en.Given;

public class CommonStepDefenition extends ApplicationWrappers {

	public static String username1;
	public static String username2;
	public static String password;
	public static String countryName;
	public static String countryCode;
	public static String codingUsername;
	private int String;

	
	@Given("^I have valid RM credentials for \"(.*?)\"$")
	public void i_have_valid_RM_credentials_for(String country)
			throws Throwable {
			switch (country) {
			case "Pakistan":
				ReadTestData.loginTD=new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 0);
				break;
			case "Bangladesh":
					ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 1);
				break;
			case "HongKong":
					ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 2);
				break;
			case "Singapore":
					ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 3);				
				break;
			case "India":
					ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 4);
				break;
			case "Malaysia":
					ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 5);
				break;
			case "Nigeria":
					ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 6);
				break;
			case "Indonesia":
					ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 7);
				break;
			case "Kenya":
					ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 8);
				break;
			case "United Arab Emirates":
					ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 9);
				break;
			}

	}
	
	@Given("^I have valid RMtwo credentials for \"(.*?)\"$")
	public void I_have_valid_RMtwo_credentials_for(String country) throws Throwable{
		switch (country) {
		case "Pakistan":
			ReadTestData.loginTD=new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 0);
			break;
		case "Bangladesh":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 1);
			break;
		case "HongKong":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 2);
			break;
		case "Singapore":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 3);				
			break;
		case "India":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 4);
			break;
		case "Malaysia":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 5);
			break;
		case "Nigeria":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 6);
			break;
		case "Indonesia":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 7);
			break;
		case "Kenya":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 8);
			break;
		case "United Arab Emirates":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 9);
			break;
		}
	}
	
	@Given("^I have valid login credentials for \"(.*?)\" with coding rights$")
	public static void i_have_valid_login_credentials_for_with_coding_rights(
			String country) throws Throwable {
		switch (country) {
		case "Pakistan":
			ReadTestData.loginTD=new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 0);
			break;
		case "Bangladesh":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 1);
			break;
		case "HongKong":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 2);
			break;
		case "Singapore":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 3);				
			break;
		case "India":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 4);
			break;
		case "Malaysia":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 5);
			break;
		case "Nigeria":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 6);
			break;
		case "Indonesia":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 7);
			break;
		case "Kenya":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 8);
			break;
		case "United Arab Emirates":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 9);
			break;
		}
	}
	
	@Given("^I have invalid RM credentials for \"(.*?)\"$")
	public void i_have_invalid_RM_credentials_for(String country)
			throws Throwable {
		switch (country) {
		case "Pakistan":
			ReadTestData.loginTD=new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 0);
			break;
		case "Bangladesh":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 1);
			break;
		case "HongKong":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 2);
			break;
		case "Singapore":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 3);				
			break;
		case "India":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 4);
			break;
		case "Malaysia":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 5);
			break;
		case "Nigeria":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 6);
			break;
		case "Indonesia":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 7);
			break;
		case "Kenya":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 8);
			break;
		case "United Arab Emirates":
				ReadTestData.loginTD = new LoginTestData(ReadTestData.allData.get("loginTD.csv"), 9);
			break;
		}
	}
	
	@Given("^I am on the product offerings screen$")
	public void i_go_to_product_offerings_screen() throws Throwable {
		
		new SetupPage().enterRMRegistration().selectProductOfferingPage()
				.clickAddProductAndSwitchToWebview();
	}
}

