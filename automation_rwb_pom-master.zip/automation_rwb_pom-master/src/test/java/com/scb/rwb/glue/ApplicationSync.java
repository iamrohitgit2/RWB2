package com.scb.rwb.glue;

import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.scb.rwb.appium.pages.DashboardPage;
import com.scb.rwb.wrappers.ApplicationWrappers;

import io.appium.java_client.AppiumDriver;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ApplicationSync extends ApplicationWrappers{
	
	
	@When("^I navigate to Sync feature$")
	public void i_navigate_to_Sync_feature() throws Throwable {
		new DashboardPage().navigateToSyncFeature();
	}
	
	
	@Then("^The Application should be synced successfully$")
	public void application_should_be_synced_successfully() throws Throwable {
		new DashboardPage().verifyApplicationSyncedSuccessfully(); 		
	}
	
	@When("^I sync application$")
	public void i_sync_application_from_left_menu() throws Throwable {
		new DashboardPage().syncApplication();
	}
}
