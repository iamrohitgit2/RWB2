package com.scb.rwb.appium.pages;


public class FFCodingPage extends AppiumBasePage{


}
