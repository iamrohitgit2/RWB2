package com.scb.rwb.wrappers;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.scb.rwb.glue.Login;
//import io.appium.java_client.ios.IOSDriver;
import com.scb.rwb.utility.ReadTestData;

public class ApplicationWrappers extends GenericWrappers {
	
	public String cssValueOfStatusIcon=".status-icon-medium-";

	Logger logger = Logger.getRootLogger();

	/**
	 * This method will return the elementId of the given product
	 * 
	 * @param productName
	 * @return
	 */
	public String getId(String productName) {
		String countryCode = (ReadTestData.loginTD.getCountryCode())
				.toLowerCase();
		String elementId = countryCode + "-"
				+ (StringUtils.replace(productName, " ", "-")).toLowerCase();

		return elementId;
	}

	/**
	 * This method will use java script executor
	 */
	public void jsToClicAddCartButton() {

		JavascriptExecutor executor = (JavascriptExecutor) wd;
		executor.executeScript("document.getElementById('scroll-down').click()");
		sleep(500);
		executor.executeScript("document.getElementsByClassName('icon-cart')[0].click()");
		/*
		 * executor.executeScript("mobile: tap", new HashMap<String, Double>() {
		 * { put("tapCount", (double) 1); put("touchCount", (double) 1);
		 * put("duration", 0.5); put("x", (double) 955); put("y", (double) 728);
		 * } });
		 */

	}

	/*
	 * public static String get_product_id(String productName) { String
	 * countryCode = (Login.countryCode).toLowerCase(); String elementId =
	 * countryCode+"-"+(StringUtils.replace(productName, " ",
	 * "-")).toLowerCase();
	 * 
	 * return elementId; }
	 */

	/**
	 * This method will do a java script executer click on the given product
	 * 
	 * @param productID
	 */
	public void jsClickOnAddProduct(String productID) {
		((JavascriptExecutor) wd)
				.executeScript("(document.getElementsByClassName('"
						+ productID
						+ "')[0].getElementsByClassName('bottom'))[0].getElementsByTagName('button')[0].click()");
	}

	/**
	 * This Method Will Do A Java Script Executer Clicks On The Cart.
	 * 
	 * 
	 */
	public void jsClickCartTogle() {
		((JavascriptExecutor) wd)
				.executeScript("document.getElementsByClassName('cart-toggle')[0].click()");
	}

	/**
	 * This Method Will Do A Java Script Executer Click On The Cart For Product
	 * CheckOut
	 * 
	 * 
	 */
	public void jsClickProductCheckout() {
		((JavascriptExecutor) wd)
				.executeScript("document.getElementById('product-checkout').click()");
	}

	/**
	 * This Method Will Do A Java Script Executer Click For Terms And
	 * Conditions.
	 * 
	 * 
	 */
	public void jsClickTermsAndCondition() {
		((JavascriptExecutor) wd)
				.executeScript("document.getElementsByClassName('terms-and-conditions-menu---button-accept')[0].click()");
	}

	/**
	 * This method will first take the id attribute from the given list of web
	 * elements and match it with the given testdata map and then pass the value
	 * to the element
	 * 
	 * @param textFields
	 * @param ffMap
	 * @param webele
	 * @return
	 */
	public Set<String> formFillEnterText(List<WebElement> textFields,
			HashMap<String, ArrayList<String>> ffMap, Set<String> webele) {
		sleep(5000);
		for (WebElement element : textFields) {
			String id = element.getAttribute("id");
			System.out.println(id);
			if (ffMap.containsKey(id)) {
//				System.out.println("Req: "+ffMap.get(id).get(2));
				if (!ffMap.get(id).get(1).equalsIgnoreCase("")) {
						// System.out.println(element.findElement(By.xpath("input")));
						waitForvisiblityOfGivenElement(element.findElement(By
								.xpath("input")));
						element.findElement(By.xpath("input")).sendKeys(
								ffMap.get(id).get(1));
						// System.out.println(ffMap.get(id).get(1));
						webele.add(id);
				}
			}
		}
		return webele;
	}

	public Set<String> formFillSelectElementFromDropdown(
			List<WebElement> dropDown,
			HashMap<String, ArrayList<String>> ffMap, Set<String> webele) {
		sleep(7000);
		for (WebElement element : dropDown) {
			String id = element.getAttribute("id");
			System.out.println(id);
			if (ffMap.containsKey(id)) {
//				System.out.println("Req: "+ffMap.get(id).get(2));
				if (!ffMap.get(id).get(1).equals("")) {
					element.findElement(By.tagName("input")).clear();
					element.findElement(By.tagName("input")).click();
					List<WebElement> eles = element.findElements(By
							.tagName("a"));
					for (WebElement webElement : eles) {
						// System.out.println(webElement);
						// System.out
						// .println("The data : " + webElement.getText());
						if (webElement.getText().equals(ffMap.get(id).get(1))) {
							System.out.println("The data : "
									+ webElement.getText());
							webElement.click();
							break;
						}
					}

					// System.out.println(ffMap.get(id).get(1));
					webele.add(id);
				}
			}
		}
		return webele;

	}

	public Set<String> formFillSwitchElementToClick(List<WebElement> dropDown,
			HashMap<String, ArrayList<String>> ffMap, Set<String> webele) {
		sleep(3000);
		for (WebElement element : dropDown) {
			String id = element.getAttribute("id");
			System.out.println(id);
			if (ffMap.containsKey(id)) {
//				System.out.println("Req: "+ffMap.get(id).get(2));
				if (!ffMap.get(id).get(1).equals("")) {
					if (ffMap.get(id).get(1).contains("Yes")) {
						sleep(500);
						element.findElement(By.tagName("label")).click();
					}
					webele.add(id);
				}
				// System.out.println(ffMap.get(id).get(1));
				
			}
		}
		return webele;

	}

	public void verificationOfRequiedElemetsPresentInPage(Set<String> webele,
			Set<String> csvkeys) throws Exception {
		if (!webele.containsAll(csvkeys)) {
			for (String string : csvkeys) {
				if (webele.add(string)) {
					System.out
							.println("The locator not present on the applciation");
					throw new Exception("The locator :" + string
							+ " not present on the applciation");
				}
			}
		}
	}
	
	public void jsClickThePassButtonInQualityCheck()
	{
		((JavascriptExecutor) driver)
		.executeScript("document.getElementsByClassName('document-quality')[0].children[1].click()");
	}
	
	public void jsCloseButtonofApplicationMasterView()
	{
		((JavascriptExecutor) driver).executeScript("document.getElementsByClassName('modal---close-button')[0].click()");
	}
	
	
	public void verifyApplicationStatusInCodingStation(String applicationStatus)
	{
		String statusId = cssValueOfStatusIcon+ applicationStatus;
		statusId = StringUtils.replace(statusId, " ", "-").toLowerCase();
		boolean Application_present = false;

		List<WebElement> elements = driver.findElements(By
				.cssSelector(".search-result-table-row"));
		Iterator<WebElement> itr1 = elements.iterator();
		itr1.next();

		while (itr1.hasNext()) {
			WebElement Approw = itr1.next();
			String AppID = Approw.findElement(
					By.cssSelector(".search-app-number a")).getText();
			Wait<WebDriver> fwait = new FluentWait<WebDriver>(driver)
					.withTimeout(50, TimeUnit.SECONDS).pollingEvery(1,
							TimeUnit.SECONDS);
			System.out.println("Application Id present in the browser ="
					+ AppID);
			
//			String appNo = (String) conf.getProperty("appRefrenceNumber");
			if (AppID.equalsIgnoreCase(getDataFromPropertiesFile(path,"appRefrenceNumber"))) {
				Application_present = true;
				Approw.findElement(By.cssSelector(statusId));
				break;
			}

		}

		if (!Application_present) {
			throw new RuntimeException(getDataFromPropertiesFile(path, "appRefrenceNumber")
					+ " Application not present ");
		}
			
	}
	
	public String getComponentId(String sectioncode, String componentType,
			String componentname) {
		String componentId = componentType + "-component_" + sectioncode + "-"
				+ componentname + "_wrapper";
		componentId = StringUtils.replace(componentId, " ", "-").toLowerCase();
		return (componentId);
	}
	
	public void fill_in_radio_component(String componentId, String value) {

		String radio_option = value;

		List<WebElement> elements = driver.findElement(By.id(componentId))
				.findElements(By.tagName("label"));

		for (WebElement element : elements) {
			System.out.println(element.getText());
			if (radio_option.equalsIgnoreCase(element.getText())) {
				element.click();
			}

		}
	}

	public void fill_in_switch_component(String componentId, String value) {
		String Option = value;
		if (Option.equalsIgnoreCase("Yes")) {
			WebElement a = driver.findElement(By.id(componentId)).findElement(
					By.tagName("label"));
			a.click();
		}

	}

	public void fill_in_text_component(String componentId, String value) {

		WebElement a = driver.findElement(By.id(componentId)).findElement(
				By.tagName("input"));
		a.sendKeys(value);
		if (componentId.contains("date")) {
			System.out
					.println(("document.getElementById('" + componentId
							+ "').getElementsByTagName('input')[0].value='"
							+ value + "'"));
			((JavascriptExecutor) driver)
					.executeScript("document.getElementById('" + componentId
							+ "').getElementsByTagName('input')[0].value='"
							+ value + "'");
		}

	}

	public void fill_in_textarea_component(String componentId, String value) {
		WebElement a = driver.findElement(By.id(componentId)).findElement(
				By.tagName("textarea"));
		a.sendKeys(value);

	}

	public void fill_in_select_component(String componentId, String value)
			throws InterruptedException, AWTException {

		WebElement a = driver.findElement(By.id(componentId)).findElement(
				By.tagName("input"));
		a.clear();
		a.click();
		a.sendKeys(value);
		Thread.sleep(1000);
		// Robot robot = new Robot();

	}
	
	/**
	 * This method will do a java script executer click on the Application number from the search result
	 * 
	 */
	
	public void jsClickTheApplicationFromTheSearchResult()
	{
		((JavascriptExecutor) driver)
		.executeScript("document.getElementsByClassName('search-app-number')[0].getElementsByTagName('a')[0].click()");

	}


}
