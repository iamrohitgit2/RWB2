package com.scb.rwb.glue;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.RollingFileAppender;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.scb.rwb.baserunner.RunGenieTest;
import com.scb.rwb.utility.ReadTestData;
import com.scb.rwb.wrappers.ApplicationWrappers;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

public class Login extends ApplicationWrappers {

	public static String Username1;
	public static String Username2;
	public static String password;
	public static String Countryname;
	public static String countryCode;
	public static String CodingUsername;
	private int String;

	Logger logger = Logger.getRootLogger();

	@Before()
	public void setlogpath(Scenario scenario) throws MalformedURLException {
//		launchBrowser("Chrome");
		setLogpathForGenei(scenario);
		ReadTestData.readTestData();
		ReadTestData.getFormFillDataFromCsvFile("formfillTD_2.csv");
		System.out.println();

	}

	@Before("@appium")
	public void startServer() throws MalformedURLException {
		startAppiumServer();
	}

	@After("@appium")
	public void afterBrowser(Scenario scenario) throws InterruptedException,
			IOException {
		captureScreenShotAndAddToGeneiReport(scenario);
		wd.closeApp();
		wd.quit();

	}

	
//	@After()
//	public void endResult(Scenario scenario) {
//		try {
//			browsercaptureScreenShotAndAddToGeneiReport(scenario);
//			driver.quit();
			
			

//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}
//	@After()
	public static void endResult() {
		try {
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	
}
