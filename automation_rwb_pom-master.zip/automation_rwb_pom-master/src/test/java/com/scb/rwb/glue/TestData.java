package com.scb.rwb.glue;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import javax.management.Query;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.FluentWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

public class TestData{
//	public static String counTry;
//	public static String countryCode;
//	public static String userName;
//	public static String passWord;
	public static String baseUrl="https://rcwbsit.sc.com/#/?";
	public static String applicationId ;
	public static String TestDataPath;
	public static boolean configure_ScreenshotPath= true;
	public static boolean configureApplicationSubmittedFromCodingPath =true;
	public static boolean configureApplicationReturnedFromCodingPath =true;
	public static boolean configureApplicationRejectedfromCodingPath1 = true;
	public static boolean ConfigureApplicationForCodingPath=true;
	public static String ScreenshotPath;
	public static String FilelogPath;
	public static String logbasePath= "/target/log/files/";
	public static String TimeStamp;
	public static String ScenarioName;
	public static boolean configureApplicationRejectedfromCodingPath;
	
	
	
/*	@Given("^I have valid RM credentials for \"(.*?)\"$")
	public void i_have_valid_RM_credentials_for(String country) throws Throwable {
//		String dataSheetpath=TestData.TestDataPath;
//		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);	
//		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
//	    XSSFSheet sheets = workbooks.getSheet("UserIDs");
//	    switch (country) 
//		{
//		
//		case "Pakistan" :
//			System.out.println("Pakistan country");
//			if(country.equalsIgnoreCase("Pakistan"))
//			{
//			XSSFRow row= sheets.getRow(1);
//			int userName =  (int) row.getCell(1).getNumericCellValue();
//	       String passWord =row.getCell(2).getStringCellValue();
//	       String countryType =row.getCell(3).getStringCellValue();
//	       
//			}
//			break;
//		}
//	}
	    
		if (country.equalsIgnoreCase("HongKong"))
		{
			
		TestData.userName= "1100002";
		TestData.passWord= "Pass1234";
		TestData.counTry= "HongKong";
		TestData.countryCode= "HK";
			
		}
		
		if (country.equalsIgnoreCase("Singapore"))
		{
		TestData.userName= "1100078";
		TestData.passWord= "Pass1234";
		TestData.counTry= "Singapore";
		TestData.countryCode= "SG";
		}
		if (country.equalsIgnoreCase("India"))
		{
		TestData.userName= "1100011";
		TestData.passWord= "Pass1234";
		TestData.counTry= "India";
		TestData.countryCode= "IN";
		}
		if (country.equalsIgnoreCase("Malaysia"))
		{
		TestData.userName= "1100003";
		TestData.passWord= "Pass1234";
		TestData.counTry= "Malaysia";
		TestData.countryCode= "MY";
		}
		if (country.equalsIgnoreCase("Nigeria"))
		{
		TestData.userName= "1100005";
		TestData.passWord= "Pass1234";
		TestData.counTry= "Nigeria";
		}
		if (country.equalsIgnoreCase("Pakistan"))
		{
		TestData.userName= "1100006";
		TestData.passWord= "Pass1234";
		TestData.counTry= "Pakistan";
		TestData.countryCode= "PK";
		}
		if (country.equalsIgnoreCase("Indonesia"))
		{
		TestData.userName= "1100017";
		TestData.passWord= "Pass1234";
		TestData.counTry= "Indonesia";
		TestData.countryCode= "ID";
		}
		if (country.equalsIgnoreCase("Kenya"))
		{
		TestData.userName= "1100010";
		TestData.passWord= "Pass1234";
		TestData.counTry= "Kenya";
		TestData.countryCode= "KE";
		}
		if (country.equalsIgnoreCase("United Arab Emirates"))
		{
		TestData.userName= "1100015";
		TestData.passWord= "Pass1234";
		TestData.counTry= "United Arab Emirates";
		TestData.countryCode= "AE";
		}
		if (country.equalsIgnoreCase("Bangladesh"))
		{
		TestData.userName= "1174909";
		TestData.passWord= "Pass1234";
		TestData.counTry= "Bangladesh";
		TestData.countryCode= "BD";
		}
	}

	@Given("^I have valid login credentials for \"(.*?)\" with coding rights$")
	public static void i_have_valid_login_credentials_for_with_coding_rights(String country) throws Throwable {
		if (country.equalsIgnoreCase("HongKong"))
		{
		TestData.userName= "1402685";
		TestData.passWord= "12341234";
		TestData.counTry= "HongKong";
		TestData.countryCode= "HK";
		}
		
		if (country.equalsIgnoreCase("Singapore"))
		{
		TestData.userName= "1105002";
		TestData.passWord= "12341234";
		TestData.counTry= "Singapore";
		TestData.countryCode= "SG";
		}
		if (country.equalsIgnoreCase("India"))
		{
		TestData.userName= "1100011";
		TestData.passWord= "12341234";
		TestData.counTry= "India";
		TestData.countryCode= "IN";
		}
		if (country.equalsIgnoreCase("Malaysia"))
		{
		TestData.userName= "1200002";
		TestData.passWord= "12341234";
		TestData.counTry= "Malaysia";
		TestData.countryCode= "MY";
		}
		if (country.equalsIgnoreCase("Nigeria"))
		{
		TestData.userName= "1453598";
		TestData.passWord= "12341234";
		TestData.counTry= "Nigeria";
		TestData.countryCode= "NG";
		}
		if (country.equalsIgnoreCase("Pakistan"))
		{
		TestData.userName= "1453598";
		TestData.passWord= "12341234";
		TestData.counTry= "Pakistan";
		TestData.countryCode= "PK";
		}
		if (country.equalsIgnoreCase("Indonesia"))
		{
		TestData.userName= "1100017";
		TestData.passWord= "Pass1234";
		TestData.counTry= "Indonesia";
		TestData.countryCode= "ID";
		}
		if (country.equalsIgnoreCase("Kenya"))
		{
		TestData.userName= "1100010";
		TestData.passWord= "Pass1234";
		TestData.counTry= "Kenya";
		TestData.countryCode= "KE";
		}
		if (country.equalsIgnoreCase("United Arab Emirates"))
		{
		TestData.userName= "1100015";
		TestData.passWord= "Pass1234";
		TestData.counTry= "United Arab Emirates";
		TestData.countryCode= "AE";
		}
		if (country.equalsIgnoreCase("Bangladesh"))
		{
		TestData.userName= "1174909";
		TestData.passWord= "Pass1234";
		TestData.counTry= "Bangladesh";
		TestData.countryCode= "BD";
		}
		
	}
	
*/	

	@Given("^I have valid application number with credit card, Personal loan and Savings account in coding queue$")
	public void i_have_valid_application_number_with_credit_card_Personal_loan_and_Savings_account_in_coding_queue() throws Throwable {
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Savings-and-Card-and-Loan.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("Applicationforcoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	}
	
	@Given("^I have valid application number with credit card and Savings account product in coding queue$")
	public void i_have_valid_application_number_with_credit_card__and_Savings_account_in_coding_queue() throws Throwable {
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Savings-and-Card.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("Applicationforcoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	}
	
	// Adding for CA SA CC & PL Products && SA+CC+PL && CC+PL
	
	@Given("^I have valid application number with credit card, Personal loan and Current account in coding queue$")
	public void i_have_valid_application_number_with_credit_card_Personal_loan_and_Current_account_in_coding_queue() throws Throwable {
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Current-and-Card-and-Loan.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("Applicationforcoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	
	}
	
	@Given("^I have valid application number with credit card and Personal loan in coding queue$")
	public void i_have_valid_application_number_with_credit_card_and_Personal_loan_in_coding_queue() throws Throwable {
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Card-and-Loan.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("Applicationforcoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	
	}
	
	@Given("^I have valid application number with credit card, Personal loan and Savings account submitted from coding queue$")
	public void i_have_valid_application_number_with_credit_card_Personal_loan_and_Savings_account_submitted_from_coding_queue() throws Throwable 
	{
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Savings-and-Card-and-Loan.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("AppSubmittedFromCoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	}
	
	@Given("^I have valid application number with credit card, Personal loan and Savings account returned from coding queue$")
	public void i_have_valid_application_number_with_credit_card_Personal_loan_and_Savings_account_returned_from_coding_queue() throws Throwable 
	{
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Savings-and-Card-and-Loan.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("AppReturnedFromCoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	}
	
	@Given("^I have valid application number with credit card and Personal loan returned from coding queue$")
	public void i_have_valid_application_number_with_credit_card_and_Personal_loan_returned_from_coding_queue() throws Throwable 
	{
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Card-and-Loan.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("AppReturnedFromCoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	}
	
	@Given("^I have valid application number with credit card and Savings account returned from coding queue$")
	public void i_have_valid_application_number_with_credit_card_and_Savings_account_returned_from_coding_queue() throws Throwable 
	{
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Savings-and-Card.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("AppReturnedFromCoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	}

	/**MODULE: Ipad  [RELEASE-2]
	  ** Inserting the submitted application from ipad in excel sheet for 3 products-HK market (CA+SA+CC)
	 */	
		
	@Given("^I have valid application number with credit card, Current and Savings account in coding queue$")
	public void i_have_valid_application_number_with_credit_card_Current_and_Savings_account_in_coding_queue() throws Throwable {
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Current-and-Card-and-Savings.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("Applicationforcoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	}
	
	/**MODULE: Ipad  [RELEASE-2]
	  ** Inserting the submitted application from ipad in excel sheet for 2 products-HK market (CA+CC)
	 */	
		
	@Given("^I have valid application number with credit card and Current account in coding queue$")
	public void i_have_valid_application_number_with_credit_card_and_Current_account_in_coding_queue() throws Throwable {
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Current-and-Card.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("Applicationforcoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	}
  
	/**MODULE: Ipad  [RELEASE-2]
	  ** Inserting the returned application from coding in excel sheet for 3 products-HK market (CA+SA+CC)
	 */	

	@Given("^I have valid application number with credit card, Current and Savings account returned from coding queue$")
	public void i_have_valid_application_number_with_credit_card_and_Current_Savings_account_returned_from_coding_queue() throws Throwable 
	{
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Current-and-Card-and-Savings.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("AppReturnedFromCoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	}
	/**MODULE: Ipad  [RELEASE-2]
	  ** Inserting the returned application from coding in excel sheet for 2 products-HK market (CA+CC)
	 */	

	@Given("^I have valid application number with credit card and Current account returned from coding queue$")
	public void i_have_valid_application_number_with_credit_card_and_Current_account_returned_from_coding_queue() throws Throwable 
	{
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//Current-and-Card.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("AppReturnedFromCoding");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	}
	
	/**MODULE: App Enquiry  [RELEASE-2]
	  ** Searching the processed application
	 */	
	
	
	@Given("^I have valid application id which is processed in ODS for rwb customer$")
	public void i_have_valid_application_id_which_is_processed_in_ODS_for_rwb_customer() throws Throwable {
		TestData.TestDataPath= "features//"+Login.countryCode+"-features//TestData//AppEnquiry.xlsx";
		
		FileInputStream fis = new FileInputStream(TestData.TestDataPath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("AppIdforRWBcustomer");
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = row.getCell(0);
		TestData.applicationId=cell.getStringCellValue();
		System.out.println("Application from Excel sheet "+ TestData.applicationId);
	
	}
}


