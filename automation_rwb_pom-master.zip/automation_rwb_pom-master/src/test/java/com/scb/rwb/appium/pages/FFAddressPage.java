package com.scb.rwb.appium.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.utility.ReadTestData;

public class FFAddressPage extends AppiumBasePage {


	/*@FindBy(id = "text-component_a-res-address-line-1_wrapper")
	WebElement txtResAddressLine1;

	@FindBy(id = "text-component_a-res-address-line-2_wrapper")
	WebElement txtResAddressLine2;

	@FindBy(id = "text-component_a-res-address-line-3_wrapper")
	WebElement txtResAddressLine3;

	@FindBy(id = "text-component_a-res-address-line-4_wrapper")
	WebElement txtResAddressLine4;

	@FindBy(id = "text-component_a-res-postal-code_wrapper")
	WebElement txtResPostalCode;

	@FindBy(id = "text-component_a-res-city_wrapper")
	WebElement txtResCity;

	@FindBy(id = "select-component_a-res-country_wrapper")
	WebElement slctResCountry;

	@FindBy(id = "select-component_a-residence-type_wrapper")
	WebElement slctResidenceType;

	@FindBy(id = "text-component_a-rent-per-annum-_wrapper")
	WebElement txtRentPerAnnum;

	@FindBy(id = "text-component_a-time-at-address-yrs_wrapper")
	WebElement txtTimeAtAddressYrs;

	@FindBy(id = "switch-component_a-per-same-as-residential-address_wrapper")
	WebElement swchPerSameAsResidentialAddress;

	@FindBy(id = "text-component_a-per-address-line-1_wrapper")
	WebElement txtPerAddressLine1;

	@FindBy(id = "text-component_a-per-address-line-2_wrapper")
	WebElement txtPerAddressLine2;

	@FindBy(id = "text-component_a-per-address-line-3_wrapper")
	WebElement txtPerAddressLine3;

	@FindBy(id = "text-component_a-per-address-line-4_wrapper")
	WebElement txtPerAddressLine4;

	@FindBy(id = "text-component_a-per-postal-code_wrapper")
	WebElement txtPerPostalCode;

	@FindBy(id = "text-component_a-per-city_wrapper")
	WebElement txtPerCity;

	@FindBy(id = "select-component_a-per-country_wrapper")
	WebElement slctPerCountry;

	@FindBy(id = "text-component_a-off-address-line-1_wrapper")
	WebElement txtOffAddressLine1;

	@FindBy(id = "text-component_a-off-address-line-2_wrapper")
	WebElement txtOffAddressLine2;

	@FindBy(id = "text-component_a-off-address-line-3_wrapper")
	WebElement txtOffAddressLine3;

	@FindBy(id = "text-component_a-off-address-line-4_wrapper")
	WebElement txtOffAddressLine4;

	@FindBy(id = "text-component_a-off-postal-code_wrapper")
	WebElement txtOffPostalCode;

	@FindBy(id = "text-component_a-off-city_wrapper")
	WebElement txtOffCity;

	@FindBy(id = "select-component_a-off-country_wrapper")
	WebElement slctOffCountry;

	@FindBy(id = "select-component_a-mailing-address_wrapper")
	WebElement slctMailingAddress;

	@FindBy(id = "text-component_a-oth-address-line-1_wrapper")
	WebElement txtOthAddressLine1;

	@FindBy(id = "text-component_a-oth-address-line-2_wrapper")
	WebElement txtOthAddressLine2;

	@FindBy(id = "text-component_a-oth-address-line-3_wrapper")
	WebElement txtOthAddressLine3;

	@FindBy(id = "text-component_a-oth-address-line-4_wrapper")
	WebElement txtOthAddressLine4;

	@FindBy(id = "text-component_a-oth-postal-code_wrapper")
	WebElement txtOthPostalCode;

	@FindBy(id = "text-component_a-oth-city_wrapper")
	WebElement txtOthCity;

	@FindBy(id = "select-component_a-oth-country_wrapper")
	WebElement slctOthCountry;

	@FindBy(id = "text-component_a-proof-address-doc_wrapper")
	WebElement txtProofAddressDoc;*/

	FFClientKeyInformationPage ffCKI = new FFClientKeyInformationPage();

	
	@FindBy(xpath = "//div[contains(@id,'_a-') and input[@type='text']]")
	List<WebElement> textFields;
	@FindBy(xpath = "//div[contains(@id,'_a-') and input[@type='date']]")
	List<WebElement> dateFeilds;

	@FindBy(xpath = "//div[.//input[@class='ui-autocomplete-input']][contains(@id,'_a-')]")
	List<WebElement> dropdownFeilds;

	@FindBy(xpath = "//div[input[@type='checkbox']][contains(@id,'_a-')]")
	List<WebElement> switchFeilds;

	@FindBy(xpath = "//div[.//input[@type='radio']][contains(@id,'_a-')]")
	List<WebElement> radioFeilds;

	@FindBy(css = "body")
	WebElement body;

	@FindBy(id = "next-button")
	WebElement btnNext;

	By tagNameInput = By.tagName("input");

	By tagNameLabel = By.tagName("label");
	
	Set<String> webele = new HashSet<String>();
	Set<String> csvkeys  = new HashSet<String>();
	HashMap<String, ArrayList<String>> addMap;
	public FFContactPage formFillForAddressSection(int count) throws Exception {
		
		getNeedDataFromCSVMap(count);
		fillTextfields();
		filldatefields();
		filldropdownFeilds();
		fillswitchFeilds();
		verificationOfRequiedElemetsPresentInPage(webele, csvkeys);
		body.click();
		waitForvisiblityOfGivenElement(btnNext);
		btnNext.click();
		
		return new FFContactPage();

	}

	public  void fillTextfields() throws Exception {
		
		webele = formFillEnterText(textFields, addMap, webele);
		
	}

	public void filldatefields() throws Exception {
		webele = formFillEnterText(dateFeilds, addMap, webele);
		
	}

	public void fillswitchFeilds() throws Exception {
		webele = formFillSwitchElementToClick(switchFeilds, addMap, webele);
	}

	public void fillradioFeilds() {
		for (WebElement element : radioFeilds) {
			// if(Map.field contains element.getAttribute("id");
			// element.sendKeys( the value of the map);
		}
	}

	public void filldropdownFeilds() throws Exception {
		webele = formFillSelectElementFromDropdown(dropdownFeilds, addMap, webele);
	}
	
	public void getNeedDataFromCSVMap(int requiredCol){
		addMap = new HashMap<>();
		for (String data : ReadTestData.ffAMap.keySet()) {
			if(!ReadTestData.ffAMap.get(data).get(requiredCol).equals("N")){
				addMap.put(data, ReadTestData.ffAMap.get(data));
			}
		}
		
		for (String dat : addMap.keySet()) {
			csvkeys.add(dat);
		}
	}
	
	/**
	 * This Method Will Enter The Data For Address Fields
	 * 
	 * @return
	 */
	/*public FFContactPage enterAddressFields() {
		sleep(2000);
		waitForvisiblityOfGivenElement(txtResAddressLine1
				);
		formFillEnterText(txtResAddressLine1,
				ReadTestData.ffData.getResAddressLine1());
		formFillEnterText(txtResAddressLine2,
				ReadTestData.ffData.getResAddressLine2());
		formFillEnterText(txtResAddressLine3,
				ReadTestData.ffData.getResAddressLine3());
		formFillEnterText(txtResAddressLine4,
				ReadTestData.ffData.getResAddressLine4());
		formFillSelectElementFromDropdown(
				txtResPostalCode,
				ReadTestData.ffData.getResPostalCode());
		formFillEnterText(txtResCity,
				ReadTestData.ffData.getResCity());
		formFillSelectElementFromDropdown(
				slctResCountry,
				ReadTestData.ffData.getResCountry());
		formFillSelectElementFromDropdown(
				slctResidenceType,
				ReadTestData.ffData.getResidenceType());
		formFillEnterText(txtRentPerAnnum,
				ReadTestData.ffData.getRentPerAnnum());
		formFillEnterText(txtTimeAtAddressYrs,
				ReadTestData.ffData.getTimeAtAddressYrs());

		if (ReadTestData.ffData.getPerSameAsResidentialAddress()
				.equalsIgnoreCase("Yes")) {
			formFillSwitchElementToClick(
					swchPerSameAsResidentialAddress
							.findElement(ffCKI.tagNameLabel),
					ReadTestData.ffData.getPerSameAsResidentialAddress());
		}

		formFillEnterText(txtPerAddressLine1,
				ReadTestData.ffData.getPerAddressLine1());
		formFillEnterText(txtPerAddressLine2,
				ReadTestData.ffData.getPerAddressLine2());
		formFillEnterText(txtPerAddressLine3,
				ReadTestData.ffData.getPerAddressLine3());
		formFillEnterText(txtPerAddressLine4,
				ReadTestData.ffData.getPerAddressLine4());
		formFillEnterText(txtPerPostalCode,
				ReadTestData.ffData.getPerPostalCode());
		formFillEnterText(txtPerCity,
				ReadTestData.ffData.getPerCity());
		formFillSelectElementFromDropdown(
				slctPerCountry,
				ReadTestData.ffData.getPerCountry());
		formFillEnterText(txtOffAddressLine1,
				ReadTestData.ffData.getOffAddressLine1());
		formFillEnterText(txtOffAddressLine2,
				ReadTestData.ffData.getOffAddressLine2());
		formFillEnterText(txtOffAddressLine3,
				ReadTestData.ffData.getOffAddressLine3());
		formFillEnterText(txtOffAddressLine4,
				ReadTestData.ffData.getOffAddressLine4());
		formFillEnterText(txtOffPostalCode,
				ReadTestData.ffData.getOffPostalCode());
		formFillEnterText(txtOffCity,
				ReadTestData.ffData.getOffCity());
		formFillSelectElementFromDropdown(
				slctOffCountry,
				ReadTestData.ffData.getOffCountry());
		formFillSelectElementFromDropdown(
				slctMailingAddress,
				ReadTestData.ffData.getMailingAddress());
		formFillEnterText(txtProofAddressDoc,
				ReadTestData.ffData.getProofAddressDoc());
		ffCKI.body.click();
		sleep(3000);
		ffCKI.btnNext.click();
		return new FFContactPage();
	}*/
}
