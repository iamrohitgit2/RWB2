package com.scb.rwb.glue;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.standardchartered.genie.FrameworkGlue;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

//public class Bau {
	

	//WebDriver driver =Coding.driver;
	
//	
//	private HashMap<String, String> fieldset;
//	public HashMap<String, String> sectionCode;
//	public HashMap<String, String> sectionId;
	
	
	//WebDriverWait wait = new WebDriverWait(driver, 30);

 

//	@When("^I click on \"(.*?)\" tab$")
//	public void i_click_on_tab(String docVeri) throws Throwable {
//	driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
//		List<WebElement> Tabs1 = driver.findElements(By.cssSelector("button.view-document"));
//		for ( WebElement Tab2 : Tabs1 ) {
//			System.out.println(Tab2.getText());
//			Thread.sleep(2000);
//			if ((docVeri).equalsIgnoreCase(Tab2.getText()))
//			{
//				Thread.sleep(2000);
//				Tab2.click();
//				System.out.println("clicked on document verification button");
//			}
//		}
////
////	
////	}
//	
//	
//	
//
//	@Then("^I should see side by side view of application form and supporting document$")
//	public void i_should_see_side_by_side_view_of_application_form_and_supporting_document() throws Throwable {
//		Thread.sleep(5000);		
//   boolean sideBySideView= driver.findElement(By.xpath("//h2[contains(text(),'Supporting Document')]")).isDisplayed();
//   Assert.assertEquals(true, sideBySideView);
//   System.out.println("side by side view of application and supporting document");
//
//	}
//
//	@When("^I click on supporting document search tab and check for supporting document list$")
//	public void i_click_on_supporting_document_search_tab_and_check_for_supporting_document_list() throws Throwable {
// 
//		Thread.sleep(5000);
//		driver.findElement(By.xpath("//input[@placeholder='Additional Proof One']")).click();
//		System.out.println("clicked on search tab");
//		List<WebElement> supDocList  = driver.findElements(By.cssSelector("li.ui-menu-item"));
//		int doc = supDocList.size();
//		System.out.println("total no. of documents is "+doc);
//		Iterator<WebElement> itr1 = supDocList.iterator();
//		
//		//ul[@class='ui-autocomplete ui-front ui-menu ui-widget ui-widget-content']
//		
//		//span[@class='ember-view ui-combobox']
//		
//		while(itr1.hasNext()) 
//		{
//			Thread.sleep(5000);
//			String availabledocs= itr1.next().findElement(By.tagName("a")).getText();
//	        System.out.println("Available docs  -"+availabledocs);
//	        
//		
//		}
//	}
//
//	
//	
//	@Then("^I should verify that documents added by the coding user are appearing in the support document search list$")
//	public void i_should_verify_that_documents_added_by_the_coding_user_are_appearing_in_the_support_document_search_list() throws Throwable {
//	     
//		Thread.sleep(5000);
//		String dataSheetpath = TestData.TestDataPath;
//		boolean Documet_present = false;
//		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
//		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
//		
//		XSSFSheet sheets = workbooks.getSheet("Document Checklist");
//		int noofRows= sheets.getLastRowNum();
//		for(int i=0;i<=noofRows ;i++)
//		{
//			XSSFRow row = sheets.getRow(i);
//			if ((row.getCell(0).getStringCellValue().equalsIgnoreCase("Additional supporting document")) && (row.getCell(1).getStringCellValue().equalsIgnoreCase("Mandatory")))
//				
//				{
//				String doc_required=  row.getCell(2).getStringCellValue();
//				System.out.println("documentTocheck from excel '" + doc_required );
//				Documet_present = false;
//				List<WebElement> addi = driver.findElements(By.cssSelector("li.ui-menu-item"));
//   		       Iterator<WebElement> ab= addi.iterator();
//   		       while(ab.hasNext()) 
//		         {
//			       String docvalue = ab.next().findElement(By.tagName("a")).getText();
//			       System.out.println(docvalue);
//		             if (docvalue.equalsIgnoreCase(doc_required))
//			              {
//			        	    System.out.println("document added by the coding user is  " + doc_required );
//			        	    Documet_present=true;
//			        	    break;
//			    	       }
//			      }
//     	          if (!Documet_present)
//	   			         {
//     	        	   throw new RuntimeException(" documents is not found in search list - " +doc_required);
//	   			         }
//				}
//			
//	}
//		
//	    
//	}
//	
//
//	 
//	
//	@When("^I click on X icon on the top$")
//	public void i_click_on_X_icon_on_the_top() throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//	//    throw new PendingException();
//		
//	Thread.sleep(5000);
//	driver.findElement(By.xpath("//input[@placeholder='Additional Proof One']")).click();
//	System.out.println("second time clicked on search tab");
//	Thread.sleep(5000);
//	driver.findElement(By.xpath("//div[@class='ember-view modal modal-document-verification scroll-closable modal-base modal_is-open modal_translucent modal_none modal_has-animation modal_scale-in modal_scale-out']/button[@id='modal-close']")).click();
//	 System.out.println("clicked on close tab");
//	}
//	
//
//}
