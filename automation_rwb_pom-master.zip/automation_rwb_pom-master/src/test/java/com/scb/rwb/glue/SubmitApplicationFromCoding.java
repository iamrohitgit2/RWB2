/*package com.scb.rwb.glue;

import static org.junit.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import cucumber.api.Scenario;
import cucumber.api.java.en.*;

public class SubmitApplicationFromCoding {
	
	WebDriver driver =Coding.driver;
	WebDriverWait wait = new WebDriverWait(driver, 30);
	Logger logger= Logger.getLogger("SubmitApplicationFromCoding");
	

	//Wait <WebDriver> fluwait = new FluentWait <WebDriver> (driver).withTimeout(30, TimeUnit.SECONDS).pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);


	
	@When("^I submit application from coding$") 
	public void i_submit_application_from_coding() throws Throwable {
		assertTrue("Submit button is not displaying", driver.findElement(By.cssSelector(".document-submit")).isDisplayed()); // added by me
		driver.findElement(By.cssSelector(".document-submit")).click();
		
		
	}
	
	
	@When("^I reject application from coding$") 
	public void i_reject_application_from_coding() throws Throwable {
		
		   WebElement ele = driver.findElement(By.cssSelector(".modal---wrapper .main-footer .application-reject"));
		   Actions action = new Actions(driver);
		   action.moveToElement(ele).build().perform();
		   ele.click();

		Thread.sleep(2000);
		assertTrue(driver.findElement(By.cssSelector(".modal---wrapper .main-footer .application-reject")).isDisplayed()); // added by me
		driver.findElement(By.cssSelector(".modal---wrapper .main-footer .application-reject"));
		Thread.sleep(10000);
           //finding the Note for entering the  rejected 
		//driver.switchTo().alert();
		
		WebElement not= (WebElement)((JavascriptExecutor) driver).executeScript("document.getElementsByClassName('ember-view ember-text-area')[1].value=\"rejected\" ");
		 
		 JavascriptExecutor jse = (JavascriptExecutor) driver;
		 jse.executeScript("document.getElementsByClassName('ember-view ember-text-area')[1].focus()");
			
		 Thread.sleep(2000);
         
		   WebElement ele1 = driver.findElement(By.cssSelector(".modal---wrapper .bottom .modal---button"));
		   Actions action1 = new Actions(driver);
		   action1.moveToElement(ele1).build().perform();
		   ele1.click();
		   Thread.sleep (30000);
		   System.out.println("Application Rejected Successfully");
		   //((JavascriptExecutor) driver).executeScript("document.getElementById('button-ok').click()");
		}

	@When("^the application should be submitted successfully$")
	public void the_application_should_be_submitted_successfully() throws Throwable
	{
		Thread.sleep(20000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); 
		//driver.findElement(By.cssSelector(".modal-search---input-field"));
		((JavascriptExecutor) driver).executeScript("document.getElementsByClassName('modal---close-button')[0].click()");
		String appquecont=driver.findElement(By.cssSelector(".app-queue-container")).getText();
		
		//System.out.println("AFTER SUBMISSION" +appquecont);
		String QueueName =driver.findElement(By.cssSelector(".tabs .active")).getText();
		assertTrue(QueueName.equalsIgnoreCase("CODING"));
		
		Thread.sleep(5000);
		
		String dataSheetpath = TestData.TestDataPath;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
		
		
		XSSFSheet sheets = workbooks.getSheet("AppSubmittedFromCoding");
		XSSFRow row = sheets.createRow(0);
		XSSFCell cell = row.createCell(0);
		cell.setCellValue(TestData.applicationId);
		FileOutputStream fileOut = new FileOutputStream(dataSheetpath);
		workbooks.write(fileOut);
		fileOut.close();
		
		if (TestData.configureApplicationSubmittedFromCodingPath)
		{
		RollingFileAppender fileApp = new RollingFileAppender();
		fileApp.setName("Applications for Coding");
		String currentDir = System.getProperty("user.dir");
		String ApplicationSubmittedFromCodingPath=currentDir+TestData.logbasePath+"files_"+TestData.TimeStamp+"/ApplicationSubmittedFromCoding.log";
		
		System.out.println(ApplicationSubmittedFromCodingPath);
		fileApp.setFile(ApplicationSubmittedFromCodingPath);
		fileApp.activateOptions();	
		PatternLayout p = new PatternLayout();
		p.setConversionPattern("%d{ISO8601} [%t] %-5p %c %x - %m%n");
		fileApp.setLayout(p);
		fileApp.setAppend(true);
		logger.addAppender(fileApp);	
		TestData.configureApplicationSubmittedFromCodingPath =false;
		
		}
		
		logger.info(TestData.ScenarioName +" = "+TestData.applicationId);
		
		
		
		//String ApplicationSubmittedFromCodingPath=currentDir+TestData.logbasePath+"/ApplicationSubmittedFromCodingPath_"+TestData.TimeStamp+".log";
		
	
     	
   }
	@When("^the application should be rejected successfully$")
	public void the_application_should_be_rejected_successfully() throws Throwable
	{
		Thread.sleep(10000);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS); 
		driver.findElement(By.cssSelector(".modal-search---input-field"));
		((JavascriptExecutor) driver).executeScript("document.getElementsByClassName('modal---close-button')[0].click()");
		//((JavascriptExecutor) driver).executeScript("document.getElementsByClassName('modal---close-button').click()");
		
		String appquecont=driver.findElement(By.cssSelector(".app-queue-container")).getText();
		
		//System.out.println("AFTER SUBMISSION" +appquecont);
		String QueueName =driver.findElement(By.cssSelector(".tabs .active")).getText();
		assertTrue(QueueName.equalsIgnoreCase("CODING"));
		
		Thread.sleep(5000);
		
		String dataSheetpath = TestData.TestDataPath;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);
		
		
		XSSFSheet sheets = workbooks.getSheet("ApplicationRejectedfromCoding");
		XSSFRow row = sheets.createRow(0);
		XSSFCell cell = row.createCell(0);
		cell.setCellValue(TestData.applicationId);
		FileOutputStream fileOut = new FileOutputStream(dataSheetpath);
		workbooks.write(fileOut);
		fileOut.close();
		
		if (TestData.configureApplicationRejectedfromCodingPath)
		{
		RollingFileAppender fileApp = new RollingFileAppender();
		fileApp.setName("Applications for Coding");
		String currentDir = System.getProperty("user.dir");
		String ApplicationSubmittedFromCodingPath=currentDir+TestData.logbasePath+"files_"+TestData.TimeStamp+"/ApplicationRejectedfromCoding.log";
		
		System.out.println(ApplicationSubmittedFromCodingPath);
		fileApp.setFile(ApplicationSubmittedFromCodingPath);
		fileApp.activateOptions();	
		PatternLayout p = new PatternLayout();
		p.setConversionPattern("%d{ISO8601} [%t] %-5p %c %x - %m%n");
		fileApp.setLayout(p);
		fileApp.setAppend(true);
		logger.addAppender(fileApp);	
		TestData.configureApplicationSubmittedFromCodingPath =false;
		
		}
		
		logger.info(TestData.ScenarioName +" = "+TestData.applicationId);
		
		
		
		//String ApplicationSubmittedFromCodingPath=currentDir+TestData.logbasePath+"/ApplicationSubmittedFromCodingPath_"+TestData.TimeStamp+".log";
		
	
     	
   }
	@When("^I should see the Notes as \"(.*?)\"$")
	public void i_should_see_the_Returned_Notes_as(String Notes) throws Throwable 
	{   
		boolean NotesPresent = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.cssSelector(".notes-order .message"))));	
		List<WebElement> AllNotes = driver.findElements(By.cssSelector(".notes-order .message"));
		Iterator<WebElement> itr1 = AllNotes.iterator();
		while(itr1.hasNext()) 
		{
			String NotesFromPage = itr1.next().getText();
			if (NotesFromPage.equalsIgnoreCase(Notes))
			{
				NotesPresent= true;
				System.out.println("My Notes = " + NotesFromPage);
				break;
			}
		}
		if (!NotesPresent)
		{
			throw new RuntimeException(Notes + "Your notes Not found");
		}
	}
	
	@When("^I tap on View Notes$")
	public void i_tap_on_View_Notes() throws Throwable 
	{
		assertTrue(driver.findElement(By.cssSelector(".reply-btn")).isDisplayed()); // added by me
		driver.findElement(By.cssSelector(".reply-btn")).click();;
	}
	
	@Then("^the application should be returned successfully$")
	public void the_application_should_be_returned_successfully() throws Throwable
	{
		Thread.sleep(15000);
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); 
		

		logger.info(TestData.ScenarioName +" = "+TestData.applicationId);
		String dataSheetpath = TestData.TestDataPath;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);


		XSSFSheet sheets = workbooks.getSheet("AppReturnedFromCoding");
		XSSFRow row = sheets.createRow(0);
		XSSFCell cell = row.createCell(0);
		cell.setCellValue(TestData.applicationId);
		FileOutputStream fileOut = new FileOutputStream(dataSheetpath);
		workbooks.write(fileOut);
		fileOut.close();

		if (TestData.configureApplicationReturnedFromCodingPath)
		{
			RollingFileAppender fileApp = new RollingFileAppender();
			fileApp.setName("Applications for Coding");
			String currentDir = System.getProperty("user.dir");
			String ApplicationReturnedFromCodingPath=currentDir+TestData.logbasePath+"files_"+TestData.TimeStamp+"/AppReturnedFromCoding.log";

			System.out.println(ApplicationReturnedFromCodingPath);
			fileApp.setFile(ApplicationReturnedFromCodingPath);
			fileApp.activateOptions();	
			PatternLayout p = new PatternLayout();
			p.setConversionPattern("%d{ISO8601} [%t] %-5p %c %x - %m%n");
			fileApp.setLayout(p);
			fileApp.setAppend(true);
			logger.addAppender(fileApp);	
			TestData.configureApplicationSubmittedFromCodingPath =false;
		
		assertTrue(driver.findElement(By.cssSelector(".modal-search---input-field")).isDisplayed()); // added by me
		driver.findElement(By.cssSelector(".modal-search---input-field"));
		
		Thread.sleep(2000);
		 ((JavascriptExecutor) driver).executeScript("document.getElementsByClassName('modal---close-button')[0].click()"); //commented on 4th aug becoz after returned its navigated to coding diary page
		
		String appquecont=driver.findElement(By.cssSelector(".app-queue-container")).getText();

		//System.out.println("AFTER SUBMISSION" +appquecont);
		String QueueName =driver.findElement(By.cssSelector(".tabs .active")).getText();
		assertTrue(QueueName.equalsIgnoreCase("CODING"));
		Thread.sleep(5000);
		
			

		}
		
		

		



		//String ApplicationSubmittedFromCodingPath=currentDir+TestData.logbasePath+"/ApplicationSubmittedFromCodingPath_"+TestData.TimeStamp+".log";



	}
	
	
	
	@Then("^the application should be returned successfully from coding$")
	public void the_application_should_be_returned_successfully_from_coding() throws Throwable
	{
		Thread.sleep(15000);
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); 
		String dataSheetpath = TestData.TestDataPath;
		FileInputStream fileInputstreams = new FileInputStream(dataSheetpath);
		XSSFWorkbook workbooks = new XSSFWorkbook(fileInputstreams);


		XSSFSheet sheets = workbooks.getSheet("AppReturnedFromCoding");
		XSSFRow row = sheets.createRow(0);
		XSSFCell cell = row.createCell(0);
		cell.setCellValue(TestData.applicationId);
		FileOutputStream fileOut = new FileOutputStream(dataSheetpath);
		workbooks.write(fileOut);
		fileOut.close();

		if (TestData.configureApplicationReturnedFromCodingPath)
		{
			RollingFileAppender fileApp = new RollingFileAppender();
			fileApp.setName("Applications for Coding");
			String currentDir = System.getProperty("user.dir");
			String ApplicationReturnedFromCodingPath=currentDir+TestData.logbasePath+"files_"+TestData.TimeStamp+"/AppReturnedFromCoding.log";

			System.out.println(ApplicationReturnedFromCodingPath);
			fileApp.setFile(ApplicationReturnedFromCodingPath);
			fileApp.activateOptions();	
			PatternLayout p = new PatternLayout();
			p.setConversionPattern("%d{ISO8601} [%t] %-5p %c %x - %m%n");
			fileApp.setLayout(p);
			fileApp.setAppend(true);
			logger.addAppender(fileApp);	
			TestData.configureApplicationSubmittedFromCodingPath =false;
			

		}

		logger.info(TestData.ScenarioName +" = "+TestData.applicationId);
		
		//assertTrue(driver.findElement(By.cssSelector(".modal-search---input-field")).isDisplayed()); // added by me
		//driver.findElement(By.cssSelector(".modal-search---input-field"));
		
		//((JavascriptExecutor) driver).executeScript("document.getElementsByClassName('modal---close-button')[0].click()"); //commented on 4th aug becoz after returned its navigated to coding diary page
		
		String appquecont=driver.findElement(By.cssSelector(".app-queue-container")).getText();

		//System.out.println("AFTER SUBMISSION" +appquecont);
		String QueueName =driver.findElement(By.cssSelector(".tabs .active")).getText();
		assertTrue(QueueName.equalsIgnoreCase("CODING"));
		Thread.sleep(5000);
	}
	@Then("^I should see the remaining count$")
	public void i_should_see_the_remaining_count() throws Throwable 
	{
	  wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.className("display-count"))));
	  String RemaingCount  = driver.findElement(By.className("display-count")).getText();
	 // System.out.println("Remaining count =" +RemaingCount);
	  assertTrue(driver.findElement(By.className("display-count")).getText().contains("Characters Remaining"));
	}

	@When("^I return application from coding$")
	public void i_return_application_from_coding() throws Throwable 
	{		
		assertTrue(driver.findElement(By.cssSelector(".bottom .modal---button")).isDisplayed()); // added by me
		driver.findElement(By.cssSelector(".bottom .modal---button")).click();
		Thread.sleep(10000);

	}
	@Then("^I tap on return button and enter notes \"(.*?)\"$")
	public void I_tap_on_return_button(String Notes) throws Throwable 
	{
		String Expected= "RETURN";
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.cssSelector(".footer-status-block .application-return"))));	
		String Actual = driver.findElement(By.cssSelector(".footer-status-block .application-return")).getText();
		assertTrue(Expected.equalsIgnoreCase(Actual));
		driver.findElement(By.cssSelector(".footer-status-block .application-return")).click();
		driver.findElement(By.cssSelector(".content .ember-text-area")).sendKeys(Notes);
	}
	@When("^I reject application from coding with \"(.*?)\"$") 
	public void i_reject_application_from_coding(String notes) throws Throwable 
	{
		
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 60);
	     String Expectedrejbtn="REJECT ICONREJECT";
	    String Actualrejbtn = (String) ((JavascriptExecutor) driver).executeScript("return  document.getElementsByClassName('footer-status-block')[2].getElementsByClassName('application-reject')[0].innerText");
		
		//String Actualrejbtn = driver.findElement(By.cssSelector(".main-footer .application-reject")).getText();
		System.out.println(Actualrejbtn.trim());		
	    assertTrue(Expectedrejbtn.equalsIgnoreCase(Actualrejbtn.trim()));
        System.out.println("Expected button name = "+Actualrejbtn.trim());
        Thread.sleep(10000);
        //driver.findElement(By.xpath("//span[contains(text(),'reject icon')]")).click();
        		
   
        ((JavascriptExecutor) driver).executeScript("document.getElementsByClassName('application-reject')[3].click()");
        
      // ((JavascriptExecutor) driver).executeScript("return  document.getElementsByClassName('footer-status-block')[2].getElementsByClassName('application-reject')[0].click()"); 
        driver.findElement(By.xpath("//textarea[@placeholder='Add a note here.']")).sendKeys(notes);
			Thread.sleep(10000);
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.cssSelector(".modal---wrapper .bottom .modal---button"))));	
			driver.findElement(By.cssSelector(".modal---wrapper .bottom .modal---button")).click();
		
			Thread.sleep(10000);
			//add
			//System.out.println("app rejected");
	}
	

}
*/