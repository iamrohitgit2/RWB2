package com.scb.rwb.appium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.testdata.FromFillTestData;
import com.scb.rwb.utility.ReadCSVFile;
import com.scb.rwb.utility.ReadTestData;

public class FFClientKeyInformationPage extends AppiumBasePage {


	@FindBy(id = "select-component_cki-title_wrapper")
	WebElement slctTitle;

	@FindBy(id = "text-component_cki-first-name_wrapper")
	WebElement txtFirstName;

	@FindBy(id = "text-component_cki-middle-name_wrapper")
	WebElement txtMiddleName;

	@FindBy(id = "text-component_cki-last-name_wrapper")
	WebElement txtLastName;

	@FindBy(id = "text-component_cki-full-name_wrapper")
	WebElement txtFullName;

	@FindBy(id = "text-component_cki-alias-name_wrapper")
	WebElement txtAliasName;

	@FindBy(id = "text-component_cki-id-no_wrapper")
	WebElement txtIdNo;

	@FindBy(id = "text-component_cki-id-issue-date_wrapper")
	WebElement txtIdIssueDate;

	@FindBy(id = "text-component_cki-other-id-details_wrapper")
	WebElement txtOtherIdDetails;

	@FindBy(id = "select-component_cki-gender_wrapper")
	WebElement slctGender;

	@FindBy(id = "select-component_cki-marital-status_wrapper")
	WebElement slctMaritalStatus;

	@FindBy(id = "text-component_cki-date-of-birth-ddmmyyyy_wrapper")
	WebElement txtDateOfBirth;

	@FindBy(id = "select-component_cki-country-of-birth_wrapper")
	WebElement slctCountryOfBirth;

	@FindBy(id = "text-component_cki-district-of-birth_wrapper")
	WebElement txtDistrictOfBirth;

	@FindBy(id = "select-component_cki-nationality_wrapper")
	WebElement slctNationality;

	@FindBy(id = "text-component_cki-other-nation_wrapper")
	WebElement txtOtherNation;

	@FindBy(id = "text-component_cki-passport-no_wrapper")
	WebElement txtPassportNo;

	@FindBy(id = "text-component_cki-passport-issuance-date_wrapper")
	WebElement txtPassportIssuanceDate;

	@FindBy(id = "select-component_cki-passport-country_wrapper")
	WebElement slctPassportCountry;

	@FindBy(id = "text-component_cki-passport-expiry-date_wrapper")
	WebElement txtPassportExpiryDate;

	@FindBy(id = "text-component_cki-driving-license-no_wrapper")
	WebElement txtDrivingLicenseNo;

	@FindBy(id = "text-component_cki-driving-license-expiry-date_wrapper")
	WebElement txtDrivingLicenseExpiryDate;

	@FindBy(id = "text-component_cki-driving-license-issue-date_wrapper")
	WebElement txtDrivingLicenseIssueDate;

	@FindBy(id = "select-component_cki-driving-license-issue-country_wrapper")
	WebElement slctDrivingLicenseIssueCountry;

	@FindBy(id = "select-component_cki-qualification_wrapper")
	WebElement slctQualification;

	@FindBy(id = "text-component_cki-mother's-maiden-name_wrapper")
	WebElement txtMothersMaidenName;

	@FindBy(id = "text-component_cki-father-name_wrapper")
	WebElement txtFatherName;

	@FindBy(id = "text-component_cki-tax-id-no_wrapper")
	WebElement txtTaxIdNo;

	@FindBy(id = "select-component_cki-residence-country_wrapper")
	WebElement slctResidenceCountry;

	@FindBy(id = "select-component_cki-residential-status_wrapper")
	WebElement slctResidentialStatus;

	@FindBy(id = "text-component_cki-no-of-dependants_wrapper")
	WebElement txtNoOfDependants;

	@FindBy(id = "text-component_cki-no-of-car-owned_wrapper")
	WebElement txtNoOfCarOwned;

	@FindBy(id = "select-component_cki-staff-category_wrapper")
	WebElement slctStaffCategory;

	@FindBy(id = "text-component_cki-spouse-full-name_wrapper")
	WebElement txtSpouseFullName;

	@FindBy(id = "text-component_cki-spouse-profession_wrapper")
	WebElement txtSpouseProfession;

	@FindBy(id = "text-component_cki-spouse-organisation_wrapper")
	WebElement txtSpouseOrganisation;

	@FindBy(id = "text-component_cki-spouse-office-line1_wrapper")
	WebElement txtSpouseOfficeLine1;

	@FindBy(id = "text-component_cki-spouse-office-line2_wrapper")
	WebElement txtSpouseOfficeLine2;

	@FindBy(id = "text-component_cki-spouse-office-line3_wrapper")
	WebElement txtSpouseOfficeLine3;

	@FindBy(id = "text-component_cki-spouse-contact-no_wrapper")
	WebElement txtSpouseContactNo;

	@FindBy(id = "text-component_cki-spouse-email_wrapper")
	WebElement txtSpouseEmail;

	@FindBy(id = "text-component_cki-spouse-fav-colour_wrapper")
	WebElement txtSpouseFavColour;

	@FindBy(id = "text-component_cki-spouse-fav-city_wrapper")
	WebElement txtSpouseFavCity;

	@FindBy(css = "body")
	WebElement body;

	@FindBy(id = "next-button")
	WebElement btnNext;

	By tagNameInput = By.tagName("input");

	By tagNameLabel = By.tagName("label");

	/**
	 * This method will fill the fields for Client Key Information
	 * 
	 * @return
	 */
	public FFAddressPage enterClientKeyInformation() {
		waitForvisiblityOfGivenElement(slctTitle);
		formFillSelectElementFromDropdown(slctTitle,
				ReadTestData.ffData.getTitle());
		sleep(2000);
		// Yogesh(1557591)
		
		formFillEnterText(txtFirstName,
				ReadTestData.ffData.getFirstName());
		formFillEnterText(txtMiddleName,
				ReadTestData.ffData.getMiddleName());
		formFillEnterText(txtLastName,
				ReadTestData.ffData.getLastName());
		formFillEnterText(txtFullName,
				ReadTestData.ffData.getFullName());
		formFillEnterText(txtAliasName,
				ReadTestData.ffData.getAliasName());
		formFillEnterText(txtIdNo, ReadTestData.ffData.getIdNo());
		formFillEnterText(txtIdIssueDate,
				ReadTestData.ffData.getIdIssueDate());
		formFillEnterText(txtOtherIdDetails,
				ReadTestData.ffData.getOtherIdDetails());
		formFillSelectElementFromDropdown(slctGender,
				ReadTestData.ffData.getGender());
		formFillSelectElementFromDropdown(slctMaritalStatus,
				ReadTestData.ffData.getMaritalStatus());
		formFillEnterText(txtDateOfBirth,
				ReadTestData.ffData.getDateOfBirth());
		formFillSelectElementFromDropdown(slctCountryOfBirth,
				ReadTestData.ffData.getCountryOfBirth());
		sleep(2000);
		formFillEnterText(txtDistrictOfBirth,
				ReadTestData.ffData.getDistrictOfBirth());
		formFillSelectElementFromDropdown(slctNationality,
				ReadTestData.ffData.getNationality());
		formFillEnterText(txtOtherNation,
				ReadTestData.ffData.getOtherNation());
		formFillEnterText(txtPassportNo,
				ReadTestData.ffData.getPassportNo());
		formFillEnterText(txtPassportIssuanceDate,
				ReadTestData.ffData.getPassportIssuanceDate());
		formFillSelectElementFromDropdown(slctPassportCountry,
				ReadTestData.ffData.getPassportCountry());
		formFillEnterText(txtPassportExpiryDate,
				ReadTestData.ffData.getPassportExpiryDate());
		formFillEnterText(txtDrivingLicenseNo,
				ReadTestData.ffData.getDrivingLicenseNo());
		formFillEnterText(txtDrivingLicenseExpiryDate,
				ReadTestData.ffData.getDrivingLicenseExpiryDate());
		formFillEnterText(txtDrivingLicenseIssueDate,
				ReadTestData.ffData.getDrivingLicenseIssueDate());
		formFillSelectElementFromDropdown(
				slctDrivingLicenseIssueCountry,
				ReadTestData.ffData.getDrivingLicenseIssueCountry());
		formFillSelectElementFromDropdown(slctQualification,
				ReadTestData.ffData.getQualification());
		formFillEnterText(txtMothersMaidenName,
				ReadTestData.ffData.getMothersMaidenName());
		formFillEnterText(txtFatherName,
				ReadTestData.ffData.getFatherName());
		formFillEnterText(txtTaxIdNo,
				ReadTestData.ffData.getTaxIdNo());
		formFillSelectElementFromDropdown(slctResidenceCountry,
				ReadTestData.ffData.getResidenceCountry());
		formFillSelectElementFromDropdown(slctResidentialStatus,
				ReadTestData.ffData.getResidentialStatus());
		formFillEnterText(txtNoOfDependants,
				ReadTestData.ffData.getNoOfDependants());
		formFillEnterText(txtNoOfCarOwned,
				ReadTestData.ffData.getNoOfCarOwned());
		formFillSelectElementFromDropdown(slctStaffCategory,
				ReadTestData.ffData.getStaffCategory());
		formFillEnterText(txtSpouseFullName,
				ReadTestData.ffData.getSpouseFullName());
		formFillEnterText(txtSpouseProfession,
				ReadTestData.ffData.getSpouseProfession());
		formFillEnterText(txtSpouseOrganisation,
				ReadTestData.ffData.getSpouseOrganisation());
		formFillEnterText(txtSpouseOfficeLine1,
				ReadTestData.ffData.getOffAddressLine1());
		formFillEnterText(txtSpouseOfficeLine2,
				ReadTestData.ffData.getOffAddressLine2());
		formFillEnterText(txtSpouseOfficeLine3,
				ReadTestData.ffData.getOffAddressLine3());
		formFillEnterText(txtSpouseContactNo,
				ReadTestData.ffData.getSpouseContactNo());
		formFillEnterText(txtSpouseEmail,
				ReadTestData.ffData.getSpouseEmail());
		formFillEnterText(txtSpouseFavColour,
				ReadTestData.ffData.getSpouseFavColour());
		formFillEnterText(txtSpouseFavCity,
				ReadTestData.ffData.getSpouseFavCity());
		body.click();
		waitForvisiblityOfGivenElement(btnNext);
		btnNext.click();
		return new FFAddressPage();
	}
}
