package com.scb.rwb.appium.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.utility.ReadTestData;

public class FFContactPage extends AppiumBasePage {


	/*@FindBy(id = "text-component_c-home_wrapper")
	WebElement txtHome;

	@FindBy(id = "text-component_c-work_wrapper")
	WebElement txtWork;

	@FindBy(id = "text-component_c-mobile_wrapper")
	WebElement txtMobile;

	@FindBy(id = "text-component_c-fax_wrapper")
	WebElement txtFax;

	@FindBy(id = "text-component_c-email_wrapper")
	WebElement txtEmail;

	@FindBy(id = "text-component_c-other-contact_wrapper")
	WebElement txtOtherContact;*/

	FFClientKeyInformationPage ffCKI = new FFClientKeyInformationPage();
	
	@FindBy(xpath = "//div[contains(@id,'_c-') and input[@type='text']]")
	List<WebElement> textFields;
	@FindBy(xpath = "//div[contains(@id,'_c-') and input[@type='date']]")
	List<WebElement> dateFeilds;

	@FindBy(xpath = "//div[.//input[@class='ui-autocomplete-input']][contains(@id,'_c-')]")
	List<WebElement> dropdownFeilds;

	@FindBy(xpath = "//div[input[@type='checkbox']][contains(@id,'_c-')]")
	List<WebElement> switchFeilds;

	@FindBy(xpath = "//div[.//input[@type='radio']][contains(@id,'_c-')]")
	List<WebElement> radioFeilds;

	@FindBy(css = "body")
	WebElement body;

	@FindBy(id = "next-button")
	WebElement btnNext;

	By tagNameInput = By.tagName("input");

	By tagNameLabel = By.tagName("label");
	
	Set<String> webele = new HashSet<String>();
	Set<String> csvkeys  = new HashSet<String>();
	HashMap<String, ArrayList<String>> addMap;
	
	public FFIncomePage formFillForContactSection(int count) throws Exception {
		
		getNeedDataFromCSVMap(count);
		fillTextfields();
		filldatefields();
		filldropdownFeilds();
		fillswitchFeilds();
		verificationOfRequiedElemetsPresentInPage(webele, csvkeys);
		body.click();
		waitForvisiblityOfGivenElement(btnNext);
		btnNext.click();
		
		return new FFIncomePage();

	}

	public  void fillTextfields() throws Exception {
		webele = formFillEnterText(textFields, addMap, webele);
		
	}

	public void filldatefields() throws Exception {
		webele = formFillEnterText(dateFeilds, addMap, webele);
		
	}

	public void fillswitchFeilds() throws Exception {
		webele = formFillSwitchElementToClick(switchFeilds, addMap, webele);
	}

	public void fillradioFeilds() {
		for (WebElement element : radioFeilds) {
			// if(Map.field contains element.getAttribute("id");
			// element.sendKeys( the value of the map);
		}
	}

	public void filldropdownFeilds() throws Exception {
		webele = formFillSelectElementFromDropdown(dropdownFeilds, addMap, webele);
	}
	
	
	public void getNeedDataFromCSVMap(int requiredCol){
		addMap = new HashMap<>();
		for (String data : ReadTestData.ffCMap.keySet()) {
			if(!ReadTestData.ffCMap.get(data).get(requiredCol).equals("N")){
				addMap.put(data, ReadTestData.ffCMap.get(data));
			}
		}
		
		for (String dat : addMap.keySet()) {
			csvkeys.add(dat);
		}
	}
	
	/**
	 * This method will enter the data for Contact details
	 * 
	 * @return
	 */
	/*public FFIncomePage enterContactDetails() {
		sleep(3000);
		formFillEnterText(txtHome,
				ReadTestData.ffData.getHome());
		formFillEnterText(txtWork,
				ReadTestData.ffData.getWork());
		formFillEnterText(txtMobile,
				ReadTestData.ffData.getMobile());
		formFillEnterText(txtFax,
				ReadTestData.ffData.getFax());
		formFillEnterText(txtEmail,
				ReadTestData.ffData.getEmail());
		formFillEnterText(txtOtherContact,
				ReadTestData.ffData.getOtherContact());
		ffCKI.body.click();
		waitForvisiblityOfGivenElement(ffCKI.btnNext);
		ffCKI.btnNext.click();

		return new FFIncomePage();
	}*/

}
