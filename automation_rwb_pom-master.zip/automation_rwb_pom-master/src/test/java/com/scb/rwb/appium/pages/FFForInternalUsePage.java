package com.scb.rwb.appium.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.scb.rwb.utility.ReadTestData;

public class FFForInternalUsePage extends AppiumBasePage {


	/*@FindBy(id = "text-component_fiu-nb-arm-code_wrapper")
	WebElement txtNBArmCode;

	@FindBy(id = "select-component_fiu-institution-classification_wrapper")
	WebElement slctInstitutionClassification;

	@FindBy(id = "text-component_fiu-relationship-no_wrapper")
	WebElement txtRelationshipNo;

	@FindBy(id = "select-component_fiu-location-dhaka_wrapper")
	WebElement slctLocationDhaka;

	@FindBy(id = "text-component_fiu-acq-channel-code_wrapper")
	WebElement txtAcqChannelCode;

	@FindBy(id = "switch-component_fiu-pre-appr-offer_wrapper")
	WebElement swchPreApprOffer;

	@FindBy(id = "text-component_fiu-pre-appr-offer-details_wrapper")
	WebElement txtPreApprOfferDetails;

	@FindBy(id = "text-component_fiu-pre-appr-offer-id-no_wrapper")
	WebElement txtPreApprOfferIdNo;

	@FindBy(id = "text-component_sd-dse-code_wrapper")
	WebElement txtDSECode;

	@FindBy(id = "select-component_fiu-segment_wrapper")
	WebElement slctSegment;

	@FindBy(id = "select-component_fiu-sub-segment_wrapper")
	WebElement slctSubSegment;

	@FindBy(id = "select-component_fiu-pl-segment_wrapper")
	WebElement slctPlSegment;

	@FindBy(id = "select-component_fiu-area_wrapper")
	WebElement slctArea;

	@FindBy(id = "text-component_fiu-arm-code_wrapper")
	WebElement slctArmCode;

	@FindBy(id = "text-component_fiu-campaign-code_wrapper")
	WebElement txtCampaignCode;

	@FindBy(id = "select-component_fiu-deviation-level_wrapper")
	WebElement slctDeviationLevel;

	@FindBy(id = "text-component_fiu-loan-no_wrapper")
	WebElement txtLoanNo;

	@FindBy(id = "text-component_fiu-master-no_wrapper")
	WebElement txtMasterNo;

	@FindBy(id = "select-component_fiu-payroll-indicator_wrapper")
	WebElement slctPayrollIndicator;

	@FindBy(id = "select-component_fiu-spot-approval_wrapper")
	WebElement slctSpotApproval;

	@FindBy(id = "select-component_fiu-top-up_wrapper")
	WebElement slctTopUp;

	@FindBy(id = "select-component_fiu-cib-report-fetching_wrapper")
	WebElement slctCIBReportFetching;

	@FindBy(id = "text-component_fiu-forwarded-by_wrapper")
	WebElement txtForwardedBy;

	@FindBy(id = "text-component_fiu-referral-code_wrapper")
	WebElement txtReferralCode;

	@FindBy(id = "text-component_fiu-sales-staff-designation_wrapper")
	WebElement txtSalesStaffDesignation;

	@FindBy(id = "text-component_fiu-reference-no-campaign_wrapper")
	WebElement txtReferenceNoCampaign;*/

	FFClientKeyInformationPage ffCKI = new FFClientKeyInformationPage();
	
	
	@FindBy(xpath = "//div[contains(@id,'_fiu-') and input[@type='text']]")
	List<WebElement> textFields;
	@FindBy(xpath = "//div[contains(@id,'_fiu-') and input[@type='date']]")
	List<WebElement> dateFeilds;

	@FindBy(xpath = "//div[.//input[@class='ui-autocomplete-input']][contains(@id,'_fiu-')]")
	List<WebElement> dropdownFeilds;

	@FindBy(xpath = "//div[input[@type='checkbox']][contains(@id,'_fiu-')]")
	List<WebElement> switchFeilds;

	@FindBy(xpath = "//div[.//input[@type='radio']][contains(@id,'_fiu-')]")
	List<WebElement> radioFeilds;

	@FindBy(css = "body")
	WebElement body;

	@FindBy(id = "next-button")
	WebElement btnNext;

	By tagNameInput = By.tagName("input");

	By tagNameLabel = By.tagName("label");
	
	Set<String> webele = new HashSet<String>();
	Set<String> csvkeys  = new HashSet<String>();
	HashMap<String, ArrayList<String>> addMap;
	
	public void formFillForInternalUseSection(int count) throws Exception {
		
		getNeedDataFromCSVMap(count);
		fillTextfields();
		filldatefields();
		filldropdownFeilds();
		fillswitchFeilds();
		verificationOfRequiedElemetsPresentInPage(webele, csvkeys);
		body.click();
		waitForvisiblityOfGivenElement(btnNext);
		btnNext.click();


	}

	public  void fillTextfields() throws Exception {
		webele = formFillEnterText(textFields, addMap, webele);
		
	}

	public void filldatefields() throws Exception {
		webele = formFillEnterText(dateFeilds, addMap, webele);
		
	}

	public void fillswitchFeilds() throws Exception {
		webele = formFillSwitchElementToClick(switchFeilds, addMap, webele);
	}

	public void fillradioFeilds() {
		for (WebElement element : radioFeilds) {
			// if(Map.field contains element.getAttribute("id");
			// element.sendKeys( the value of the map);
		}
	}

	public void filldropdownFeilds() throws Exception {
		webele = formFillSelectElementFromDropdown(dropdownFeilds, addMap, webele);
	}
	
	
	public void getNeedDataFromCSVMap(int requiredCol){
		addMap = new HashMap<>();
		for (String data : ReadTestData.ffFiuMap.keySet()) {
			if(!ReadTestData.ffFiuMap.get(data).get(requiredCol).equals("N")){
				addMap.put(data, ReadTestData.ffFiuMap.get(data));
			}
		}
		
		for (String dat : addMap.keySet()) {
			csvkeys.add(dat);
		}
	}

	/*public void enterForInternaleUseDetails() {
		formFillSelectElementFromDropdown(slctSegment,
				ReadTestData.ffData.getSegment());
		formFillSelectElementFromDropdown(
				slctLocationDhaka,
				ReadTestData.ffData.getLocationDhaka());
		formFillEnterText(txtAcqChannelCode,
				ReadTestData.ffData.getAcqChannelCode());
		formFillSelectElementFromDropdown(
				slctInstitutionClassification,
				ReadTestData.ffData.getInstitutionClassification());

		formFillSwitchElementToClick(swchPreApprOffer,
				ReadTestData.ffData.getPreApprOffer());
		formFillEnterText(txtPreApprOfferDetails,
				ReadTestData.ffData.getPreApprOfferDetails());
		formFillEnterText(txtPreApprOfferIdNo,
				ReadTestData.ffData.getPreApprOfferIdNo());
		formFillEnterText(txtDSECode,
				ReadTestData.ffData.getDseCode());
		formFillEnterText(txtRelationshipNo,
				ReadTestData.ffData.getRelationshipNo());
		formFillEnterText(txtCampaignCode,
				ReadTestData.ffData.getCampaignCode());
		formFillEnterText(txtNBArmCode,
				ReadTestData.ffData.getNbArmCode());
		formFillSelectElementFromDropdown(slctSubSegment,
				ReadTestData.ffData.getSubSegment());
		formFillSelectElementFromDropdown(slctPlSegment,
				ReadTestData.ffData.getPlSegment());
		formFillSelectElementFromDropdown(slctArea,
				ReadTestData.ffData.getArea());
		formFillEnterText(slctArmCode,
				ReadTestData.ffData.getArmCode());

		formFillSelectElementFromDropdown(
				slctDeviationLevel,
				ReadTestData.ffData.getDeviationLevel());
		formFillEnterText(txtLoanNo,
				ReadTestData.ffData.getLoanNo());
		formFillEnterText(txtMasterNo,
				ReadTestData.ffData.getMasterNo());
		formFillSelectElementFromDropdown(
				slctPayrollIndicator,
				ReadTestData.ffData.getPayrollIndicator());
		formFillSelectElementFromDropdown(slctSpotApproval,
				ReadTestData.ffData.getSpotApproval());
		formFillSelectElementFromDropdown(slctTopUp,
				ReadTestData.ffData.getTopUp());
		formFillSelectElementFromDropdown(
				slctCIBReportFetching,
				ReadTestData.ffData.getCibReportFetching());
		formFillEnterText(txtForwardedBy,
				ReadTestData.ffData.getForwardedBy());
		formFillEnterText(txtReferralCode,
				ReadTestData.ffData.getReferralCode());
		formFillEnterText(txtSalesStaffDesignation,
				ReadTestData.ffData.getSalesStaffDesignation());
		formFillEnterText(txtReferenceNoCampaign,
				ReadTestData.ffData.getReferenceNoCampaign());

		ffCKI.body.click();
		waitForvisiblityOfGivenElement(ffCKI.btnNext);
		ffCKI.btnNext.click();
	}*/

}
